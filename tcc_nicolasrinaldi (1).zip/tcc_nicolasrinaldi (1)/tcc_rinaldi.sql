-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 01/10/2025 às 14:02
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `tcc_rinaldi`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `calculadora`
--

CREATE TABLE `calculadora` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `receita` decimal(10,2) NOT NULL,
  `despesas` decimal(10,2) NOT NULL,
  `impostos` decimal(10,2) NOT NULL,
  `lucro` decimal(10,2) GENERATED ALWAYS AS (`receita` - `despesas` - `impostos`) STORED,
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `calculadora_conteudo`
--

CREATE TABLE `calculadora_conteudo` (
  `id` int(11) NOT NULL,
  `calculadora_titulo` varchar(255) DEFAULT NULL,
  `calculadora_paragrafo` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `calculadora_conteudo`
--

INSERT INTO `calculadora_conteudo` (`id`, `calculadora_titulo`, `calculadora_paragrafo`, `created_at`, `updated_at`) VALUES
(1, 'Calculadora Financeira', 'Utilize nossa calculadora para simular seus ganhos, custos e organizar sua vida financeira.', '2025-09-12 13:48:50', '2025-09-12 13:48:50');

-- --------------------------------------------------------

--
-- Estrutura para tabela `calculos`
--

CREATE TABLE `calculos` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `tipo_atividade` enum('formal','informal') NOT NULL,
  `renda_bruta` decimal(10,2) NOT NULL,
  `despesas_fixas` decimal(10,2) NOT NULL,
  `despesas_variaveis` decimal(10,2) NOT NULL,
  `impostos` decimal(10,2) NOT NULL DEFAULT 0.00,
  `salario` decimal(10,2) NOT NULL DEFAULT 0.00,
  `saldo` decimal(10,2) NOT NULL,
  `data_calculo` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `calculos`
--

INSERT INTO `calculos` (`id`, `user_id`, `tipo_atividade`, `renda_bruta`, `despesas_fixas`, `despesas_variaveis`, `impostos`, `salario`, `saldo`, `data_calculo`) VALUES
(8, 6, 'formal', 500000.00, 200.00, 200.00, 0.00, 0.00, 497400.00, '2025-09-12 14:27:14'),
(9, 6, 'formal', 100000.00, 100.00, 100.00, 0.00, 0.00, 98700.00, '2025-09-12 14:27:49'),
(10, 6, 'formal', 200000.00, 200.00, 200.00, 0.00, 0.00, 199200.00, '2025-09-12 14:28:01'),
(11, 6, 'formal', 500000.00, 100.00, 100.00, 0.00, 0.00, 498700.00, '2025-09-12 14:32:50'),
(12, 6, 'formal', 200.00, 10000.00, 10000.00, 0.00, 0.00, -39800.00, '2025-09-12 14:59:29'),
(13, 8, 'formal', 2000000.00, 100.00, 100.00, 0.00, 0.00, 1999600.00, '2025-09-13 00:53:21'),
(14, 8, 'formal', 100.00, 20000.00, 20000.00, 0.00, 0.00, -79900.00, '2025-09-13 00:54:02'),
(15, 8, 'formal', 200000.00, 200.00, 200.00, 0.00, 0.00, 199200.00, '2025-09-13 00:54:35'),
(16, 8, 'formal', 6000.00, 1800.00, 600.00, 0.00, 0.00, 850.00, '2025-09-13 00:55:22'),
(17, 8, 'formal', 7000.00, 1000.00, 400.00, 0.00, 1500.00, 4100.00, '2025-09-13 01:42:07'),
(18, 5, 'informal', 500000.00, 10000.00, 1000.00, 0.00, 0.00, 489000.00, '2025-09-01 03:00:00'),
(19, 5, 'informal', 10000.00, 1000.00, 0.00, 0.00, 0.00, 9000.00, '2025-08-01 03:00:00'),
(20, 5, 'formal', 10000.00, 1000.00, 0.00, 0.00, 0.00, 9000.00, '2025-08-01 03:00:00'),
(21, 5, 'informal', 500000.00, 10000.00, 1120.00, 0.00, 0.00, 488880.00, '2025-09-01 03:00:00'),
(22, 5, 'informal', 501000.00, 10000.00, 1120.00, 0.00, 0.00, 489880.00, '2025-09-01 03:00:00'),
(23, 9, 'informal', 3500.00, 800.00, 100.00, 0.00, 0.00, 2600.00, '2025-09-01 03:00:00'),
(24, 9, 'informal', 5000.00, 800.00, 0.00, 0.00, 0.00, 4200.00, '2025-08-01 03:00:00');

-- --------------------------------------------------------

--
-- Estrutura para tabela `calendar_events`
--

CREATE TABLE `calendar_events` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `event_date` date NOT NULL,
  `importance` enum('verde','amarelo','vermelho') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `calendar_events`
--

INSERT INTO `calendar_events` (`id`, `user_id`, `title`, `description`, `event_date`, `importance`, `created_at`) VALUES
(1, 5, 'Pagamento do DAS', 'Pagar o das', '2025-09-08', 'vermelho', '2025-09-24 12:07:35'),
(2, 5, 'Pagar conta de agua', 'Pagamento da Sabesp', '2025-09-08', 'amarelo', '2025-09-24 12:10:00'),
(3, 9, 'DAS', 'Pagamento do DAS', '2025-09-10', 'vermelho', '2025-09-30 13:26:10'),
(4, 9, 'DAS', 'Pagamento do DAS', '2025-09-30', 'vermelho', '2025-09-30 13:26:37');

-- --------------------------------------------------------

--
-- Estrutura para tabela `home_conteudo`
--

CREATE TABLE `home_conteudo` (
  `id` int(11) NOT NULL,
  `home_titulo` varchar(255) NOT NULL,
  `home_paragrafo` text NOT NULL,
  `card1_titulo` varchar(255) NOT NULL,
  `card1_paragrafo` text NOT NULL,
  `card2_titulo` varchar(255) NOT NULL,
  `card2_paragrafo` text NOT NULL,
  `card3_titulo` varchar(255) NOT NULL,
  `card3_paragrafo` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `home_conteudo`
--

INSERT INTO `home_conteudo` (`id`, `home_titulo`, `home_paragrafo`, `card1_titulo`, `card1_paragrafo`, `card2_titulo`, `card2_paragrafo`, `card3_titulo`, `card3_paragrafo`) VALUES
(1, 'Bem Vindo!', 'Sistema de apoio financeiro e jurídico para trabalhadores autônomos.', '📊 Calculadora', 'Simule ganhos, custos e organize sua vida financeira.', '📂 Planilhas', 'Baixe planilhas de controle personalizadas para sua rotina.', '⚖️ Trilha Jurídica', 'Entenda obrigações legais e acesse documentos importantes.');

-- --------------------------------------------------------

--
-- Estrutura para tabela `juridico_conteudo`
--

CREATE TABLE `juridico_conteudo` (
  `id` int(11) NOT NULL,
  `juridico_titulo` varchar(255) DEFAULT NULL,
  `juridico_paragrafo` text DEFAULT NULL,
  `trilha_informal_titulo` varchar(255) DEFAULT NULL,
  `trilha_informal_paragrafo` text DEFAULT NULL,
  `trilha_formal_titulo` varchar(255) DEFAULT NULL,
  `trilha_formal_paragrafo` text DEFAULT NULL,
  `doc1_titulo` varchar(255) DEFAULT NULL,
  `doc1_link` varchar(255) DEFAULT NULL,
  `doc2_titulo` varchar(255) DEFAULT NULL,
  `doc2_link` varchar(255) DEFAULT NULL,
  `doc3_titulo` varchar(255) DEFAULT NULL,
  `doc3_link` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `juridico_conteudo`
--

INSERT INTO `juridico_conteudo` (`id`, `juridico_titulo`, `juridico_paragrafo`, `trilha_informal_titulo`, `trilha_informal_paragrafo`, `trilha_formal_titulo`, `trilha_formal_paragrafo`, `doc1_titulo`, `doc1_link`, `doc2_titulo`, `doc2_link`, `doc3_titulo`, `doc3_link`, `created_at`, `updated_at`) VALUES
(1, 'Guia Jurídico Essencial para MEIs', 'Este guia oferece uma visão geral das obrigações legais, direitos e deveres dos Microempreendedores Individuais (MEIs). O material foi desenvolvido para ajudar você a entender as principais leis e regulamentações que impactam sua atividade empresarial, garantindo que você opere de forma segura e em conformidade.', 'Passo a Passo para se Tornar MEI', 'Você está no caminho para a formalização! Siga esta trilha para aprender o caminho completo, desde a pesquisa inicial até a obtenção do seu CNPJ e os benefícios que a formalização trará para o seu negócio.', 'Trilha para MEI Formalizado: Mantenha-se em Dia', 'Guia essencial para quem já é MEI. Entenda suas obrigações, como declarar seu faturamento, emitir notas fiscais e gerenciar o seu negócio legalmente.', 'Estatuto da Microempresa', 'https://www.gov.br/receitafederal/pt-br/assuntos/orientacao-tributaria/simples-nacional/microempreendedor-individual/legislacao/estatuto-nacional-da-microempresa-e-empresa-de-pequeno-porte', 'Direitos e Deveres do MEI', 'https://www.sebrae.com.br/sites/PortalSebrae/ufs/sp/conteudo_user/direitos-e-deveres-do-mei', 'Manual do MEI', 'https://www.gov.br/receitafederal/pt-br/assuntos/orientacao-tributaria/simples-nacional/microempreendedor-individual/manuais/manual-do-mei', '2025-09-23 15:07:45', '2025-10-01 11:56:28');

-- --------------------------------------------------------

--
-- Estrutura para tabela `juridico_documentos`
--

CREATE TABLE `juridico_documentos` (
  `id` int(11) NOT NULL,
  `titulo` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL,
  `tipo` varchar(50) NOT NULL COMMENT 'informal ou formal'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `juridico_documentos`
--

INSERT INTO `juridico_documentos` (`id`, `titulo`, `link`, `tipo`) VALUES
(1, 'Checklist para Formalização MEI', 'https://www.gov.br/empresas-e-negocios/pt-br/empreendedor/sou-mei', 'informal'),
(2, 'Guia de Emissão de Nota Fiscal', 'https://www.gov.br/empresas-e-negocios/pt-br/empreendedor/servicos-para-mei/emissao-de-nota-fiscal', 'formal'),
(3, 'Declaração Anual de Faturamento (DASN-SIMEI)', 'https://www.gov.br/empresas-e-negocios/pt-br/empreendedor/servicos-para-mei/declaracao-anual-de-faturamento', 'formal'),
(4, 'Cartilha do MEI', 'https://www.gov.br/empresas-e-negocios/pt-br/empreendedor/sou-mei', 'informal'),
(5, 'Manual de Orientação do Simples Nacional', 'https://www.gov.br/empresas-e-negocios/pt-br/empreendedor/simples-nacional', 'formal'),
(6, 'Passo a Passo para se Tornar MEI', 'https://www.gov.br/empresas-e-negocios/pt-br/empreendedor/sou-mei/passo-a-passo', 'informal');

-- --------------------------------------------------------

--
-- Estrutura para tabela `juridico_trilhas`
--

CREATE TABLE `juridico_trilhas` (
  `id` int(11) NOT NULL,
  `status_tipo` varchar(50) NOT NULL COMMENT 'Pode ser informal ou formal',
  `titulo` varchar(255) NOT NULL,
  `paragrafo` text NOT NULL,
  `ordem` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `juridico_trilhas`
--

INSERT INTO `juridico_trilhas` (`id`, `status_tipo`, `titulo`, `paragrafo`, `ordem`) VALUES
(1, 'informal', 'Pesquisa e Planejamento', 'Pesquise se a sua atividade pode ser enquadrada como MEI e verifique o limite de faturamento anual de R$ 81.000,00. Analise os custos e benefícios iniciais.', 1),
(2, 'informal', 'Criação da Conta Gov.br', 'Crie uma conta no portal Gov.br com nível de segurança Ouro ou Prata. Esta conta será a sua porta de entrada para a formalização.', 2),
(3, 'informal', 'Formalização no Portal do Empreendedor', 'Acesse o Portal do Empreendedor, faça login com sua conta Gov.br e preencha os dados necessários para registrar seu MEI. Ao final, você terá o seu CNPJ.', 3),
(4, 'informal', 'Conheça suas Vantagens', 'Você agora tem um CNPJ! Isso traz vantagens como aposentadoria, auxílio-doença, auxílio-maternidade e a possibilidade de emitir nota fiscal e ter acesso a crédito mais fácil.', 4),
(5, 'formal', 'Pagamento do DAS', 'Pague a guia do Documento de Arrecadação do Simples Nacional (DAS) mensalmente. O valor inclui a contribuição para o INSS, ISS e/ou ICMS e garante seus benefícios previdenciários.', 1),
(6, 'formal', 'Declaração Anual de Faturamento (DASN-SIMEI)', 'Entregue a Declaração Anual de Faturamento (DASN-SIMEI) até o dia 31 de maio de cada ano. Nela, você informa a receita bruta do ano anterior e se teve funcionários.', 2),
(7, 'formal', 'Emissão de Notas Fiscais', 'Emita nota fiscal sempre que vender para uma pessoa jurídica. Para pessoa física, a emissão não é obrigatória, mas é recomendada.', 3),
(8, 'formal', 'Controle Financeiro', 'Mantenha um controle financeiro rigoroso das suas receitas e despesas. Isso é fundamental para a gestão do seu negócio e para o preenchimento da DASN-SIMEI.', 4);

-- --------------------------------------------------------

--
-- Estrutura para tabela `planilhas`
--

CREATE TABLE `planilhas` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `titulo` varchar(150) NOT NULL,
  `dados` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`dados`)),
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `planilhas_conteudo`
--

CREATE TABLE `planilhas_conteudo` (
  `id` int(11) NOT NULL,
  `planilhas_titulo` varchar(255) DEFAULT NULL,
  `planilhas_paragrafo` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `planilhas_conteudo`
--

INSERT INTO `planilhas_conteudo` (`id`, `planilhas_titulo`, `planilhas_paragrafo`, `created_at`, `updated_at`) VALUES
(1, 'Minhas Planilhas', 'Aqui você encontra planilhas de controle financeiro e organização personalizadas.', '2025-09-12 13:49:01', '2025-09-12 13:49:01');

-- --------------------------------------------------------

--
-- Estrutura para tabela `registros_financeiros`
--

CREATE TABLE `registros_financeiros` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `valor` decimal(10,2) NOT NULL,
  `descricao` varchar(255) NOT NULL,
  `tipo` varchar(50) NOT NULL COMMENT 'Ex: saldo, renda, custo_variavel, custo_fixo',
  `data_registro` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `registros_financeiros`
--

INSERT INTO `registros_financeiros` (`id`, `user_id`, `valor`, `descricao`, `tipo`, `data_registro`, `created_at`) VALUES
(1, 0, 2000.00, 'Compra Marcia', 'renda', '2025-09-13', '2025-09-13 01:27:07'),
(2, 8, 2000.00, 'compra', 'renda', '2025-09-13', '2025-09-13 01:31:25'),
(3, 8, 200.00, 'agua', 'custo_variavel', '2025-09-13', '2025-09-13 01:31:37'),
(4, 8, 200.00, 'espelho', 'custo_variavel', '2025-09-13', '2025-09-13 01:31:47'),
(5, 8, 1000.00, 'aluguel', 'custo_fixo', '2025-09-13', '2025-09-13 01:31:57'),
(6, 8, 1500.00, 'salario', 'salario', '2025-09-13', '2025-09-13 01:32:08'),
(7, 8, 5000.00, 'compra', 'renda', '2025-09-13', '2025-09-13 01:32:21'),
(8, 5, 10000.00, 'a', 'custo_fixo', '2025-09-22', '2025-09-22 18:58:17'),
(9, 5, 1000.00, 'a', 'custo_variavel', '2025-09-22', '2025-09-22 18:58:29'),
(10, 5, 500000.00, 'a', 'renda', '2025-09-22', '2025-09-22 18:58:38'),
(11, 5, 10000.00, 'a', 'renda', '2025-08-12', '2025-09-23 14:48:30'),
(12, 5, 1000.00, 'a', 'custo_fixo', '2025-08-12', '2025-09-23 14:48:46'),
(13, 5, 120.00, 'gas', 'custo_variavel', '2025-09-23', '2025-09-23 14:56:02'),
(14, 5, 1000.00, 'venda marcia', 'renda', '2025-09-24', '2025-09-24 11:30:57'),
(15, 9, 1000.00, 'Venda pra Marcia', 'renda', '2025-09-30', '2025-09-30 13:21:18'),
(16, 9, 2500.00, 'Venda pro Lucas', 'renda', '2025-09-24', '2025-09-30 13:21:37'),
(17, 9, 100.00, 'Galão de água', 'custo_variavel', '2025-09-30', '2025-09-30 13:21:59'),
(18, 9, 800.00, 'aluguel', 'custo_fixo', '2025-09-16', '2025-09-30 13:22:21'),
(19, 9, 5000.00, 'Venda pro Murylo', 'renda', '2025-08-06', '2025-09-30 13:23:57'),
(20, 9, 800.00, 'aluguel', 'custo_fixo', '2025-08-14', '2025-09-30 13:24:13');

-- --------------------------------------------------------

--
-- Estrutura para tabela `trilha_juridica`
--

CREATE TABLE `trilha_juridica` (
  `id` int(11) NOT NULL,
  `titulo` varchar(200) NOT NULL,
  `descricao` text NOT NULL,
  `ordem` int(11) NOT NULL,
  `link_referencia` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `trilha_juridica`
--

INSERT INTO `trilha_juridica` (`id`, `titulo`, `descricao`, `ordem`, `link_referencia`) VALUES
(1, 'Cadastro MEI', 'Aprenda como se formalizar como Microempreendedor Individual.', 1, 'https://www.gov.br/mei'),
(2, 'Emissão de Notas', 'Saiba como emitir notas fiscais de forma correta.', 2, 'https://www.nfe.fazenda.gov.br'),
(3, 'Obrigações Legais', 'Entenda suas obrigações mensais e anuais.', 3, NULL),
(4, 'Benefícios Previdenciários', 'Descubra os benefícios do INSS para o autônomo.', 4, NULL);

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `tipo` enum('admin','comum') DEFAULT 'comum',
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp(),
  `password_hash` varchar(255) NOT NULL,
  `atividade_profissional` enum('formal','informal') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `nome`, `email`, `senha`, `tipo`, `criado_em`, `password_hash`, `atividade_profissional`) VALUES
(5, 'Nicolas', 'alves.nicolasrinaldi@gmail.com', '', 'admin', '2025-09-12 10:53:57', '$2y$10$ez/FZTh6YYDquaNQvbYhXe6EJEbbasQ3OlgiGUDyC1O5E7cMmy9kK', 'informal'),
(6, 'Marcelo', 'marcelo@marcelo', '', 'comum', '2025-09-12 14:26:42', '$2y$10$sXKZtJBAMebUEh58rskU0OT1lzerp9dPlyWdCZql0WKOftWsTTLgG', 'formal'),
(8, 'Ana Clara', 'anaclara@gmail.com', '', 'comum', '2025-09-13 00:52:24', '$2y$10$N6LZS/HbUzVQf5f8YP7e5eXNZfHHdJOmYeTA8.rs5byRnzP1rVY4a', 'formal'),
(9, 'Informal', 'informal@gmail.com', '', 'comum', '2025-09-30 13:11:03', '$2y$10$lmBjy/abnhZZEkduQnDKeevRcrQKmDHvtzPy7WlF2Dem48Bh0PGNq', 'informal');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `calculadora`
--
ALTER TABLE `calculadora`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Índices de tabela `calculadora_conteudo`
--
ALTER TABLE `calculadora_conteudo`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `calculos`
--
ALTER TABLE `calculos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Índices de tabela `calendar_events`
--
ALTER TABLE `calendar_events`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `home_conteudo`
--
ALTER TABLE `home_conteudo`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `juridico_conteudo`
--
ALTER TABLE `juridico_conteudo`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `juridico_documentos`
--
ALTER TABLE `juridico_documentos`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `juridico_trilhas`
--
ALTER TABLE `juridico_trilhas`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `planilhas`
--
ALTER TABLE `planilhas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Índices de tabela `planilhas_conteudo`
--
ALTER TABLE `planilhas_conteudo`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `registros_financeiros`
--
ALTER TABLE `registros_financeiros`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `trilha_juridica`
--
ALTER TABLE `trilha_juridica`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `calculadora`
--
ALTER TABLE `calculadora`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `calculadora_conteudo`
--
ALTER TABLE `calculadora_conteudo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `calculos`
--
ALTER TABLE `calculos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT de tabela `calendar_events`
--
ALTER TABLE `calendar_events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `home_conteudo`
--
ALTER TABLE `home_conteudo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `juridico_conteudo`
--
ALTER TABLE `juridico_conteudo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `juridico_documentos`
--
ALTER TABLE `juridico_documentos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `juridico_trilhas`
--
ALTER TABLE `juridico_trilhas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT de tabela `planilhas`
--
ALTER TABLE `planilhas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `planilhas_conteudo`
--
ALTER TABLE `planilhas_conteudo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `registros_financeiros`
--
ALTER TABLE `registros_financeiros`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de tabela `trilha_juridica`
--
ALTER TABLE `trilha_juridica`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `calculadora`
--
ALTER TABLE `calculadora`
  ADD CONSTRAINT `calculadora_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `calculos`
--
ALTER TABLE `calculos`
  ADD CONSTRAINT `calculos_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `usuarios` (`id`);

--
-- Restrições para tabelas `planilhas`
--
ALTER TABLE `planilhas`
  ADD CONSTRAINT `planilhas_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
