<?php
session_start();
// get_conteudo.php - Linha 2 corrigida (se estiverem na mesma pasta)
include 'conexao.php';

header('Content-Type: application/json');

if (!isset($_SESSION['tipo']) || $_SESSION['tipo'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'Acesso negado.']);
    exit();
}

$id_pagina = $_GET['id'] ?? '';

if (!empty($id_pagina)) {
    $sql = "SELECT conteudo FROM paginas_conteudo WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id_pagina);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        echo json_encode(['success' => true, 'conteudo' => $row['conteudo']]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Conteúdo não encontrado.']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'ID de página não fornecido.']);
}
?>