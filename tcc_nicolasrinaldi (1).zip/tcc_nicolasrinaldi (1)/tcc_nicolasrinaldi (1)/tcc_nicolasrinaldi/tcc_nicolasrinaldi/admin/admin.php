<?php
// admin.php - VERSÃO FINAL com Menu Padronizado, Abas Internas e Theme Toggle Corrigido.
error_reporting(E_ALL);
ini_set('display_errors', 1);

// CRÍTICO: 1. Inicia a sessão.
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 2. Inclusão de Conexão. (Ajuste o caminho se necessário)
require_once __DIR__ . '/conexao.php'; 

// 3. Detecta ID e tipo do usuário e verifica permissão.
$current_user_id = $_SESSION['user_id'] ?? $_SESSION['usuario_id'] ?? null;
$user_type = $_SESSION['tipo'] ?? $_SESSION['tipo_usuario'] ?? null;

// Se não for admin, redireciona
if (!$current_user_id || $user_type !== 'admin') {
    header("Location: ../login/login.php");
    exit;
}

// Helper: verifica se existe PDO (Mantido para compatibilidade)
function is_pdo() {
    return isset($GLOBALS['pdo']) && $GLOBALS['pdo'] instanceof PDO;
}

/* 4. -------------------- DEFINIÇÃO DAS FUNÇÕES -------------------- */

// Função para buscar todos os usuários (exceto o admin logado)
if (!function_exists('getAllUsers')) {
    function getAllUsers() {
        global $conn, $current_user_id; // Assumindo $conn é sua conexão mysqli
        $users = [];
        if (!isset($conn)) return [];
        // CRÍTICO: Filtra o admin logado para evitar auto-exclusão/edição.
        $sql = "SELECT id, nome, email, tipo AS tipo_usuario FROM usuarios WHERE id != " . intval($current_user_id) . " ORDER BY nome ASC";
        $result = $conn->query($sql);
        if ($result) {
            while ($row = $result->fetch_assoc()) $users[] = $row;
        }
        return $users;
    }
}

// Função para buscar o conteúdo de páginas (Ajustada para PRIORIZAR suas tabelas existentes)
if (!function_exists('getConteudo')) {
    function getConteudo($pagina) {
        global $conn;
        $out = ['titulo' => '', 'conteudo' => ''];
        
        // TENTATIVA 1: BUSCA NAS TABELAS ESPECÍFICAS 
        $map = [
            'home' => ['table' => 'home_conteudo', 'title' => 'home_titulo', 'text' => 'home_paragrafo'],
            'calculadora' => ['table' => 'calculadora_conteudo', 'title' => 'calculadora_titulo', 'text' => 'calculadora_paragrafo'],
            'planilhas' => ['table' => 'planilhas_conteudo', 'title' => 'planilhas_titulo', 'text' => 'planilhas_paragrafo'],
            'juridico_principal' => ['table' => 'juridico_conteudo', 'title' => 'juridico_titulo', 'text' => 'juridico_paragrafo'],
        ];

        if (isset($map[$pagina]) && isset($conn)) {
            $t = $map[$pagina];
            // ID 1 é o padrão para conteúdo principal
            $sql = "SELECT {$t['title']} AS titulo, {$t['text']} AS conteudo FROM {$t['table']} WHERE id = 1 LIMIT 1";
            $res = $conn->query($sql); 
            if ($res && $res->num_rows) return $res->fetch_assoc();
        }

}
}

// Função para buscar trilhas jurídicas (Ajustada para suas tabelas)
if (!function_exists('getTrilhas')) {
    function getTrilhas($tipo = null) {
        global $conn;
        $rows = [];

        if (isset($conn)) {
            // TENTATIVA 1: Tabela juridico_trilhas
            $sql = "SELECT id, titulo, paragrafo, ordem FROM juridico_trilhas ";
            if ($tipo !== null) $sql .= "WHERE status_tipo = ?";
            $sql .= " ORDER BY ordem ASC";

            $stmt = $conn->prepare($sql);
            if ($stmt) {
                if ($tipo !== null) $stmt->bind_param("s", $tipo);
                $stmt->execute();
                $res = $stmt->get_result();
                while ($r = $res->fetch_assoc()) $rows[] = $r;
                $stmt->close();
                if ($rows) return $rows;
            }
            
            // TENTATIVA 2: Fallback para tabela 'trilha_juridica'
            $res = $conn->query("SELECT id, titulo, conteudo AS paragrafo, ordem FROM trilha_juridica ORDER BY ordem ASC");
            if ($res && $res->num_rows) {
                $rows = [];
                while ($r = $res->fetch_assoc()) $rows[] = $r;
                return $rows;
            }
        }

        return [];
    }
}


/* 5. -------------------- AÇÕES (POST) -------------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $paginas_permitidas = ['home', 'calculadora', 'planilhas'];

    // 1. Salvar Conteúdo Geral
    if (isset($_POST['salvar_conteudo'])) {
        $pagina = $_POST['pagina'] ?? '';
        $titulo = $_POST['titulo'] ?? '';
        $conteudo = $_POST['conteudo'] ?? '';
        $ok = false;

        if (!in_array($pagina, $paginas_permitidas)) {
            header("Location: admin.php?tab=conteudo&status=error_invalid_page");
            exit;
        }

        $map = [
            'home' => ['table' => 'home_conteudo', 'title' => 'home_titulo', 'text' => 'home_paragrafo'],
            'calculadora' => ['table' => 'calculadora_conteudo', 'title' => 'calculadora_titulo', 'text' => 'calculadora_paragrafo'],
            'planilhas' => ['table' => 'planilhas_conteudo', 'title' => 'planilhas_titulo', 'text' => 'planilhas_paragrafo'],
        ];

        if(isset($map[$pagina])){
            $t = $map[$pagina];
            $sql = "UPDATE {$t['table']} SET {$t['title']} = ?, {$t['text']} = ? WHERE id = 1";
            $stmt = $conn->prepare($sql);
            if ($stmt) {
                $stmt->bind_param("ss", $titulo, $conteudo); 
                $ok = $stmt->execute();
                $stmt->close();
            }
        }

        // Fallback para a tabela genérica (se existir)
        if (!$ok) {
            $stmt = $conn->prepare("UPDATE conteudos SET titulo = ?, conteudo = ? WHERE pagina = ?");
            if ($stmt) {
                $stmt->bind_param("sss", $titulo, $conteudo, $pagina); 
                $ok = $stmt->execute();
                $stmt->close();
            }
        }

        header("Location: admin.php?tab=conteudo&status=" . ($ok ? "success" : "error"));
        exit;
    }

    // 2. Salvar Conteúdo Jurídico Principal
    if (isset($_POST['salvar_juridico_principal'])) {
        $titulo = $_POST['juridico_titulo'] ?? '';
        $conteudo = $_POST['juridico_conteudo'] ?? '';
        $ok = false;
        
        // Tentativa 1: Update em 'juridico_conteudo'
        $sql1 = "UPDATE juridico_conteudo SET juridico_titulo = ?, juridico_paragrafo = ? WHERE id = 1";
        $stmt1 = $conn->prepare($sql1);
        if ($stmt1) {
            $stmt1->bind_param("ss", $titulo, $conteudo);
            $ok = $stmt1->execute();
            $stmt1->close();
        }

        header("Location: admin.php?tab=juridico&status=" . ($ok ? "success" : "error"));
        exit;
    }

    // 3. Salvar Trilhas (Jurídico)
    if (isset($_POST['salvar_trilha']) && isset($_POST['trilhas']) && is_array($_POST['trilhas'])) {
        $okAll = true;
        foreach ($_POST['trilhas'] as $id => $t) {
            $id = intval($id); 
            $titulo = $t['titulo'] ?? '';
            $conteudo = $t['conteudo'] ?? $t['paragrafo'] ?? '';

            if ($id <= 0) continue; 

            // Prioriza juridico_trilhas, depois trilha_juridica
            $sql1 = "UPDATE juridico_trilhas SET titulo = ?, paragrafo = ? WHERE id = ?";
            $stmt1 = $conn->prepare($sql1);
            if ($stmt1) {
                $stmt1->bind_param("ssi", $titulo, $conteudo, $id);
                $res = $stmt1->execute();
                $stmt1->close();
                if (!$res) $okAll = false;
            } else {
                // Fallback para trilha_juridica
                $sql2 = "UPDATE trilha_juridica SET titulo = ?, conteudo = ? WHERE id = ?";
                $stmt2 = $conn->prepare($sql2);
                if ($stmt2) {
                    $stmt2->bind_param("ssi", $titulo, $conteudo, $id);
                    $res2 = $stmt2->execute();
                    $stmt2->close();
                    if (!$res2) $okAll = false;
                } else { $okAll = false; }
            }
        }

        header("Location: admin.php?tab=juridico&status=" . ($okAll ? "success" : "error"));
        exit;
    }

    // 4. Atualizar Permissões de Usuário
    if (isset($_POST['update_user'])) {
        $id = intval($_POST['id'] ?? 0);
        $tipo_usuario = $_POST['tipo_usuario'] ?? 'user';
        $ok = false;

        if (!in_array($tipo_usuario, ['admin', 'user']) || $id === $current_user_id) {
             header("Location: admin.php?tab=usuarios&status=error_invalid_type_or_self");
             exit;
        }

        $stmt = $conn->prepare("UPDATE usuarios SET tipo = ? WHERE id = ?");
        if ($stmt) {
            $stmt->bind_param("si", $tipo_usuario, $id);
            $ok = $stmt->execute();
            $stmt->close();
        }

        header("Location: admin.php?tab=usuarios&status=" . ($ok ? "success" : "error"));
        exit;
    }

    // 5. Excluir Usuário
    if (isset($_POST['delete_user'])) {
        $id = intval($_POST['id'] ?? 0);
        if ($id === $current_user_id) {
            header("Location: admin.php?tab=usuarios&status=error_self");
            exit;
        }

        $ok = false;
        $stmt = $conn->prepare("DELETE FROM usuarios WHERE id = ?");
        if ($stmt) {
            $stmt->bind_param("i", $id);
            $ok = $stmt->execute();
            $stmt->close();
        }

        header("Location: admin.php?tab=usuarios&status=" . ($ok ? "success" : "error"));
        exit;
    }
}

/* 6. -------------------- BUSCA DE DADOS PARA FRONT -------------------- */
$users = getAllUsers();
$home_conteudo = getConteudo('home');
$calculadora_conteudo = getConteudo('calculadora');
$planilhas_conteudo = getConteudo('planilhas');
$juridico_conteudo = getConteudo('juridico_principal');
$trilhas_informal = getTrilhas('informal');
$trilhas_formal = getTrilhas('formal');

/* -------------------- HTML (minimalista) -------------------- */
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Painel Admin — TCC Rinaldi</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        /* VARIÁVEIS DE TEMA - Baseadas na identidade visual escura */
        :root {
            --sidebar-width-open: 250px;
            --sidebar-width-closed: 60px;
            --bg: #222; /* Fundo principal escuro */
            --panel: #2b2b2b; /* Fundo dos painéis e cards */
            --sidebar-bg: #1a1a1a; /* Fundo da Sidebar, mais escuro */
            --menu-bg: #333;
            --menu-hover-bg: #444;
            --muted: #b0b0b0; /* Texto secundário */
            --accent: #F58A3D; /* Laranja (Cor de Destaque) */
            --text-color: #fff;
            --border-color: #444;
            --box-shadow-color: rgba(245, 138, 61, 0.2); 
            --active-tab-bg: var(--accent);
            --active-tab-text: #fff;
        }

        /* TEMA CLARO (Light Mode) */
        *[data-theme="light"] {
            --bg: #f0f2f5;
            --panel: #fff;
            --sidebar-bg: #f8f9fa;
            --menu-bg: #e9ecef;
            --menu-hover-bg: #dee2e6;
            --muted: #6b6b6b;
            --accent: #F58A3D;
            --text-color: #333;
            --border-color: #dee2e6;
            --box-shadow-color: rgba(0, 0, 0, 0.1);
            --active-tab-bg: var(--accent);
            --active-tab-text: #fff;
        }
        
        /* ESTILOS GERAIS */
        *{box-sizing:border-box}
        body{margin:0;font-family:Arial, sans-serif;background:var(--bg);color:var(--text-color);display:flex;transition: background-color 0.3s ease, color 0.3s ease;}

        /* Sidebar - ESTILO IDÊNTICO AO home.php */
        .sidebar {
            width: var(--sidebar-width-closed);
            background-color: var(--sidebar-bg);
            color: var(--text-color);
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            display: flex;
            flex-direction: column;
            align-items: center; 
            transition: width 0.3s ease-in-out, background-color 0.3s ease;
            z-index: 1000;
            overflow-x: hidden;
            box-shadow: 2px 0 5px var(--box-shadow-color);
        }

        .sidebar:hover {
            width: var(--sidebar-width-open);
        }
        
        .logo {
            padding: 10px 0;
            margin-bottom: 10px;
            white-space: nowrap;
            width: 100%; 
            text-align: center;
            box-sizing: border-box;
        }
        .logo img {
            max-width: 40px; 
            max-height: 40px; 
            height: auto;
            display: block;
            margin: 0 auto;
            object-fit: contain;
            transition: max-height 0.3s ease-in-out, max-width 0.3s ease-in-out;
        }
        .sidebar:hover .logo img {
            max-width: 120%;
            max-height: 120px;
        }

        .menu-list {
            list-style: none;
            padding: 0;
            width: 100%;
        }

        .menu-list li {
            margin-bottom: 5px;
            padding: 0 5px;
        }

        .menu-list a {
            color: var(--text-color);
            text-decoration: none;
            display: flex;
            padding: 15px;
            background-color: var(--menu-bg);
            border-radius: 8px;
            transition: background-color 0.3s ease;
            font-size: 18px;
            align-items: center;
        }
        
        .menu-list a .fas {
            margin-right: 15px;
            color: var(--accent);
            min-width: 25px;
            text-align: center;
        }
        
        .menu-list a span {
            display: inline-block;
            visibility: hidden; 
            opacity: 0;
            white-space: nowrap;
            transition: opacity 0.2s ease, visibility 0.2s ease;
        }

        .sidebar:hover .menu-list a span {
            visibility: visible;
            opacity: 1;
        }

        .menu-list a:hover {
            background-color: var(--menu-hover-bg);
        }
        
        /* Conteúdo Principal */
        .main-content {
            margin-left: var(--sidebar-width-closed);
            padding: 20px;
            flex-grow: 1;
            box-sizing: border-box;
            transition: margin-left 0.3s ease-in-out;
            width: 100%;
        }

        .sidebar:hover ~ .main-content {
            margin-left: var(--sidebar-width-open);
        }
        
        /* Estilos da Página ADMIN */
        h1{margin:0 0 12px;font-size:24px;color:var(--accent);}
        h2{margin:0 0 12px;font-size:20px;color:var(--accent);}
        h3{color:var(--accent);}
        
        /* Abas de Navegação Interna */
        .tab-nav {
            display: flex;
            margin-bottom: 20px;
            border-bottom: 2px solid var(--border-color);
        }
        .tab-nav-item {
            padding: 12px 20px;
            cursor: pointer;
            border-bottom: 2px solid transparent;
            color: var(--muted);
            font-weight: bold;
            transition: all 0.3s;
        }
        .tab-nav-item:hover {
            color: var(--accent);
            border-bottom-color: var(--accent);
        }
        .tab-nav-item.active {
            color: var(--active-tab-text);
            background-color: var(--active-tab-bg);
            border-radius: 8px 8px 0 0;
            border-bottom: 2px solid var(--active-tab-bg);
        }

        /* PAINÉIS/CARDS */
        .panel{background:var(--panel);padding:16px;border-radius:10px;box-shadow:0 0 10px var(--box-shadow-color);margin-bottom:18px;border: 1px solid var(--border-color);}
        
        /* FORMULÁRIOS */
        label{display:block;font-weight:600;margin-top:8px;color:var(--muted)}
        input[type=text],textarea,select{width:100%;padding:10px;margin-top:6px;border:1px solid var(--border-color);border-radius:8px;background:var(--bg);color:var(--text-color)}
        
        /* BOTÕES */
        button{margin-top:12px;padding:10px 14px;background:var(--accent);border:0;border-radius:8px;color:#fff;cursor:pointer;transition:background .15s, box-shadow .15s}
        button:hover{background:#d87a32; box-shadow: 0 0 8px var(--accent);}
        
        /* TABELA DE USUÁRIOS */
        table{width:100%;border-collapse:collapse;margin-top:15px;}
        th,td{padding:12px;border-bottom:1px solid var(--border-color);text-align:left}
        th{color:var(--accent);font-weight:700;}
        
        /* CORES DE TEXTO E STATUS */
        .muted{color:var(--muted);font-size:14px}
        .alert{font-size: 14px; padding: 10px; border-radius: 6px;}
        .alert.success{background-color: #34d399; color: #1a1a1a;}
        .alert.error{background-color: #f87171; color: #1a1a1a;}

        /* Responsividade (Ajustado para o novo layout) */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                width: var(--sidebar-width-open);
            }
            .sidebar.active {
                transform: translateX(0);
            }
            .main-content {
                margin-left: 0;
            }
        }
        
        /* Botão de tema no canto superior direito (Mantido) */
        #theme-toggle {
            position: fixed;
            top: 20px;
            right: 20px;
            background: transparent;
            border: 2px solid var(--accent);
            border-radius: 50%;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-size: 20px;
            color: var(--accent);
            transition: color 0.3s ease, background 0.3s ease, border-color 0.3s ease;
            z-index: 1001;
        }

        #theme-toggle:hover {
            background: var(--accent);
            color: white;
        }
    </style>
</head>
<body data-theme="dark">
    <button id="theme-toggle">
        <i class="fas fa-sun"></i>
    </button>

    <div class="sidebar" id="sidebar">
        <div class="logo">
            <a href="../home/home.php">
                <img src="../boasvindas/LogoTipo Auxtec.png" alt="Logo da Auxtec">
            </a>
        </div>
        <ul class="menu-list">
            <li><a href="../home/home.php"><i class="fas fa-home"></i> <span>Início</span></a></li>
            <li><a href="../perfil/editar_perfil.php"><i class="fas fa-user-circle"></i> <span>Meu Perfil</span></a></li>
            <li><a href="../juridico/juridico.php"><i class="fas fa-gavel"></i> <span>Jurídico</span></a></li>
            <li><a href="../financeiro/financeiro.php"><i class="fas fa-wallet"></i> <span>Financeiro</span></a></li>
            <li><a href="../calculadora/calculadora.php"><i class="fas fa-calculator"></i> <span>Calculadora</span></a></li>
            <li><a href="../planilhas/planilhas.php"><i class="fas fa-file-excel"></i> <span>Minhas Planilhas</span></a></li>
            <li><a href="../calendario/calendario.php"><i class="fas fa-calendar-alt"></i> <span>Calendário</span></a></li>
            <li><a href="../login/logout.php"><i class="fas fa-sign-out-alt"></i> <span>Sair</span></a></li>
            <li><a href="../admin/admin.php" style="background-color: var(--accent);"><i class="fas fa-user-shield" style="color:#fff;"></i> <span>Painel Admin</span></a></li>
        </ul>
    </div>

    <main class="main-content">
        <h1>Painel Administrativo</h1>
        <p class="muted">Gerencie o conteúdo exibido para os usuários e as permissões de acesso.</p>

        <?php if (isset($_GET['status'])): ?>
            <div class="alert <?php echo (strpos($_GET['status'], 'success') !== false) ? 'success' : 'error'; ?>">
                <?php
                $s = $_GET['status'];
                if ($s === 'success' || $s === 'success_content') echo "Ação realizada com sucesso.";
                elseif ($s === 'error_self') echo "Erro: não é possível excluir sua própria conta enquanto logado.";
                elseif ($s === 'error_invalid_page') echo "Erro: Tentativa de alterar uma página não mapeada.";
                elseif ($s === 'error_invalid_type_or_self') echo "Erro: Tipo de usuário inválido ou tentativa de alterar a própria permissão.";
                else echo "Ocorreu um erro ao processar sua solicitação.";
                ?>
            </div>
        <?php endif; ?>

        <div class="tab-nav">
            <div class="tab-nav-item" data-tab="conteudo" onclick="showTab('conteudo')">Conteúdo Geral</div>
            <div class="tab-nav-item" data-tab="juridico" onclick="showTab('juridico')">Conteúdo Jurídico</div>
            <div class="tab-nav-item" data-tab="usuarios" onclick="showTab('usuarios')">Gerenciar Usuários</div>
        </div>
        
        <section id="conteudo" class="tab-content" style="display:none">
            <h2>Edição de Páginas Principais</h2>
            <?php
            $paginas = [
                'home' => ['label' => 'Home (Página Inicial)', 'data' => $home_conteudo],
                'calculadora' => ['label' => 'Calculadora', 'data' => $calculadora_conteudo],
                'planilhas' => ['label' => 'Planilhas', 'data' => $planilhas_conteudo]
            ];
            foreach ($paginas as $pagina => $item):
                $conteudo = $item['data'];
            ?>
                <form method="POST" class="panel" style="margin-bottom:12px">
                    <input type="hidden" name="salvar_conteudo" value="1">
                    <input type="hidden" name="pagina" value="<?php echo htmlspecialchars($pagina); ?>">
                    <label>Título (<?php echo htmlspecialchars($item['label']); ?>)</label>
                    <input type="text" name="titulo" value="<?php echo htmlspecialchars($conteudo['titulo'] ?? ''); ?>" required>
                    <label>Conteúdo</label>
                    <textarea name="conteudo" rows="4" required><?php echo htmlspecialchars($conteudo['conteudo'] ?? $conteudo['paragrafo'] ?? ''); ?></textarea>
                    <button type="submit">Salvar <?php echo htmlspecialchars($item['label']); ?></button>
                </form>
            <?php endforeach; ?>
        </section>

        <section id="juridico" class="tab-content" style="display:none">
            <h2>Edição de Conteúdo Jurídico</h2>

            <form method="POST" class="panel">
                <h3>Principal</h3>
                <input type="hidden" name="salvar_juridico_principal" value="1">
                <label>Título da Página (Jurídico Principal)</label>
                <input type="text" name="juridico_titulo" value="<?php echo htmlspecialchars($juridico_conteudo['titulo'] ?? ''); ?>" required>
                <label>Parágrafo Principal</label>
                <textarea name="juridico_conteudo" rows="4" required><?php echo htmlspecialchars($juridico_conteudo['conteudo'] ?? $juridico_conteudo['paragrafo'] ?? ''); ?></textarea>
                <button type="submit">Salvar Jurídico Principal</button>
            </form>

            <div class="panel">
                <h3>Trilhas</h3>
                <form method="POST">
                    <input type="hidden" name="salvar_trilha" value="1">
                    
                    <h4>Trilhas Informal</h4>
                    <?php if (empty($trilhas_informal)): ?>
                        <p class="muted">Nenhuma trilha informal encontrada.</p>
                    <?php else: foreach ($trilhas_informal as $t): ?>
                        <label style="margin-top:12px">Título (ID: <?php echo intval($t['id']); ?>)</label>
                        <input type="text" name="trilhas[<?php echo $t['id']; ?>][titulo]" value="<?php echo htmlspecialchars($t['titulo'] ?? ''); ?>" required>
                        <label>Parágrafo</label>
                        <textarea name="trilhas[<?php echo $t['id']; ?>][conteudo]" rows="2" required><?php echo htmlspecialchars($t['paragrafo'] ?? $t['conteudo'] ?? ''); ?></textarea>
                    <?php endforeach; endif; ?>
                    
                    <h4 style="margin-top:20px;">Trilhas Formal</h4>
                    <?php if (empty($trilhas_formal)): ?>
                        <p class="muted">Nenhuma trilha formal encontrada.</p>
                    <?php else: foreach ($trilhas_formal as $t): ?>
                        <label style="margin-top:12px">Título (ID: <?php echo intval($t['id']); ?>)</label>
                        <input type="text" name="trilhas[<?php echo $t['id']; ?>][titulo]" value="<?php echo htmlspecialchars($t['titulo'] ?? ''); ?>" required>
                        <label>Parágrafo</label>
                        <textarea name="trilhas[<?php echo $t['id']; ?>][conteudo]" rows="2" required><?php echo htmlspecialchars($t['paragrafo'] ?? $t['conteudo'] ?? ''); ?></textarea>
                    <?php endforeach; endif; ?>

                    <button type="submit">Salvar Todas as Trilhas</button>
                </form>
            </div>
        </section>

        <section id="usuarios" class="tab-content" style="display:none">
            <h2>Gerenciar Usuários</h2>
            <?php if (empty($users)): ?>
                <p class="muted">Nenhum outro usuário encontrado.</p>
            <?php else: ?>
                <div class="panel">
                    <table>
                        <thead>
                            <tr><th>ID</th><th>Nome</th><th>Email</th><th>Permissão</th><th>Ações</th></tr>
                        </thead>
                        <tbody>
                        <?php foreach ($users as $u): ?>
                            <tr>
                                <td><?php echo intval($u['id']); ?></td>
                                <td><?php echo htmlspecialchars($u['nome']); ?></td>
                                <td><?php echo htmlspecialchars($u['email']); ?></td>
                                <td>
                                    <form method="POST" style="display:flex;gap:8px;align-items:center">
                                        <input type="hidden" name="update_user" value="1">
                                        <input type="hidden" name="id" value="<?php echo intval($u['id']); ?>">
                                        <select name="tipo_usuario">
                                            <option value="user" <?php echo ($u['tipo_usuario'] ?? '') === 'user' ? 'selected' : ''; ?>>Usuário</option>
                                            <option value="admin" <?php echo ($u['tipo_usuario'] ?? '') === 'admin' ? 'selected' : ''; ?>>Admin</option>
                                        </select>
                                        <button type="submit">Alterar</button>
                                    </form>
                                </td>
                                <td>
                                    <form method="POST" onsubmit="return confirm('Excluir usuário? A ação é irreversível.');">
                                        <input type="hidden" name="delete_user" value="1">
                                        <input type="hidden" name="id" value="<?php echo intval($u['id']); ?>">
                                        <button type="submit" style="background:#e63; border:0">Excluir</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </section>

    </main>
</div>

<script>
    // Função para mostrar a aba correta
    function showTab(id){
        // Esconde todos os conteúdos de aba
        document.querySelectorAll('.tab-content').forEach(s=>s.style.display='none');
        // Remove a classe 'active' de todos os itens de navegação
        document.querySelectorAll('.tab-nav-item').forEach(item => item.classList.remove('active'));

        // Mostra o conteúdo da aba selecionada
        const el = document.getElementById(id);
        if(el) el.style.display = 'block';

        // Adiciona a classe 'active' ao item de navegação
        const navItem = document.querySelector(`.tab-nav-item[data-tab="${id}"]`);
        if(navItem) navItem.classList.add('active');

        // Atualiza a URL sem recarregar
        history.replaceState(null, null, 'admin.php?tab=' + id);
    }
    
    // Função para alternar entre Dark e Light mode
    function toggleTheme(){
        const html = document.documentElement;
        const currentTheme = html.getAttribute('data-theme');
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        html.setAttribute('data-theme', newTheme);
        localStorage.setItem('theme', newTheme);
        
        // Atualiza o ícone do botão
        const themeToggleBtn = document.getElementById('theme-toggle');
        if (newTheme === 'light') {
            themeToggleBtn.innerHTML = '<i class="fas fa-moon"></i>'; // Se for light, mostra o ícone de lua
        } else {
            themeToggleBtn.innerHTML = '<i class="fas fa-sun"></i>'; // Se for dark, mostra o ícone de sol
        }
    }

    // Inicialização da página e Event Listener
    (function(){
        // 1. Aplica o tema salvo (e define o ícone inicial correto)
        const savedTheme = localStorage.getItem('theme');
        const html = document.documentElement;
        const themeToggleBtn = document.getElementById('theme-toggle');

        if (savedTheme === 'light') {
            html.setAttribute('data-theme', 'light');
            themeToggleBtn.innerHTML = '<i class="fas fa-moon"></i>'; 
        } else {
            // Padrão ou 'dark'
            html.setAttribute('data-theme', 'dark');
            themeToggleBtn.innerHTML = '<i class="fas fa-sun"></i>'; 
        }

        // 2. Adiciona o evento de clique ao botão! (CRÍTICO)
        themeToggleBtn.addEventListener('click', toggleTheme);
        
        // 3. Determina qual aba abrir
        const params = new URLSearchParams(location.search);
        const tab = params.get('tab');
        if(tab) showTab(tab);
        else showTab('conteudo'); 
    })();
</script>
</body>
</html>