<?php
// Garantir que a sessão seja iniciada apenas UMA vez
if (session_status() === PHP_SESSION_NONE) {
session_start();
}

// Configurações do banco de dados
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "tcc_rinaldi"; 

// Criar conexão
$conn = new mysqli($host, $user, $pass, $dbname);

// Verificar conexão
if ($conn->connect_error) {
die("Erro na conexão: " . $conn->connect_error);
}
?>