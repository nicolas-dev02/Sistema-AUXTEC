<?php
// Ativa a exibição de erros para diagnóstico
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

// Garante que o caminho para o seu arquivo de conexão (db.php) está correto.
include("../config/db.php");

// Garante que o usuário está logado
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login/login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$tipo_usuario = $_SESSION['tipo'] ?? 'comum'; // Garante que tipo_usuario tem um valor padrão

// Lógica para adicionar, editar e excluir eventos
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'add_event') {
        $title = trim($_POST['title']);
        $description = trim($_POST['description']);
        $event_date = $_POST['event_date'];
        $importance = $_POST['importance'];

        if (!empty($title) && !empty($event_date) && !empty($importance)) {
            $sql = "INSERT INTO `calendar_events` (`user_id`, `title`, `description`, `event_date`, `importance`) VALUES (?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("issss", $user_id, $title, $description, $event_date, $importance);
            $stmt->execute();
            $stmt->close();
        }
    } elseif ($_POST['action'] === 'edit_event') {
        $event_id = $_POST['event_id'];
        $title = trim($_POST['title']);
        $description = trim($_POST['description']);
        $importance = $_POST['importance'];

        if (!empty($title) && !empty($importance)) {
            $sql = "UPDATE `calendar_events` SET `title` = ?, `description` = ?, `importance` = ? WHERE `id` = ? AND `user_id` = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sssii", $title, $description, $importance, $event_id, $user_id);
            $stmt->execute();
            $stmt->close();
        }
    } elseif ($_POST['action'] === 'delete_event') {
        $event_id = $_POST['event_id'];
        $sql = "DELETE FROM `calendar_events` WHERE `id` = ? AND `user_id` = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ii", $event_id, $user_id);
        $stmt->execute();
        $stmt->close();
    }
    // Redireciona para evitar reenvio do formulário e recarrega a página
    header("Location: calendario.php");
    exit();
}

// Lógica para buscar os eventos do usuário
$events = [];
$sql = "SELECT id, title, description, event_date, importance FROM `calendar_events` WHERE `user_id` = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $events[] = $row;
}
$stmt->close();

// Lógica para as notificações (eventos de hoje e amanhã)
$today = date('Y-m-d');
$tomorrow = date('Y-m-d', strtotime('+1 day'));
$notification_count = 0;
$notifications = [];

foreach ($events as $event) {
    if ($event['event_date'] == $today || $event['event_date'] == $tomorrow) {
        $notifications[] = [
            'title' => $event['title'],
            'date' => $event['event_date'],
            'description' => $event['description']
        ];
        $notification_count++;
    }
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calendário - TCC Rinaldi</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;700&display=swap" rel="stylesheet">
    
    <style>
        /* Variáveis de Tema */
        :root {
            --sidebar-width-open: 250px;
            --sidebar-width-closed: 60px;

            /* Variáveis para cores do tema escuro (padrão) */
            --bg-color: #222;
            --text-color: #fff;
            --card-bg: #2b2b2b;
            --sidebar-bg: #1a1a1a;
            --menu-bg: #333;
            --menu-hover-bg: #444;
            --accent-primary: #F58A3D; /* Laranja principal */
            --border-color: #444;
            --box-shadow-color: rgba(0, 0, 0, 0.3);
            
            /* Cores de status */
            --status-positive: #34d399; /* Verde */
            --status-attention: #F5A623; /* Amarelo */
            --status-negative: #f87171; /* Vermelho */
        }

        /* Variáveis para cores do tema claro */
        body.light-mode {
            --bg-color: #f0f2f5;
            --text-color: #333;
            --card-bg: #fff;
            --sidebar-bg: #f8f9fa;
            --menu-bg: #e9ecef;
            --menu-hover-bg: #dee2e6;
            --accent-primary: #F58A3D;
            --border-color: #dee2e6;
            --box-shadow-color: rgba(0, 0, 0, 0.1);
        }

        /* Estilos do body e transições */
        body {
            background-color: var(--bg-color);
            color: var(--text-color);
            font-family: 'Open Sans', sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            min-height: 100vh;
            transition: background-color 0.3s ease, color 0.3s ease;
        }

        /* --- Estilos do Menu Lateral (Sidebar) --- */

        .sidebar {
            width: var(--sidebar-width-closed);
            background-color: var(--sidebar-bg);
            color: var(--text-color);
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            display: flex;
            flex-direction: column;
            align-items: center; 
            transition: width 0.3s ease-in-out, background-color 0.3s ease;
            z-index: 1000;
            overflow-x: hidden;
            box-shadow: 2px 0 5px var(--box-shadow-color);
        }

        .sidebar:hover {
            width: var(--sidebar-width-open);
        }

        .logo {
            padding: 10px 0;
            margin-bottom: 10px;
            white-space: nowrap;
            opacity: 1; 
            width: 100%; 
            text-align: center;
            box-sizing: border-box;
        }

        .logo img {
            max-width: 40px; 
            max-height: 40px; 
            height: auto;
            display: block;
            margin: 0 auto;
            object-fit: contain;
            transition: max-height 0.3s ease-in-out, max-width 0.3s ease-in-out;
        }
        
        /* Simulação do logo (substitua pela imagem real) */
        .logo a {
            font-size: 24px;
            text-decoration: none;
            color: var(--accent-primary);
        }
        
        .menu-list {
            list-style: none;
            padding: 0;
            width: 100%;
        }

        .menu-list li {
            margin-bottom: 5px;
            padding: 0 5px;
        }

        .menu-list a {
            color: var(--text-color);
            text-decoration: none;
            display: flex;
            padding: 15px;
            background-color: var(--menu-bg);
            border-radius: 8px;
            transition: background-color 0.3s ease;
            font-size: 18px;
            align-items: center;
        }

        .menu-list a .fas {
            margin-right: 15px;
            color: var(--accent-primary);
            min-width: 25px;
            text-align: center;
        }

        .menu-list a span {
            display: inline-block;
            visibility: hidden; 
            opacity: 0;
            white-space: nowrap;
            transition: opacity 0.2s ease, visibility 0.2s ease;
        }

        .sidebar:hover .menu-list a span {
            visibility: visible;
            opacity: 1;
        }

        .menu-list a:hover {
            background-color: var(--menu-hover-bg);
        }

        /* --- Conteúdo Principal (Ajustes CRUCIAIS) --- */
        .main-content {
            margin-left: var(--sidebar-width-closed);
            padding: 20px;
            flex-grow: 1;
            box-sizing: border-box;
            transition: margin-left 0.3s ease-in-out;
            /* Garante que ocupe exatamente o espaço restante e evita que o calendário vaze */
            width: calc(100% - var(--sidebar-width-closed)); 
            overflow-x: hidden; 
        }

        .sidebar:hover ~ .main-content {
            margin-left: var(--sidebar-width-open);
            width: calc(100% - var(--sidebar-width-open));
        }

        /* Botão de tema no canto superior direito */
        #theme-toggle {
            position: fixed;
            top: 20px;
            right: 20px;
            background: transparent;
            border: 2px solid var(--accent-primary);
            border-radius: 50%;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-size: 20px;
            color: var(--accent-primary);
            transition: color 0.3s ease, background 0.3s ease, border-color 0.3s ease;
            z-index: 1001;
        }

        #theme-toggle:hover {
            background: var(--accent-primary);
            color: white;
        }
        
        /* Botão de Toggle para Mobile */
        .menu-toggle {
            display: none; /* Esconde no desktop */
            position: fixed;
            top: 20px;
            left: 20px;
            z-index: 1002;
            background: var(--accent-primary);
            color: white;
            padding: 10px;
            border-radius: 5px;
            cursor: pointer;
        }

        /* Media Queries para Responsividade (Mobile) */
        @media (max-width: 768px) {
            .menu-toggle {
                display: block;
            }
            
            .sidebar {
                width: 0;
                transform: translateX(-100%);
                transition: transform 0.3s ease-in-out, width 0.3s ease-in-out;
            }
            
            .sidebar.active {
                width: var(--sidebar-width-open);
                transform: translateX(0);
            }
            
            .sidebar:hover {
                width: 0;
            }

            .main-content {
                margin-left: 0;
                padding-top: 60px;
                width: 100%; /* Ocupa toda a largura em mobile */
            }
            
            .sidebar:hover ~ .main-content {
                margin-left: 0;
                width: 100%;
            }
        }
        
        /* --- ESTILOS ESPECÍFICOS DO CALENDÁRIO --- */
        
        .calendar-container {
            background-color: var(--card-bg); 
            color: var(--text-color); 
            padding: 2rem;
            border-radius: 12px;
            box-shadow: 0 4px 15px var(--box-shadow-color); 
            max-width: 900px;
            margin: 0 auto;
            transition: background-color 0.3s, box-shadow 0.3s;
        }

        /* Melhoria do Calendário Header */
        .calendar-header {
            display: flex; /* Permite alinhamento horizontal */
            justify-content: space-between; /* Espaçamento igual entre os elementos */
            align-items: center; /* Alinha verticalmente */
            margin-bottom: 20px;
            padding: 0 10px; 
        }

        .calendar-header h2 {
            font-size: 1.8rem;
            font-weight: 700;
            margin: 0;
            text-transform: capitalize; 
        }

        .calendar-header button {
            background-color: var(--accent-primary);
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 6px;
            cursor: pointer;
            font-weight: bold;
            transition: background-color 0.2s;
            min-width: 90px; 
            text-transform: uppercase;
            font-size: 0.8rem;
        }

        .calendar-header button:hover {
            background-color: #e67627; 
        }


        /* Melhoria do Sino de Notificações */
        .notification-icon-container {
            position: fixed;
            top: 25px; 
            right: 70px; 
            z-index: 1000;
        }
        
        .notification-icon {
            position: relative; 
            cursor: pointer;
            padding: 5px; 
        }
        
        .notification-badge {
            position: absolute;
            top: -5px; 
            right: -5px;
            background-color: var(--status-negative); 
            color: white;
            border-radius: 50%;
            padding: 2px 6px;
            font-size: 10px;
            font-weight: bold;
            line-height: 1;
            border: 1px solid var(--card-bg); 
        }
        
        .notification-list {
            display: none; /* Inicia oculto */
            position: absolute;
            top: 50px; /* Posiciona abaixo do sino */
            right: 0;
            width: 300px;
            max-height: 400px;
            overflow-y: auto;
            background-color: var(--menu-bg); 
            box-shadow: 0 4px 12px var(--box-shadow-color); 
            border-radius: 8px;
            padding: 10px;
        }

        .notification-list.visible {
            display: block; /* Mostra ao clicar */
        }
        

        /* Layout do calendário em si (grid) */
        .calendar-grid {
            display: grid;
            grid-template-columns: repeat(7, 1fr);
            gap: 10px; /* Espaçamento entre os dias */
            margin-top: 15px;
        }
        
        .weekdays {
            display: grid;
            grid-template-columns: repeat(7, 1fr);
            text-align: center;
            font-weight: bold;
            padding-bottom: 10px;
            border-bottom: 2px solid var(--border-color);
        }

        .day {
            background-color: var(--menu-bg); 
            color: var(--text-color); 
            padding: 15px 5px;
            border-radius: 8px;
            min-height: 80px; /* Garante que o dia tenha altura para eventos */
            cursor: pointer;
            position: relative;
            text-align: right;
            box-shadow: 0 2px 5px var(--box-shadow-color); 
            transition: background-color 0.2s, border-color 0.2s; 
        }

        .day-number {
            font-size: 1.2em;
            font-weight: bold;
            display: block;
            margin-bottom: 5px;
            padding-right: 5px;
        }
        
        .day:hover {
            background-color: var(--menu-hover-bg); 
        }

        .day.inactive {
            background-color: var(--bg-color); 
            color: var(--border-color); 
            cursor: default;
        }
        
        .day.inactive:hover {
            background-color: var(--bg-color);
        }
        
        .day.today {
            border: 2px solid var(--accent-primary);
        }

        /* Estilos para eventos */
        .event-dot {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            margin: 2px auto 0;
            display: block; 
        }
        .event-dot.verde { background-color: var(--status-positive); }
        .event-dot.amarelo { background-color: var(--status-attention); }
        .event-dot.vermelho { background-color: var(--status-negative); }
        
        /* Borda de importância no dia (para quando há eventos) */
        .day.has-event {
            border-width: 3px;
            border-style: solid;
            padding: 12px 2px; 
        }
        .day.verde { border-color: var(--status-positive); }
        .day.amarelo { border-color: var(--status-attention); }
        .day.vermelho { border-color: var(--status-negative); }

        /* Modal */
        .modal {
            display: none; 
            position: fixed; 
            z-index: 1010; 
            left: 0;
            top: 0;
            width: 100%; 
            height: 100%; 
            overflow: auto; 
            background-color: rgba(0,0,0,0.7); 
        }

        .modal.visible {
            display: block;
        }

        .modal-content {
            background-color: var(--card-bg); 
            margin: 15% auto; 
            padding: 20px;
            border-radius: 10px;
            width: 80%; 
            max-width: 500px;
            position: relative;
            box-shadow: 0 5px 15px var(--box-shadow-color);
        }

        .close-button {
            color: var(--text-color);
            float: right;
            font-size: 28px;
            font-weight: bold;
            background: none;
            border: none;
            cursor: pointer;
        }
        .close-button:hover,
        .close-button:focus {
            color: var(--accent-primary);
            text-decoration: none;
            cursor: pointer;
        }
        
        /* Estilos de Formulário (Modal) */
        .event-form label, #modal-body label {
            display: block;
            margin-top: 10px;
            margin-bottom: 5px;
            font-weight: bold;
        }
        
        .event-form input[type="text"], 
        .event-form textarea, 
        .event-form select,
        #modal-body input[type="text"],
        #modal-body textarea,
        #modal-body select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid var(--border-color); 
            background-color: var(--bg-color); 
            color: var(--text-color);
            border-radius: 4px;
            box-sizing: border-box;
        }

        .importance-options label {
            display: inline-block;
            margin-right: 15px;
            font-weight: normal;
        }
        
        .form-buttons, .modal-buttons {
            margin-top: 20px;
            text-align: right;
        }
        
        .form-buttons button, .modal-buttons button {
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: bold;
            transition: all 0.2s;
            margin-left: 10px;
        }

        .form-buttons button[type="submit"], .modal-buttons .btn-primary {
            background-color: var(--accent-primary);
            color: white;
        }
        .form-buttons button[type="submit"]:hover, .modal-buttons .btn-primary:hover {
            background-color: #e67627;
        }
        
        .modal-buttons .edit-btn, .modal-buttons .cancel-btn { 
            background-color: var(--menu-bg); 
            color: var(--text-color);
            border: 1px solid var(--border-color);
        }
        
        .modal-buttons .delete-btn {
            background-color: var(--status-negative);
            color: white;
        }
        .modal-buttons .delete-btn:hover {
            background-color: #c54a4a;
        }

        /* Estilos de visualização de evento */
        .event-details {
            padding: 10px;
            border: 1px solid var(--border-color);
            border-radius: 5px;
            margin-bottom: 10px;
        }
        .importance-label.verde { color: var(--status-positive); }
        .importance-label.amarelo { color: var(--status-attention); }
        .importance-label.vermelho { color: var(--status-negative); }

    </style>
</head>
<body>
    
    <button id="theme-toggle">
        <i class="fas fa-sun"></i>
    </button>

    <div class="menu-toggle" onclick="toggleMenu()">
        <i class="fas fa-bars"></i>
    </div>
    
    <div class="sidebar" id="sidebar">
        <div class="logo">
            <a href="../home/home.php">
                <img src="../boasvindas/LogoTipo Auxtec.png" alt="Logo da Auxtec">
            </a>
        </div>
        <ul class="menu-list">
            <li><a href="../home/home.php"><i class="fas fa-home"></i> <span>Início</span></a></li>
            <li><a href="../perfil/editar_perfil.php"><i class="fas fa-user-circle"></i> <span>Meu Perfil</span></a></li>
            <li><a href="../juridico/juridico.php"><i class="fas fa-gavel"></i> <span>Jurídico</span></a></li>
            <li><a href="../financeiro/financeiro.php"><i class="fas fa-wallet"></i> <span>Financeiro</span></a></li>
            <li><a href="../calculadora/calculadora.php"><i class="fas fa-calculator"></i> <span>Calculadora</span></a></li>
            <li><a href="../planilhas/planilhas.php"><i class="fas fa-file-excel"></i> <span>Minhas Planilhas</span></a></li>
            <li><a href="../calendario/calendario.php"><i class="fas fa-calendar-alt"></i> <span>Calendário</span></a></li>
            <li><a href="../login/logout.php"><i class="fas fa-sign-out-alt"></i> <span>Sair</span></a></li>
            <?php if ($tipo_usuario == 'admin'): ?>
                <li><a href="../admin/admin.php"><i class="fas fa-user-shield"></i> <span>Painel Admin</span></a></li>
            <?php endif; ?>
        </ul>
    </div>

    <div class="main-content">
        <div class="notification-icon-container">
            <div class="notification-icon" onclick="toggleNotifications()">
                <i class="fas fa-bell" style="font-size: 30px; color: var(--text-color);"></i>
                <?php if ($notification_count > 0): ?>
                    <span class="notification-badge"><?php echo $notification_count; ?></span>
                <?php endif; ?>
            </div>
            <div class="notification-list" id="notification-list">
                <?php if (count($notifications) > 0): ?>
                    <?php foreach ($notifications as $note): ?>
                        <div class="notification-item">
                            <div class="notification-title"><?php echo htmlspecialchars($note['title']); ?></div>
                            <div class="notification-date"><?php echo ($note['date'] == $today) ? 'Hoje' : 'Amanhã'; ?></div>
                            <div class="notification-description"><?php echo htmlspecialchars($note['description']); ?></div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="notification-item">Nenhuma notificação por enquanto.</div>
                <?php endif; ?>
            </div>
        </div>

        <div class="calendar-container">
            <div class="calendar-header">
                <button id="prev-month">Anterior</button>
                <h2 id="current-month-year"></h2>
                <button id="next-month">Próximo</button>
            </div>
            <div class="weekdays">
                <div>Dom</div>
                <div>Seg</div>
                <div>Ter</div>
                <div>Qua</div>
                <div>Qui</div>
                <div>Sex</div>
                <div>Sáb</div>
            </div>
            <div class="calendar-grid" id="calendar-grid"></div>
        </div>
    </div>

    <div id="event-modal" class="modal">
        <div class="modal-content">
            <button class="close-button" onclick="closeModal()">&times;</button>
            <div id="modal-body"></div>
        </div>
    </div>

    <script>
        // Função para abrir e fechar o menu lateral (usada no botão de mobile)
        function toggleMenu() {
            var sidebar = document.getElementById("sidebar");
            sidebar.classList.toggle("active");
        }
        
        document.addEventListener('DOMContentLoaded', () => {
            const body = document.body;
            const themeToggleBtn = document.getElementById('theme-toggle');
            
            // --- LÓGICA DO TEMA ---
            
            // 1. Pega o tema salvo e aplica
            const savedTheme = localStorage.getItem('theme');
            if (savedTheme === 'light') {
                body.classList.add('light-mode');
                themeToggleBtn.innerHTML = '<i class="fas fa-moon"></i>';
            } else {
                // Tema escuro padrão
                themeToggleBtn.innerHTML = '<i class="fas fa-sun"></i>';
            }

            // 2. Listener para alternar o tema ao clicar
            themeToggleBtn.addEventListener('click', () => {
                body.classList.toggle('light-mode');

                if (body.classList.contains('light-mode')) {
                    localStorage.setItem('theme', 'light');
                    themeToggleBtn.innerHTML = '<i class="fas fa-moon"></i>';
                } else {
                    localStorage.setItem('theme', 'dark');
                    themeToggleBtn.innerHTML = '<i class="fas fa-sun"></i>';
                }
            });
            
            // --- LÓGICA DO CALENDÁRIO EXISTENTE ---
            
            const calendarGrid = document.getElementById('calendar-grid');
            const currentMonthYear = document.getElementById('current-month-year');
            const prevMonthBtn = document.getElementById('prev-month');
            const nextMonthBtn = document.getElementById('next-month');
            const eventModal = document.getElementById('event-modal');
            const modalBody = document.getElementById('modal-body');
            const notificationList = document.getElementById('notification-list');
            const events = <?php echo json_encode($events); ?>;

            let currentDate = new Date();

            const renderCalendar = () => {
                const year = currentDate.getFullYear();
                const month = currentDate.getMonth();

                const firstDayOfMonth = new Date(year, month, 1).getDay();
                const lastDateOfMonth = new Date(year, month + 1, 0).getDate();
                const lastDateOfLastMonth = new Date(year, month, 0).getDate();

                currentMonthYear.textContent = new Intl.DateTimeFormat('pt-BR', { month: 'long', year: 'numeric' }).format(currentDate);
                calendarGrid.innerHTML = '';

                // Renderiza dias do mês anterior
                for (let i = firstDayOfMonth; i > 0; i--) {
                    const day = document.createElement('div');
                    day.classList.add('day', 'inactive');
                    
                    // Adiciona o número do dia dentro de um span para manter o estilo
                    const dayNumber = document.createElement('span');
                    dayNumber.classList.add('day-number');
                    dayNumber.textContent = lastDateOfLastMonth - i + 1;
                    day.appendChild(dayNumber);
                    
                    calendarGrid.appendChild(day);
                }

                // Renderiza dias do mês atual
                for (let i = 1; i <= lastDateOfMonth; i++) {
                    const day = document.createElement('div');
                    day.classList.add('day');
                    const dayFormatted = `${year}-${String(month + 1).padStart(2, '0')}-${String(i).padStart(2, '0')}`;
                    day.dataset.date = dayFormatted;

                    const today = new Date();
                    if (i === today.getDate() && month === today.getMonth() && year === today.getFullYear()) {
                        day.classList.add('today');
                    }
                    
                    const dayEvents = events.filter(event => event.event_date === dayFormatted);
                    
                    const dayNumber = document.createElement('span');
                    dayNumber.classList.add('day-number');
                    dayNumber.textContent = i;
                    day.appendChild(dayNumber);

                    // Adiciona indicadores de evento
                    dayEvents.forEach(event => {
                        const eventDot = document.createElement('div');
                        eventDot.classList.add('event-dot', event.importance);
                        day.appendChild(eventDot);
                    });

                    if (dayEvents.length > 0) {
                        // Classifica a importância (vermelho > amarelo > verde) para borda
                        let maxImportance = dayEvents.reduce((max, event) => {
                            const priorities = { 'vermelho': 3, 'amarelo': 2, 'verde': 1 };
                            return (priorities[event.importance] || 0) > (priorities[max] || 0) ? event.importance : max;
                        }, 'verde');
                        
                        day.classList.add('has-event', maxImportance);
                        day.onclick = () => showEvents(dayFormatted, dayEvents);
                    } else {
                        day.onclick = () => addEvent(dayFormatted);
                    }
                    calendarGrid.appendChild(day);
                }

                // Renderiza dias do próximo mês (preencher a grade)
                const totalDays = firstDayOfMonth + lastDateOfMonth;
                const nextDays = (Math.ceil(totalDays / 7) * 7) - totalDays;
                for (let i = 1; i <= nextDays; i++) {
                    const day = document.createElement('div');
                    day.classList.add('day', 'inactive');
                    
                    // Adiciona o número do dia dentro de um span para manter o estilo
                    const dayNumber = document.createElement('span');
                    dayNumber.classList.add('day-number');
                    dayNumber.textContent = i;
                    day.appendChild(dayNumber);
                    
                    calendarGrid.appendChild(day);
                }
            };

            prevMonthBtn.addEventListener('click', () => {
                currentDate.setMonth(currentDate.getMonth() - 1);
                renderCalendar();
            });

            nextMonthBtn.addEventListener('click', () => {
                currentDate.setMonth(currentDate.getMonth() + 1);
                renderCalendar();
            });

            // CORREÇÃO FINAL: Função showEvents revisada para corrigir o botão de edição de forma robusta
            const showEvents = (date, events) => {
                let html = '<h3>Eventos em ' + new Date(date + 'T12:00:00').toLocaleDateString('pt-BR') + '</h3>';
                events.forEach(event => {
                    // Prepara os dados para serem passados via URL/JS (usando PHP para urlencode)
                    // Nota: O urlencode precisa ser feito aqui, no PHP, antes de ser enviado para o JS.
                    const safeTitleForJS = encodeURIComponent(event.title);
                    const safeDescriptionForJS = encodeURIComponent(event.description);
                    
                    html += `
                        <div class="event-details">
                            <p><strong>Título:</strong> ${event.title}</p>
                            <p><strong>Descrição:</strong> ${event.description}</p>
                            <p><strong>Importância:</strong> <span class="importance-label ${event.importance}">${event.importance.charAt(0).toUpperCase() + event.importance.slice(1)}</span></p>
                            <div class="modal-buttons" style="text-align: left;">
                                <button class="edit-btn" onclick="editEvent(${event.id}, decodeURIComponent('${safeTitleForJS}'), decodeURIComponent('${safeDescriptionForJS}'), '${event.importance}', '${event.event_date}')">Editar</button>
                                <form method="POST" action="calendario.php" style="display:inline;" onsubmit="return confirm('Tem certeza que deseja excluir este evento?');">
                                    <input type="hidden" name="action" value="delete_event">
                                    <input type="hidden" name="event_id" value="${event.id}">
                                    <button type="submit" class="delete-btn">Excluir</button>
                                </form>
                            </div>
                        </div>
                        <hr style="margin: 15px 0; border: none; border-top: 1px solid var(--border-color);">
                    `;
                });
                html += `<div class="modal-buttons" style="text-align: right;"><button type="button" class="btn-primary" onclick="addEvent('${date}')">Adicionar Mais um</button></div>`;
                modalBody.innerHTML = html;
                eventModal.classList.add('visible');
            };
            // Fim da Correção Final

            window.addEvent = (date) => {
                const html = `
                    <h3>Adicionar Evento</h3>
                    <form id="event-form" method="POST" action="calendario.php">
                        <input type="hidden" name="action" value="add_event">
                        <input type="hidden" name="event_date" value="${date}">
                        <label for="event-title">Título:</label>
                        <input type="text" id="event-title" name="title" required>
                        <label for="event-description">Descrição:</label>
                        <textarea id="event-description" name="description"></textarea>
                        <label>Importância:</label>
                        <div class="importance-options">
                            <label><input type="radio" name="importance" value="verde" required> Verde</label>
                            <label><input type="radio" name="importance" value="amarelo"> Amarelo</label>
                            <label><input type="radio" name="importance" value="vermelho"> Vermelho</label>
                        </div>
                        <div class="form-buttons">
                            <button type="submit">Adicionar</button>
                        </div>
                    </form>
                `;
                modalBody.innerHTML = html;
                eventModal.classList.add('visible');
            };

            window.editEvent = (id, title, description, importance, date) => {
                // Ao receber os dados, eles já estão decodificados, basta preencher o formulário
                const html = `
                    <h3>Editar Evento</h3>
                    <form id="edit-form" method="POST" action="calendario.php">
                        <input type="hidden" name="action" value="edit_event">
                        <input type="hidden" name="event_id" value="${id}">
                        <input type="hidden" name="event_date" value="${date}">
                        <label for="edit-title">Título:</label>
                        <input type="text" id="edit-title" name="title" value="${title}" required>
                        <label for="edit-description">Descrição:</label>
                        <textarea id="edit-description" name="description">${description}</textarea>
                        <label>Importância:</label>
                        <div class="importance-options">
                            <label><input type="radio" name="importance" value="verde" ${importance === 'verde' ? 'checked' : ''} required> Verde</label>
                            <label><input type="radio" name="importance" value="amarelo" ${importance === 'amarelo' ? 'checked' : ''}> Amarelo</label>
                            <label><input type="radio" name="importance" value="vermelho" ${importance === 'vermelho' ? 'checked' : ''}> Vermelho</label>
                        </div>
                        <div class="form-buttons">
                            <button type="submit">Salvar</button>
                            <button type="button" class="cancel-btn" onclick="closeModal()">Cancelar</button>
                        </div>
                    </form>
                `;
                modalBody.innerHTML = html;
                eventModal.classList.add('visible');
            };

            window.closeModal = () => {
                eventModal.classList.remove('visible');
            };

            window.onclick = (event) => {
                if (event.target === eventModal) {
                    closeModal();
                }
            };
            
            window.toggleNotifications = () => {
                notificationList.classList.toggle('visible');
            };

            renderCalendar();
        });
    </script>
</body>
</html>