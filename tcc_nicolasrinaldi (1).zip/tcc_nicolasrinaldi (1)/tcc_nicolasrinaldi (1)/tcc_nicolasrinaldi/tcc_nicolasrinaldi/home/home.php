<?php
// Ativa a exibição de erros para diagnóstico
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
include("../config/db.php");

// Se não estiver logado, redireciona
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login/login.php");
    exit();
}

$message = '';
$nomeUsuario = "Usuário";
$tipo = $_SESSION['tipo'] ?? 'comum';

// Pega nome do usuário no banco
$sql = "SELECT nome FROM usuarios WHERE id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$result = $stmt->get_result();
if ($row = $result->fetch_assoc()) {
    $nomeUsuario = $row['nome'];
}

// Lógica para carregar o conteúdo do banco de dados, buscando sempre o registro com ID 1
$home_content = null;
$sql_content = "SELECT * FROM home_conteudo WHERE id = 1";

if ($result_content = $conn->query($sql_content)) {
    $home_content = $result_content->fetch_assoc();
} else {
    $message = '<div class="alert error">Erro ao carregar o conteúdo: ' . $conn->error . '</div>';
}

$home_titulo = $home_content['home_titulo'] ?? "Bem-vindo, " . $nomeUsuario . "!";
$home_paragrafo = $home_content['home_paragrafo'] ?? "Sistema de apoio financeiro e jurídico para trabalhadores autônomos.";
$card1_titulo = $home_content['card1_titulo'] ?? "📊 Calculadora";
$card1_paragrafo = $home_content['card1_paragrafo'] ?? "Simule ganhos, custos e organize sua vida financeira.";
$card2_titulo = $home_content['card2_titulo'] ?? "📂 Planilhas";
$card2_paragrafo = $home_content['card2_paragrafo'] ?? "Baixe planilhas de controle personalizadas para sua rotina.";
$card3_titulo = $home_content['card3_titulo'] ?? "⚖️ Trilha Jurídica";
$card3_paragrafo = $home_content['card3_paragrafo'] ?? "Entenda obrigações legais e acesse documentos importantes.";
$card4_titulo = $home_content['card4_titulo'] ?? "💰 Financeiro";
$card4_paragrafo = $home_content['card4_paragrafo'] ?? "Registre seus gastos e receitas para uma gestão completa.";
$card5_titulo = "🗓️ Calendário";
$card5_paragrafo = "Organize seus compromissos e lembretes para não perder nenhuma data importante.";

if (empty($message) && isset($_GET['status'])) {
    if ($_GET['status'] == 'success_content') {
        $message = '<div class="alert success">Conteúdo salvo com sucesso!</div>';
    } elseif ($_GET['status'] == 'error_content') {
        $message = '<div class="alert error">Erro ao salvar o conteúdo.</div>';
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Home - TCC Rinaldi</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        :root {
            --sidebar-width-open: 250px;
            --sidebar-width-closed: 60px;

            /* Variáveis para cores do tema escuro (padrão) */
            --bg-color: #222;
            --text-color: #fff;
            --card-bg: #2b2b2b;
            --sidebar-bg: #1a1a1a;
            --menu-bg: #333;
            --menu-hover-bg: #444;
            --accent-color: #F58A3D;
            --border-color: #444;
            --box-shadow-color: rgba(0, 0, 0, 0.3);
        }

        /* Variáveis para cores do tema claro */
        body.light-mode {
            --bg-color: #f0f2f5;
            --text-color: #333;
            --card-bg: #fff;
            --sidebar-bg: #f8f9fa;
            --menu-bg: #e9ecef;
            --menu-hover-bg: #dee2e6;
            --accent-color: #F58A3D; /* Laranja da paleta */
            --border-color: #dee2e6;
            --box-shadow-color: rgba(0, 0, 0, 0.1);
        }

        /* Estilos do body e transições */
        body {
            background-color: var(--bg-color);
            color: var(--text-color);
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            transition: background-color 0.3s ease, color 0.3s ease;
        }

        /* Menu Lateral (Sidebar) com efeito hover */
        .sidebar {
            width: var(--sidebar-width-closed);
            background-color: var(--sidebar-bg);
            color: var(--text-color);
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            display: flex;
            flex-direction: column;
            align-items: center; 
            transition: width 0.3s ease-in-out, background-color 0.3s ease;
            z-index: 1000;
            overflow-x: hidden;
            box-shadow: 2px 0 5px var(--box-shadow-color); /* Adicionado sombra para destaque */
        }

        .sidebar:hover {
            width: var(--sidebar-width-open);
        }

        /* INÍCIO DA CORREÇÃO DO LOGO */
        .logo {
            padding: 10px 0; /* Diminuído o padding vertical */
            margin-bottom: 10px; /* Adicionado margem inferior para separar do menu */
            white-space: nowrap;
            opacity: 1; 
            width: 100%; 
            text-align: center;
            box-sizing: border-box; /* Garante que padding e border sejam incluídos na largura total */
        }
        
        /* CORREÇÃO CHAVE: Define a largura e altura MÁXIMA da imagem quando o menu está fechado */
        .logo img {
            max-width: 40px; 
            max-height: 40px; 
            height: auto;
            display: block;
            margin: 0 auto;
            object-fit: contain; /* Garante que a imagem caiba sem esticar */
            transition: max-height 0.3s ease-in-out, max-width 0.3s ease-in-out;
        }

        /* Ajuste do logo no hover (menu aberto) */
        .sidebar:hover .logo {
            /* Garante que o container do logo tenha a mesma largura do sidebar aberto */
            width: var(--sidebar-width-open); 
        }

        .sidebar:hover .logo img {
            max-width: 120%; /* Deixa a imagem maior no modo aberto */
            max-height: 120px; /* Aumenta a altura máxima */
        }
        /* FIM DA CORREÇÃO DO LOGO */


        .logo a {
            font-size: 24px;
            font-weight: bold;
            color: var(--accent-color);
            text-decoration: none;
        }
        
        .menu-list {
            list-style: none;
            padding: 0;
            width: 100%;
        }

        .menu-list li {
            margin-bottom: 5px; /* Diminuído a margem para mais itens caberem */
            padding: 0 5px; /* Padding para o item da lista */
        }

        .menu-list a {
            color: var(--text-color);
            text-decoration: none;
            display: flex;
            padding: 15px;
            background-color: var(--menu-bg);
            border-radius: 8px;
            transition: background-color 0.3s ease;
            font-size: 18px;
            align-items: center;
        }
        
        .menu-list a .fas {
            margin-right: 15px;
            color: var(--accent-color);
            min-width: 25px;
            text-align: center;
        }
        
        .menu-list a span {
            display: inline-block;
            visibility: hidden; 
            opacity: 0;
            white-space: nowrap;
            transition: opacity 0.2s ease, visibility 0.2s ease;
        }

        .sidebar:hover .menu-list a span {
            visibility: visible;
            opacity: 1;
        }

        .menu-list a:hover {
            background-color: var(--menu-hover-bg);
        }

        /* Conteúdo Principal */
        .main-content {
            margin-left: var(--sidebar-width-closed);
            padding: 20px;
            flex-grow: 1;
            box-sizing: border-box;
            transition: margin-left 0.3s ease-in-out;
        }

        .sidebar:hover ~ .main-content {
            margin-left: var(--sidebar-width-open);
        }
        
        main {
            text-align: center;
        }

        .cards {
            display: flex;
            justify-content: center;
            gap: 20px;
            flex-wrap: wrap;
            margin-top: 30px;
        }

        .card {
            background: var(--card-bg);
            padding: 20px;
            border-radius: 8px;
            width: 250px;
            box-shadow: 0 4px 8px var(--box-shadow-color);
            text-align: center;
            transition: background 0.3s ease, box-shadow 0.3s ease;
        }

        .card h3 {
            color: var(--accent-color);
        }

        .btn {
            display: inline-block;
            margin-top: 15px;
            padding: 10px 20px;
            background: var(--accent-color);
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background 0.3s ease;
            border: none;
        }

        .btn:hover {
            background-color: #d87a32; /* Tonalidade um pouco mais escura de laranja */
        }

        /* Rodapé */
        footer {
            margin-top: 50px;
            text-align: center;
            padding: 20px 0;
            border-top: 1px solid var(--border-color);
        }

        /* Botão de Edição */
        .edit-btn {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background: var(--accent-color);
            color: white;
            padding: 12px 18px;
            border-radius: 50%;
            font-size: 20px;
            text-decoration: none;
            box-shadow: 0 4px 8px var(--box-shadow-color);
            cursor: pointer;
            transition: background 0.3s ease;
        }

        /* Alertas */
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 8px;
            font-weight: bold;
        }

        .alert.success {
            background-color: #34d399;
            color: white;
        }

        .alert.error {
            background-color: #f87171;
            color: white;
        }
        
        /* Botão de tema no canto superior direito */
        #theme-toggle {
            position: fixed;
            top: 20px;
            right: 20px;
            background: transparent;
            border: 2px solid var(--accent-color);
            border-radius: 50%;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-size: 20px;
            color: var(--accent-color);
            transition: color 0.3s ease, background 0.3s ease, border-color 0.3s ease;
            z-index: 1001;
        }

        #theme-toggle:hover {
            background: var(--accent-color);
            color: white;
        }

        /* Media Queries para Responsividade */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                width: var(--sidebar-width-open);
            }
            .sidebar.active {
                transform: translateX(0);
            }
            .main-content {
                margin-left: 0;
                padding-left: 20px;
            }
            .menu-toggle {
                display: block;
            }
            .sidebar:hover {
                width: var(--sidebar-width-open);
            }
            .sidebar:hover ~ .main-content {
                margin-left: 0;
            }
        }
    </style>
</head>
<body>
    <button id="theme-toggle">
        <i class="fas fa-sun"></i>
    </button>
    
    <div class="menu-toggle" onclick="toggleMenu()">
        <i class="fas fa-bars"></i>
    </div>

    <div class="sidebar" id="sidebar">
        <div class="logo">
            <a href="../home/home.php">
                <img src="../boasvindas/LogoTipo Auxtec.png" alt="Logo da Auxtec">
            </a>
        </div>
        <ul class="menu-list">
            <li><a href="../home/home.php"><i class="fas fa-home"></i> <span>Início</span></a></li>
            <li><a href="../perfil/editar_perfil.php"><i class="fas fa-user-circle"></i> <span>Meu Perfil</span></a></li>
            <li><a href="../juridico/juridico.php"><i class="fas fa-gavel"></i> <span>Jurídico</span></a></li>
            <li><a href="../financeiro/financeiro.php"><i class="fas fa-wallet"></i> <span>Financeiro</span></a></li>
            <li><a href="../calculadora/calculadora.php"><i class="fas fa-calculator"></i> <span>Calculadora</span></a></li>
            <li><a href="../planilhas/planilhas.php"><i class="fas fa-file-excel"></i> <span>Minhas Planilhas</span></a></li>
            <li><a href="../calendario/calendario.php"><i class="fas fa-calendar-alt"></i> <span>Calendário</span></a></li>
            <li><a href="../login/logout.php"><i class="fas fa-sign-out-alt"></i> <span>Sair</span></a></li>
            <?php if ($tipo == 'admin'): ?>
                <li><a href="../admin/admin.php"><i class="fas fa-user-shield"></i> <span>Painel Admin</span></a></li>
            <?php endif; ?>
        </ul>
    </div>

    <div class="main-content">
        <?php echo $message; ?>
        <main>
            <h2><?php echo htmlspecialchars($home_titulo); ?></h2>
            <p><?php echo htmlspecialchars($home_paragrafo); ?></p>

            <section class="cards">
                <div class="card">
                    <h3>👤 Meu Perfil</h3>
                    <p>Altere seu nome, e-mail, senha e tipo de atividade profissional.</p>
                    <a href="../perfil/editar_perfil.php" class="btn">Acessar</a>
                </div>
                <div class="card">
                    <h3><?php echo htmlspecialchars($card1_titulo); ?></h3>
                    <p><?php echo htmlspecialchars($card1_paragrafo); ?></p>
                    <a href="../calculadora/calculadora.php" class="btn">Acessar</a>
                </div>
                <div class="card">
                    <h3><?php echo htmlspecialchars($card2_titulo); ?></h3>
                    <p><?php echo htmlspecialchars($card2_paragrafo); ?></p>
                    <a href="../planilhas/planilhas.php" class="btn">Acessar</a>
                </div>
                <div class="card">
                    <h3><?php echo htmlspecialchars($card3_titulo); ?></h3>
                    <p><?php echo htmlspecialchars($card3_paragrafo); ?></p>
                    <a href="../juridico/juridico.php" class="btn">Acessar</a>
                </div>
                <div class="card">
                    <h3><?php echo htmlspecialchars($card4_titulo); ?></h3>
                    <p><?php echo htmlspecialchars($card4_paragrafo); ?></p>
                    <a href="../financeiro/financeiro.php" class="btn">Acessar</a>
                </div>
                <div class="card">
                    <h3><?php echo htmlspecialchars($card5_titulo); ?></h3>
                    <p><?php echo htmlspecialchars($card5_paragrafo); ?></p>
                    <a href="../calendario/calendario.php" class="btn">Acessar</a>
                </div>
                <?php if ($tipo == 'admin'): ?>
                <div class="card">
                    <h3>Painel Admin</h3>
                    <p>Acesse o painel para editar o conteúdo do site e gerenciar usuários.</p>
                    <a href="../admin/admin.php" class="btn">Acessar</a>
                </div>
                <?php endif; ?>
            </section>
        </main>

        <footer>
            <p>
                © 2025 TCC Rinaldi. Todos os direitos reservados.
            </p>
        </footer>
    </div>
    
    <script>
        function toggleMenu() {
            var sidebar = document.getElementById("sidebar");
            sidebar.classList.toggle("active");
        }

        document.addEventListener('DOMContentLoaded', (event) => {
            const themeToggleBtn = document.getElementById('theme-toggle');
            const body = document.body;
            
            // Aplica o tema salvo no localStorage
            const savedTheme = localStorage.getItem('theme');
            if (savedTheme === 'light') {
                body.classList.add('light-mode');
                themeToggleBtn.innerHTML = '<i class="fas fa-moon"></i>';
            } else {
                themeToggleBtn.innerHTML = '<i class="fas fa-sun"></i>';
            }

            themeToggleBtn.addEventListener('click', () => {
                body.classList.toggle('light-mode');

                if (body.classList.contains('light-mode')) {
                    localStorage.setItem('theme', 'light');
                    themeToggleBtn.innerHTML = '<i class="fas fa-moon"></i>';
                } else {
                    localStorage.setItem('theme', 'dark');
                    themeToggleBtn.innerHTML = '<i class="fas fa-sun"></i>';
                }
            });
        });
    </script>
</body>
</html>