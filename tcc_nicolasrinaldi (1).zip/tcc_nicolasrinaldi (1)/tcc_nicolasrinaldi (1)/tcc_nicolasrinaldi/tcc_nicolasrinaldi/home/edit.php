<?php
session_start();
include("../config/db.php");

// Se não for admin, redireciona
if (!isset($_SESSION['tipo']) || $_SESSION['tipo'] !== 'admin') {
    header("Location: home.php");
    exit();
}

// Lógica para carregar o conteúdo atual do banco de dados
$id_conteudo = 1;
$sql = "SELECT * FROM home_conteudo WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_conteudo);
$stmt->execute();
$result = $stmt->get_result();
$home_content = $result->fetch_assoc();

// Se o conteúdo não for encontrado, use valores padrão
$home_titulo      = $home_content['home_titulo'] ?? '';
$home_paragrafo   = $home_content['home_paragrafo'] ?? '';
$card1_titulo     = $home_content['card1_titulo'] ?? '';
$card1_paragrafo  = $home_content['card1_paragrafo'] ?? '';
$card2_titulo     = $home_content['card2_titulo'] ?? '';
$card2_paragrafo  = $home_content['card2_paragrafo'] ?? '';
$card3_titulo     = $home_content['card3_titulo'] ?? '';
$card3_paragrafo  = $home_content['card3_paragrafo'] ?? '';

$tipo = $_SESSION['tipo'] ?? 'comum';
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Editar Conteúdo - TCC Rinaldi</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        /* Estilos do corpo e layout geral */
        body {
            background-color: #222;
            color: #fff;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
        }

        /* Estilos do Menu Lateral */
        .sidebar {
            width: 250px;
            background-color: #1a1a1a;
            color: #fff;
            padding: 20px;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        .logo {
            margin-bottom: 30px;
        }
        .logo a {
            font-size: 24px;
            font-weight: bold;
            color: #F58A3D;
            text-decoration: none;
        }
        .menu-list {
            list-style: none;
            padding: 0;
            width: 100%;
        }
        .menu-list li {
            margin-bottom: 10px;
        }
        .menu-list a {
            color: #fff;
            text-decoration: none;
            display: block;
            padding: 15px;
            background-color: #333;
            border-radius: 8px;
            transition: background-color 0.3s ease;
            font-size: 18px;
            display: flex;
            align-items: center;
        }
        .menu-list a:hover {
            background-color: #444;
        }
        .menu-list a .fas {
            margin-right: 15px;
            color: #F58A3D;
        }

        /* Estilos do Conteúdo Principal */
        .main-content {
            margin-left: 250px; /* Offset para o menu fixo */
            padding: 20px;
            flex-grow: 1;
            box-sizing: border-box;
        }
        .edit-form-container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background-color: #2b2b2b;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        }
        .edit-form-container h2, .edit-form-container h3 {
            color: #F58A3D;
        }
        .edit-form-container label {
            display: block;
            margin-bottom: 5px;
            color: #ccc;
            font-weight: bold;
        }
        .edit-form-container input, .edit-form-container textarea {
            width: 100%;
            padding: 8px;
            margin-bottom: 15px;
            border: 1px solid #555;
            border-radius: 4px;
            background-color: #333;
            color: white;
            box-sizing: border-box;
        }
        .edit-form-container textarea {
            min-height: 100px;
            resize: vertical;
        }
        .edit-form-container button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }
        .edit-form-container button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="logo">
            <a href="#">Logo do Site</a>
        </div>
        <ul class="menu-list">
            <li><a href="../home/home.php"><i class="fas fa-home"></i> Início</a></li>
            <li><a href="../juridico/juridico.php"><i class="fas fa-gavel"></i> Jurídico</a></li>
            <li><a href="../calculadora/calculadora.php"><i class="fas fa-calculator"></i> Calculadora</a></li>
            <li><a href="../planilhas/planilhas.php"><i class="fas fa-file-excel"></i> Minhas Planilhas</a></li>
            <li><a href="../login/logout.php"><i class="fas fa-sign-out-alt"></i> Sair</a></li>
            <?php if ($tipo == 'admin'): ?>
                <li><a href="#"><i class="fas fa-user-shield"></i> Painel Admin</a></li>
            <?php endif; ?>
        </ul>
    </div>

    <div class="main-content">
        <div class="edit-form-container">
            <h2>Página Inicial</h2>
            <form action="save_content.php" method="post">
                <label for="home_titulo">Título da Página</label>
                <input type="text" id="home_titulo" name="home_titulo_input" value="<?php echo htmlspecialchars($home_titulo); ?>">

                <label for="home_paragrafo">Parágrafo da Página</label>
                <textarea id="home_paragrafo" name="home_paragrafo_input"><?php echo htmlspecialchars($home_paragrafo); ?></textarea>

                <hr>
                <h3>Card 1</h3>
                <label for="card1_titulo">Título do Card 1</label>
                <input type="text" id="card1_titulo" name="card1_titulo_input" value="<?php echo htmlspecialchars($card1_titulo); ?>">
                <label for="card1_paragrafo">Parágrafo do Card 1</label>
                <textarea id="card1_paragrafo" name="card1_paragrafo_input"><?php echo htmlspecialchars($card1_paragrafo); ?></textarea>

                <hr>
                <h3>Card 2</h3>
                <label for="card2_titulo">Título do Card 2</label>
                <input type="text" id="card2_titulo" name="card2_titulo_input" value="<?php echo htmlspecialchars($card2_titulo); ?>">
                <label for="card2_paragrafo">Parágrafo do Card 2</label>
                <textarea id="card2_paragrafo" name="card2_paragrafo_input"><?php echo htmlspecialchars($card2_paragrafo); ?></textarea>

                <hr>
                <h3>Card 3</h3>
                <label for="card3_titulo">Título do Card 3</label>
                <input type="text" id="card3_titulo" name="card3_titulo_input" value="<?php echo htmlspecialchars($card3_titulo); ?>">
                <label for="card3_paragrafo">Parágrafo do Card 3</label>
                <textarea id="card3_paragrafo" name="card3_paragrafo_input"><?php echo htmlspecialchars($card3_paragrafo); ?></textarea>
                
                <button type="submit">Salvar Alterações</button>
            </form>
        </div>
    </div>
</body>
</html>