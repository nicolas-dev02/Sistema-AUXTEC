<?php
session_start();
include("../config/db.php");

// Se não for admin, redireciona
if (!isset($_SESSION['tipo']) || $_SESSION['tipo'] !== 'admin') {
    header("Location: home.php");
    exit();
}

// Verifica se os dados do formulário foram enviados via POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Pega os dados do formulário
    $home_titulo = $_POST['home_titulo_input'] ?? '';
    $home_paragrafo = $_POST['home_paragrafo_input'] ?? '';
    $card1_titulo = $_POST['card1_titulo_input'] ?? '';
    $card1_paragrafo = $_POST['card1_paragrafo_input'] ?? '';
    $card2_titulo = $_POST['card2_titulo_input'] ?? '';
    $card2_paragrafo = $_POST['card2_paragrafo_input'] ?? '';
    $card3_titulo = $_POST['card3_titulo_input'] ?? '';
    $card3_paragrafo = $_POST['card3_paragrafo_input'] ?? '';

    // Lógica para atualizar o conteúdo no banco de dados
    $sql = "UPDATE home_conteudo SET 
            home_titulo = ?, 
            home_paragrafo = ?, 
            card1_titulo = ?, 
            card1_paragrafo = ?, 
            card2_titulo = ?, 
            card2_paragrafo = ?, 
            card3_titulo = ?, 
            card3_paragrafo = ?
            WHERE id = 1"; // Atualiza sempre o registro de ID 1

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssssss", 
        $home_titulo, 
        $home_paragrafo, 
        $card1_titulo, 
        $card1_paragrafo, 
        $card2_titulo, 
        $card2_paragrafo, 
        $card3_titulo, 
        $card3_paragrafo
    );
    
    // Executa a atualização e redireciona com status
    if ($stmt->execute()) {
        header("Location: home.php?status=success_content");
    } else {
        header("Location: edit.php?status=error_content");
    }

    $stmt->close();
    $conn->close();
    exit();
} else {
    // Se a requisição não for POST, redireciona para a página de edição
    header("Location: edit.php");
    exit();
}
?>