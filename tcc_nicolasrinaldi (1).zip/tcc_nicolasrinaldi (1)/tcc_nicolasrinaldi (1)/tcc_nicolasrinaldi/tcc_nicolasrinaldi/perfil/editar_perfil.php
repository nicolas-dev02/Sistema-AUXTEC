<?php
// Ativa a exibição de erros para diagnóstico
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
include("../config/db.php");

// 1. Redireciona se não estiver logado
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login/login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$message = '';

// --- Lógica para Carregar Dados do Usuário ---
$sql_user = "SELECT nome, email, atividade_profissional FROM usuarios WHERE id = ?";
$stmt_user = $conn->prepare($sql_user);
$stmt_user->bind_param("i", $user_id);
$stmt_user->execute();
$result_user = $stmt_user->get_result();
$usuario = $result_user->fetch_assoc();
$stmt_user->close();

if (!$usuario) {
    // Caso raro onde o ID da sessão não encontra um usuário
    $_SESSION = array(); // Limpa a sessão
    session_destroy();
    header("Location: ../login/login.php?status=error_user");
    exit();
}

$nomeAtual = $usuario['nome'];
$emailAtual = $usuario['email'];
$atividadeAtual = $usuario['atividade_profissional'];

// --- Lógica para Processar o Formulário de Atualização ---
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $novoNome = trim($_POST['nome'] ?? '');
    $novoEmail = trim($_POST['email'] ?? '');
    $novaSenha = $_POST['password'] ?? '';
    $confirmaSenha = $_POST['confirm_password'] ?? '';
    $novaAtividade = $_POST['atividade_profissional'] ?? '';

    // Validação básica
    if (empty($novoNome) || empty($novoEmail) || empty($novaAtividade)) {
        $message = '<div class="alert error">Por favor, preencha todos os campos obrigatórios.</div>';
    } elseif ($novaAtividade !== 'formal' && $novaAtividade !== 'informal') {
        $message = '<div class="alert error">Valor inválido para Atividade Profissional.</div>';
    } else {
        $update_parts = [];
        $params = [];
        $types = '';

        // 1. Atualizar Nome
        if ($novoNome !== $nomeAtual) {
            $update_parts[] = "nome = ?";
            $params[] = $novoNome;
            $types .= 's';
        }

        // 2. Atualizar E-mail (com verificação de duplicidade)
        if ($novoEmail !== $emailAtual) {
            // Verifica se o novo e-mail já está em uso por outro usuário
            $stmt_check_email = $conn->prepare("SELECT id FROM usuarios WHERE email = ? AND id != ?");
            $stmt_check_email->bind_param("si", $novoEmail, $user_id);
            $stmt_check_email->execute();
            $stmt_check_email->store_result();
            if ($stmt_check_email->num_rows > 0) {
                $message = '<div class="alert error">O novo e-mail já está cadastrado em outra conta.</div>';
            } else {
                $update_parts[] = "email = ?";
                $params[] = $novoEmail;
                $types .= 's';
                $emailAtual = $novoEmail; // Atualiza para exibição imediata
            }
            $stmt_check_email->close();
        }

        // 3. Atualizar Senha (apenas se preenchida e confirmada)
        if (!empty($novaSenha)) {
            if ($novaSenha !== $confirmaSenha) {
                $message = '<div class="alert error">A nova senha e a confirmação não coincidem.</div>';
            } else {
                $password_hash = password_hash($novaSenha, PASSWORD_DEFAULT);
                $update_parts[] = "password_hash = ?";
                $params[] = $password_hash;
                $types .= 's';
            }
        }

        // 4. Atualizar Atividade Profissional
        if ($novaAtividade !== $atividadeAtual) {
            $update_parts[] = "atividade_profissional = ?";
            $params[] = $novaAtividade;
            $types .= 's';
            $atividadeAtual = $novaAtividade; // Atualiza para exibição imediata
            
            // **CORREÇÃO: ATUALIZA A SESSÃO APÓS ALTERAR NO BANCO**
            $_SESSION['atividade_profissional'] = $novaAtividade;
        }

        // 5. Executar a Atualização
        if (empty($message) && !empty($update_parts)) {
            $sql_update = "UPDATE usuarios SET " . implode(", ", $update_parts) . " WHERE id = ?";
            
            // Adiciona o ID do usuário aos parâmetros no final
            $params[] = $user_id;
            $types .= 'i';

            $stmt_update = $conn->prepare($sql_update);
            
            // Necessário para Prepared Statements com parâmetros variáveis
            $bind_names[] = $types;
            for ($i = 0; $i < count($params); $i++) {
                $bind_name = 'bind' . $i;
                $$bind_name = $params[$i];
                $bind_names[] = &$$bind_name;
            }
            call_user_func_array(array($stmt_update, 'bind_param'), $bind_names);

            if ($stmt_update->execute()) {
                // Atualiza o nome na sessão caso tenha mudado (melhor UX)
                if (isset($novoNome)) {
                    $_SESSION['user_nome'] = $novoNome;
                }
                $message = '<div class="alert success">Perfil atualizado com sucesso!</div>';
                // Recarrega os dados atuais do formulário
                $nomeAtual = $novoNome;
                $emailAtual = $novoEmail;
            } else {
                $message = '<div class="alert error">Erro ao atualizar: ' . $stmt_update->error . '</div>';
            }
            $stmt_update->close();
        } elseif (empty($message)) {
             $message = '<div class="alert">Nenhuma alteração detectada.</div>';
        }
    }
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Editar Perfil - TCC Rinaldi</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        :root {
            /* Variáveis para cores do tema escuro (padrão) */
            --bg-color: #222;
            --container-bg: #1a1a1a;
            --text-color: #fff;
            --input-bg: #333;
            --input-border: #444;
            --accent-color: #F58A3D;
            --box-shadow-color: rgba(0, 0, 0, 0.3);
        }

        /* Variáveis para cores do tema claro */
        body.light-mode {
            --bg-color: #f0f2f5;
            --container-bg: #fff;
            --text-color: #333;
            --input-bg: #e9ecef;
            --input-border: #dee2e6;
            --accent-color: #F58A3D;
            --box-shadow-color: rgba(0, 0, 0, 0.1);
        }

        body {
            background-color: var(--bg-color);
            color: var(--text-color);
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            transition: background-color 0.3s ease, color 0.3s ease;
        }

        .edit-container {
            background-color: var(--container-bg);
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 4px 15px var(--box-shadow-color);
            width: 90%;
            max-width: 500px;
            transition: background-color 0.3s ease, box-shadow 0.3s ease;
        }

        .edit-container h2 {
            margin-bottom: 30px;
            color: var(--accent-color);
            text-align: center;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }

        .form-group input,
        .form-group select {
            width: 100%;
            padding: 12px;
            border: 1px solid var(--input-border);
            border-radius: 5px;
            box-sizing: border-box;
            background-color: var(--input-bg);
            color: var(--text-color);
            transition: background-color 0.3s ease, border-color 0.3s ease, color 0.3s ease;
        }

        .btn-primary {
            width: 100%;
            padding: 12px;
            background-color: var(--accent-color);
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 18px;
            margin-top: 10px;
            transition: background-color 0.3s ease;
        }

        .btn-primary:hover {
            background-color: #d87a32;
        }

        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 8px;
            font-weight: bold;
        }

        .alert.success {
            background-color: #34d399;
            color: white;
        }

        .alert.error {
            background-color: #f87171;
            color: white;
        }
        
        .alert:not(.success):not(.error) {
            background-color: #F58A3D; /* Laranja de alerta neutro */
            color: white;
        }
        
        /* Botão de tema no canto superior direito */
        #theme-toggle {
            position: fixed;
            top: 20px;
            right: 20px;
            background: transparent;
            border: 2px solid var(--accent-color);
            border-radius: 50%;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-size: 20px;
            color: var(--accent-color);
            transition: color 0.3s ease, background 0.3s ease, border-color 0.3s ease;
            z-index: 1001;
        }

        #theme-toggle:hover {
            background: var(--accent-color);
            color: white;
        }
    </style>
</head>
<body>
    <button id="theme-toggle">
        <i class="fas fa-sun"></i>
    </button>
    
    <div class="edit-container">
        <h2><i class="fas fa-user-circle"></i> Meu Perfil</h2>
        <?php echo $message; ?>
        
        <form action="editar_perfil.php" method="POST">
            <div class="form-group">
                <label for="nome">Nome Completo</label>
                <input type="text" id="nome" name="nome" value="<?php echo htmlspecialchars($nomeAtual); ?>" required>
            </div>
            
            <div class="form-group">
                <label for="email">E-mail</label>
                <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($emailAtual); ?>" required>
            </div>
            
            <div class="form-group">
                <label for="atividade_profissional">Tipo de Trabalhador Autônomo</label>
                <select id="atividade_profissional" name="atividade_profissional" required>
                    <option value="informal" <?php echo $atividadeAtual == 'informal' ? 'selected' : ''; ?>>
                        Trabalhador Autônomo Informal
                    </option>
                    <option value="formal" <?php echo $atividadeAtual == 'formal' ? 'selected' : ''; ?>>
                        Trabalhador Autônomo Formal (MEI)
                    </option>
                </select>
            </div>

            <h3>Alterar Senha (Opcional)</h3>
            <p style="font-size: 0.9em; margin-top: -10px; margin-bottom: 20px;">Preencha os campos abaixo APENAS se desejar alterar sua senha.</p>
            
            <div class="form-group">
                <label for="password">Nova Senha</label>
                <input type="password" id="password" name="password" placeholder="Deixe em branco para não alterar">
            </div>
            
            <div class="form-group">
                <label for="confirm_password">Confirmar Nova Senha</label>
                <input type="password" id="confirm_password" name="confirm_password" placeholder="Repita a nova senha">
            </div>
            
            <button type="submit" class="btn btn-primary">Salvar Alterações</button>
        </form>
        <p style="text-align: center; margin-top: 20px;"><a href="../home/home.php">Voltar para Início</a></p>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', (event) => {
            const themeToggleBtn = document.getElementById('theme-toggle');
            const body = document.body;
            
            // Aplica o tema salvo no localStorage
            const savedTheme = localStorage.getItem('theme');
            if (savedTheme === 'light') {
                body.classList.add('light-mode');
                themeToggleBtn.innerHTML = '<i class="fas fa-moon"></i>';
            } else {
                themeToggleBtn.innerHTML = '<i class="fas fa-sun"></i>';
            }

            themeToggleBtn.addEventListener('click', () => {
                body.classList.toggle('light-mode');

                if (body.classList.contains('light-mode')) {
                    localStorage.setItem('theme', 'light');
                    themeToggleBtn.innerHTML = '<i class="fas fa-moon"></i>';
                } else {
                    localStorage.setItem('theme', 'dark');
                    themeToggleBtn.innerHTML = '<i class="fas fa-sun"></i>';
                }
            });
        });
    </script>
</body>
</html>