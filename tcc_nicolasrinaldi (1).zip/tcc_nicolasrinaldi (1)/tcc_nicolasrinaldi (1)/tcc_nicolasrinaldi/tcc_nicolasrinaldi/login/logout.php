<?php
session_start();

// Destrói todas as variáveis de sessão
session_unset();

// Destrói a sessão
session_destroy();

// Redireciona para a página de boas-vindas
// O '../' sobe um nível na hierarquia de pastas para encontrar o arquivo boasvindas.html
header("Location: ../boasvindas/boasvindas.html");
exit();
?>