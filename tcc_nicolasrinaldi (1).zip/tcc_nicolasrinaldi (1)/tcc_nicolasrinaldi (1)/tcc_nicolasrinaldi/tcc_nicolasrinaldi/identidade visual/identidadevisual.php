<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nossa Identidade - Auxtec</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        :root {
            /* Tema escuro (padrão) */
            --bg-dark: #121212;
            --bg-medium: #1e1e1e;
            --bg-light: #2a2a2a;
            --text-light: #f5f5f5;
            --text-muted: #cccccc;
            --accent-primary: #F58A3D;
            --accent-hover: #e67627;
            --border-color: #444;
            --box-shadow-color: rgba(0, 0, 0, 0.3);
        }

        /* Tema claro */
        body.light-mode {
            --bg-dark: #f0f2f5;
            --bg-medium: #ffffff;
            --bg-light: #e9ecef;
            --text-light: #333333;
            --text-muted: #6b7280;
            --accent-primary: #F58A3D;
            --accent-hover: #d87a32;
            --border-color: #dee2e6;
            --box-shadow-color: rgba(0, 0, 0, 0.1);
        }

        /* Estilos base */
        body {
            font-family: 'Poppins', sans-serif;
            background-color: var(--bg-dark);
            color: var(--text-light);
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            transition: background-color 0.3s ease, color 0.3s ease;
        }

        /* --- Header --- */
        .main-header {
            width: 100%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 40px;
            box-sizing: border-box;
            background-color: var(--bg-medium);
        }

        .logo-header { width: 150px; }
        .logo-header img { width: 100%; height: auto; }

        .header-buttons {
            display: flex;
            gap: 15px;
            align-items: center;
        }

        .btn {
            display: inline-block;
            padding: 10px 20px;
            text-decoration: none;
            color: var(--text-light);
            background-color: transparent;
            border: 2px solid var(--accent-primary);
            border-radius: 8px;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .btn.primary {
            background-color: var(--accent-primary);
            color: var(--bg-dark);
        }

        .btn.primary:hover {
            background-color: var(--accent-hover);
            border-color: var(--accent-hover);
        }

        .btn:hover {
            background-color: var(--accent-primary);
            color: var(--bg-dark);
        }

        /* Botão de tema (mesmo estilo do home.php) */
        #theme-toggle {
            position: fixed;
            top: 20px;
            right: 20px;
            background: transparent;
            border: 2px solid var(--accent-primary);
            border-radius: 50%;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-size: 20px;
            color: var(--accent-primary);
            transition: color 0.3s ease, background 0.3s ease, border-color 0.3s ease;
            z-index: 1001;
        }

        #theme-toggle:hover {
            background: var(--accent-primary);
            color: white;
        }

        /* --- Main Content --- */
        .main-container {
            flex-grow: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 40px 20px;
            max-width: 1200px;
            margin: 0 auto;
            text-align: center;
        }

        .main-container h1 {
            font-size: 3rem;
            color: var(--accent-primary);
            margin-bottom: 40px;
            border-bottom: 2px solid var(--accent-primary);
            padding-bottom: 10px;
        }

        .section-box {
            background-color: var(--bg-medium);
            border-radius: 12px;
            padding: 40px;
            margin-bottom: 40px;
            max-width: 800px;
            box-shadow: 0 4px 15px var(--box-shadow-color);
            text-align: center;
        }

        .section-box h2 {
            font-size: 2rem;
            color: var(--accent-primary);
            margin-top: 0;
            margin-bottom: 20px;
        }

        /* Identidade Visual */
        .identity-section {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 30px;
            width: 100%;
        }

        /* Usar variável para texto principal e para parágrafos usar --text-muted (melhor contraste em ambos) */
        .identity-section p {
            text-align: justify;
            color: var(--text-muted);
            max-width: 720px;
        }

        .logo-presentation img {
            max-width: 250px;
            width: 100%;
        }

        .color-palette {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            margin-top: 10px;
            justify-content: center;
        }

        .color-box {
            width: 80px;
            height: 80px;
            border-radius: 8px;
            border: 2px solid var(--border-color);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.9rem;
            text-align: center;
            padding: 5px;
            font-weight: 600;
            color: #fff; /* padrão para fundos escuros / laranja */
            box-shadow: 0 6px 12px rgba(0,0,0,0.08);
        }

        .color-box.light {
            background-color:rgb(0, 0, 0);
            color: var(--bg-dark);
        }

        /* Se você quiser que as caixas usem as cores exatas da marca, mantive a definição inline abaixo. */

        /* Carrossel */
        .carousel-section {
            width: 100%;
            max-width: 800px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .carousel-container {
            width: 100%;
            overflow: hidden;
            position: relative;
            background-color: var(--bg-medium);
            border-radius: 12px;
            box-shadow: 0 4px 15px var(--box-shadow-color);
            padding: 40px;
            display: flex;
            align-items: center;
        }

        .carousel-track {
            display: flex;
            width: 100%;
            transition: transform 0.5s ease-in-out;
        }

        .carousel-slide {
            flex-shrink: 0;
            width: 100%;
            display: flex;
            align-items: center;
            gap: 40px;
            flex-wrap: wrap;
            padding: 20px 0;
            text-align: left;
            justify-content: center;
        }

        .carousel-content {
            flex-basis: 60%;
            min-width: 300px;
            text-align: left;
        }

        .carousel-content h2 {
            font-size: 2rem;
            color: var(--accent-primary);
            margin-bottom: 10px;
        }

        /* Aqui o parágrafo usa --text-muted para ter contraste correto em ambos os temas */
        .carousel-content p {
            line-height: 1.6;
            color: var(--text-muted);
        }

        .carousel-icon {
            flex-basis: 30%;
            min-width: 150px;
            text-align: center;
        }

        .carousel-icon i {
            font-size: 8rem;
            color: var(--accent-primary);
        }

        .carousel-dots {
            margin-top: 20px;
            display: flex;
            gap: 10px;
            justify-content: center;
        }

        .dot {
            width: 12px;
            height: 12px;
            background-color: #555;
            border-radius: 50%;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .dot.active { background-color: var(--accent-primary); }

        strong { color: var(--text-light); font-weight: 600; }

        /* Footer */
        .footer {
            width: 100%;
            background-color: var(--bg-medium);
            padding: 30px 20px;
            text-align: center;
            box-shadow: 0 -4px 15px rgba(0, 0, 0, 0.3);
            margin-top: auto;
        }

        .social-media { margin-bottom: 20px; }
        .social-media a {
            color: var(--text-light);
            font-size: 1.5rem;
            margin: 0 15px;
            transition: color 0.3s ease;
        }
        .social-media a:hover { color: var(--accent-primary); }

        .footer p { font-size: 0.9rem; color: var(--text-muted); }

        /* Responsividade */
        @media (max-width: 768px) {
            .main-header { flex-direction: column; padding: 20px; }
            .header-buttons { margin-top: 20px; }
            .main-container h1 { font-size: 2.5rem; }
            .carousel-slide { flex-direction: column; text-align: center; }
            .carousel-content { text-align: center; }
            .carousel-icon { font-size: 6rem; }
            .carousel-container { padding: 20px; }
            .section-box { padding: 20px; }
            .identity-section p { text-align: center; }
        }
    </style>
</head>
<body>

    <header class="main-header">
        <a href="../boasvindas/boasvindas.html" class="logo-header">
            <img src="../boasvindas/LogoTipo Auxtec.png" alt="Logo da Auxtec">
        </a>
        <div class="header-buttons">
            <a href="../login/login.php" class="btn">Login</a>
            <a href="../cadastro/cadastro.php" class="btn primary">Cadastrar</a>
        </div>
    </header>

    <!-- Botão de alternar tema (igual ao home.php) -->
    <button id="theme-toggle" aria-label="Alternar tema">
        <i class="fas fa-sun"></i>
    </button>

    <div class="main-container">
        <h1>Nossa Identidade Visual e Princípios</h1>

        <div class="section-box identity-section">
            <h2>Identidade Visual</h2>
            <p>
                A identidade visual da <strong>Auxtec</strong> foi cuidadosamente pensada para transmitir segurança, inovação e simplicidade. A paleta de cores é baseada em tons de laranja e cinza escuro, representando a energia do empreendedorismo e a solidez da gestão. A tipografia Poppins foi escolhida por sua clareza e modernidade, garantindo uma leitura fácil e agradável em todas as nossas plataformas.
            </p>

            <div class="color-palette">
                <!-- Mantive as cores oficiais com inline styles para garantir fidelidade -->
                <div class="color-box" style="background-color: #F58A3D;"></div>
                <div class="color-box" style="background-color: #121212;"></div>
                <div class="color-box" style="background-color: #1e1e1e;"></div>
                <div class="color-box light" style="background-color:rgb(255, 255, 255);"></div>
            </div>
        </div>

        <div class="carousel-section">
            <div class="carousel-container">
                <div class="carousel-track">
                    <div class="carousel-slide">
                        <div class="carousel-icon"><i class="fas fa-bullseye"></i></div>
                        <div class="carousel-content">
                            <h2>Missão</h2>
                            <p>Nossa missão é <strong>desburocratizar a vida do Microempreendedor Individual (MEI)</strong>, oferecendo ferramentas intuitivas e suporte especializado para que ele possa gerenciar seu negócio de forma eficiente, focando no que realmente importa: o crescimento e a realização de seus objetivos.</p>
                        </div>
                    </div>

                    <div class="carousel-slide">
                        <div class="carousel-icon"><i class="fas fa-eye"></i></div>
                        <div class="carousel-content">
                            <h2>Visão</h2>
                            <p>Ser a <strong>plataforma líder e referência</strong> em gestão simplificada para MEIs, reconhecida por democratizar o acesso a recursos essenciais e por impulsionar o sucesso de milhões de empreendedores autônomos no Brasil.</p>
                        </div>
                    </div>

                    <div class="carousel-slide">
                        <div class="carousel-icon"><i class="fas fa-hands-helping"></i></div>
                        <div class="carousel-content">
                            <h2>Valores</h2>
                            <p>Guiados por <strong>Inovação, Simplicidade, Parceria, Transparência e Compromisso</strong>, nosso objetivo é ser um aliado confiável na jornada de cada empreendedor.</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="carousel-dots">
                <div class="dot active" data-slide="0"></div>
                <div class="dot" data-slide="1"></div>
                <div class="dot" data-slide="2"></div>
            </div>
        </div>
    </div>

    <footer class="footer">
        <div class="social-media">
            <a href="https://facebook.com" target="_blank" aria-label="Facebook"><i class="fab fa-facebook-f"></i></a>
            <a href="https://instagram.com" target="_blank" aria-label="Instagram"><i class="fab fa-instagram"></i></a>
        </div>
        <p>&copy; 2025 Auxtec. Todos os direitos reservados.</p>
    </footer>

    <script>
        // Carrossel
        const track = document.querySelector('.carousel-track');
        const slides = Array.from(track.querySelectorAll('.carousel-slide'));
        const dotsContainer = document.querySelector('.carousel-dots');
        const dots = Array.from(dotsContainer.querySelectorAll('.dot'));
        let slideIndex = 0;

        function updateCarousel() {
            const slideWidth = slides[0].offsetWidth;
            track.style.transform = 'translateX(' + (-slideWidth * slideIndex) + 'px)';
            dots.forEach(dot => dot.classList.remove('active'));
            dots[slideIndex].classList.add('active');
        }

        // dots click
        dotsContainer.addEventListener('click', e => {
            const dot = e.target.closest('.dot');
            if (!dot) return;
            const dotIndex = dots.indexOf(dot);
            slideIndex = dotIndex;
            updateCarousel();
        });

        function nextSlide() {
            slideIndex = (slideIndex + 1) % slides.length;
            updateCarousel();
        }

        // atualizar no resize para manter o posicionamento correto
        window.addEventListener('resize', updateCarousel);

        // start
        updateCarousel();
        setInterval(nextSlide, 5000);

        // Alternar tema (igual ao home.php)
        const themeToggleBtn = document.getElementById('theme-toggle');
        const bodyEl = document.body;

        // Carrega preferência salva
        const savedTheme = localStorage.getItem('theme');
        if (savedTheme === 'light') {
            bodyEl.classList.add('light-mode');
            themeToggleBtn.innerHTML = '<i class="fas fa-moon"></i>';
        } else {
            themeToggleBtn.innerHTML = '<i class="fas fa-sun"></i>';
        }

        themeToggleBtn.addEventListener('click', () => {
            bodyEl.classList.toggle('light-mode');

            if (bodyEl.classList.contains('light-mode')) {
                localStorage.setItem('theme', 'light');
                themeToggleBtn.innerHTML = '<i class="fas fa-moon"></i>';
            } else {
                localStorage.setItem('theme', 'dark');
                themeToggleBtn.innerHTML = '<i class="fas fa-sun"></i>';
            }
        });
    </script>
</body>
</html>
