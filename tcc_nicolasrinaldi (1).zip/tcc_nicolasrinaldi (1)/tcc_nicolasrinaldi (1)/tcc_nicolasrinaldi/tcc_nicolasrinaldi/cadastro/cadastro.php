<?php
session_start();
include("../config/db.php");

$message = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $nome = $_POST['nome'];
    $atividade_profissional = $_POST['atividade_profissional'];
    $tipo = 'comum';

    if (empty($email) || empty($password) || empty($nome) || empty($atividade_profissional)) {
        $message = "Por favor, preencha todos os campos.";
    } else {
        // Verifica se o email já existe
        $stmt = $conn->prepare("SELECT id FROM usuarios WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();
        
        if ($stmt->num_rows > 0) {
            $message = "Este e-mail já está cadastrado.";
        } else {
            $password_hash = password_hash($password, PASSWORD_DEFAULT);

            // Prepara a query para inserir o novo usuário
            $stmt = $conn->prepare("INSERT INTO usuarios (email, password_hash, nome, tipo, atividade_profissional) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("sssss", $email, $password_hash, $nome, $tipo, $atividade_profissional);

            if ($stmt->execute()) {
                header("Location: ../login/login.php");
                exit();
            } else {
                $message = "Erro ao cadastrar. Tente novamente mais tarde.";
            }
        }
        $stmt->close();
    }
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Cadastro - TCC Rinaldi</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        :root {
            /* Variáveis para cores do tema escuro (padrão) */
            --bg-color: #222;
            --container-bg: #1a1a1a;
            --text-color: #fff;
            --input-bg: #333;
            --input-border: #444;
            --accent-color: #F58A3D;
            --box-shadow-color: rgba(0, 0, 0, 0.3);
        }

        /* Variáveis para cores do tema claro */
        body.light-mode {
            --bg-color: #f0f2f5;
            --container-bg: #fff;
            --text-color: #333;
            --input-bg: #e9ecef;
            --input-border: #dee2e6;
            --accent-color: #F58A3D;
            --box-shadow-color: rgba(0, 0, 0, 0.1);
        }

        body {
            background-color: var(--bg-color);
            color: var(--text-color);
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            transition: background-color 0.3s ease, color 0.3s ease;
        }

        .cadastro-container {
            background-color: var(--container-bg);
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 4px 15px var(--box-shadow-color);
            text-align: center;
            width: 90%;
            max-width: 400px;
            transition: background-color 0.3s ease, box-shadow 0.3s ease;
        }

        .cadastro-container h2 {
            margin-bottom: 20px;
            color: var(--accent-color);
        }

        .form-group {
            margin-bottom: 15px;
            text-align: left;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
        }

        .form-group input,
        .form-group select {
            width: 100%;
            padding: 10px;
            border: 1px solid var(--input-border);
            border-radius: 5px;
            box-sizing: border-box;
            background-color: var(--input-bg);
            color: var(--text-color);
            transition: background-color 0.3s ease, border-color 0.3s ease, color 0.3s ease;
        }

        .form-group input:focus,
        .form-group select:focus {
            outline: none;
            border-color: var(--accent-color);
        }

        .btn-primary {
            width: 100%;
            padding: 10px;
            background-color: var(--accent-color);
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        .btn-primary:hover {
            background-color: #d87a32;
        }

        .message {
            background-color: #f87171;
            color: white;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 15px;
        }
        
        a {
            color: var(--accent-color);
            text-decoration: none;
            transition: color 0.3s ease;
        }

        a:hover {
            text-decoration: underline;
        }

        /* Botão de tema no canto superior direito */
        #theme-toggle {
            position: fixed;
            top: 20px;
            right: 20px;
            background: transparent;
            border: 2px solid var(--accent-color);
            border-radius: 50%;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-size: 20px;
            color: var(--accent-color);
            transition: color 0.3s ease, background 0.3s ease, border-color 0.3s ease;
            z-index: 1001;
        }

        #theme-toggle:hover {
            background: var(--accent-color);
            color: white;
        }
    </style>
</head>
<body>
    <button id="theme-toggle">
        <i class="fas fa-sun"></i>
    </button>

    <div class="cadastro-container">
        <h2>Criar conta</h2>
        <?php if ($message): ?>
            <div class="message"><?php echo $message; ?></div>
        <?php endif; ?>
        <form action="cadastro.php" method="POST">
            <div class="form-group">
                <label for="nome">Nome Completo</label>
                <input type="text" id="nome" name="nome" required>
            </div>
            <div class="form-group">
                <label for="email">E-mail</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="password">Senha</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="form-group">
                <label for="atividade_profissional">Você se identifica como:</label>
                <select id="atividade_profissional" name="atividade_profissional" required>
                    <option value="">Selecione</option>
                    <option value="informal">Trabalhador Autônomo Informal</option>
                    <option value="formal">Trabalhador Autônomo Formal (MEI)</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Cadastrar</button>
        </form>
        <p>Já tem uma conta? <a href="../login/login.php">Entrar</a></p>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', (event) => {
            const themeToggleBtn = document.getElementById('theme-toggle');
            const body = document.body;
            
            const savedTheme = localStorage.getItem('theme');
            if (savedTheme === 'light') {
                body.classList.add('light-mode');
                themeToggleBtn.innerHTML = '<i class="fas fa-moon"></i>';
            } else {
                themeToggleBtn.innerHTML = '<i class="fas fa-sun"></i>';
            }

            themeToggleBtn.addEventListener('click', () => {
                body.classList.toggle('light-mode');

                if (body.classList.contains('light-mode')) {
                    localStorage.setItem('theme', 'light');
                    themeToggleBtn.innerHTML = '<i class="fas fa-moon"></i>';
                } else {
                    localStorage.setItem('theme', 'dark');
                    themeToggleBtn.innerHTML = '<i class="fas fa-sun"></i>';
                }
            });
        });
    </script>
</body>
</html>