<?php
// Determina o caminho atual para marcar o link ativo
$current_page = basename($_SERVER['PHP_SELF']);
?>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

<!-- Botão para abrir o menu (apenas em mobile) -->
<button class="menu-toggle-btn" onclick="toggleSidebar()">
    <i class="fas fa-bars"></i> Menu
</button>

<!-- Menu Sidebar -->
<aside class="sidebar" id="sidebar">
    <div class="logo-container">
        <div class="logo">TCC Rinaldi</div>
        <!-- Botão de fechar (apenas em mobile) -->
        <button class="menu-toggle-btn close-btn" onclick="toggleSidebar()">
            <i class="fas fa-times"></i> Fechar
        </button>
    </div>

    <nav class="nav-links">
        <a href="../home/home.php" class="nav-link <?php echo ($current_page === 'home.php') ? 'active' : ''; ?>">
            <i class="fas fa-home"></i> Início
        </a>
        <a href="../calculadora/calculadora.php" class="nav-link <?php echo ($current_page === 'calculadora.php') ? 'active' : ''; ?>">
            <i class="fas fa-calculator"></i> Calculadora
        </a>
        <a href="../planilhas/planilhas.php" class="nav-link <?php echo ($current_page === 'planilhas.php') ? 'active' : ''; ?>">
            <i class="fas fa-table"></i> Minhas Planilhas
        </a>
    </nav>

    <div class="sidebar-footer">
        <!-- Botão de Troca de Tema -->
        <button id="theme-toggle" class="theme-toggle-btn">
            <i class="fas fa-moon" id="theme-icon"></i> <span id="theme-text">Modo Escuro</span>
        </button>
        <!-- Link de Logout -->
        <a href="../logout.php" class="logout-link">
            Sair
        </a>
    </div>
</aside>

<script>
    // Função para alternar o estado do menu lateral em dispositivos móveis
    function toggleSidebar() {
        const sidebar = document.getElementById('sidebar');
        sidebar.classList.toggle('open');
    }

    // --- Lógica de Troca de Tema ---
    const themeToggle = document.getElementById('theme-toggle');
    const themeIcon = document.getElementById('theme-icon');
    const themeText = document.getElementById('theme-text');
    const body = document.body;

    // Função que aplica o tema
    function applyTheme(theme) {
        document.documentElement.setAttribute('data-theme', theme);
        localStorage.setItem('theme', theme);

        if (theme === 'light') {
            themeIcon.classList.replace('fa-sun', 'fa-moon');
            themeText.textContent = 'Modo Escuro';
        } else {
            themeIcon.classList.replace('fa-moon', 'fa-sun');
            themeText.textContent = 'Modo Claro';
        }
    }

    // Função para inicializar o tema (carrega do localStorage, usa 'light' como padrão)
    function initTheme() {
        const currentTheme = localStorage.getItem('theme') || 'light';
        applyTheme(currentTheme);
    }

    // Adiciona o listener de click ao botão
    themeToggle.addEventListener('click', () => {
        const currentTheme = localStorage.getItem('theme');
        const newTheme = currentTheme === 'light' ? 'dark' : 'light';
        applyTheme(newTheme);

        // Se houver um gráfico na página, recarrega para aplicar as cores atualizadas
        if (window.myChart) {
            window.myChart.destroy();
            drawChart();
        }
    });

    // Inicializa o tema quando a página carrega
    window.addEventListener('load', initTheme);
</script>
