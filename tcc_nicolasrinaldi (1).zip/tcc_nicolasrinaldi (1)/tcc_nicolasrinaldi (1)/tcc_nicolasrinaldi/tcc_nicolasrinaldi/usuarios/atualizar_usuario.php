<?php
session_start();
include("../config/db.php");

if(!isset($_SESSION['user_id']) || $_SESSION['tipo'] !== 'admin'){
    header("Location: ../home/home.php");
    exit();
}

// Atualizar dados
if(isset($_POST['atualizar'])){
    $id = $_POST['id'];
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $senha = $_POST['senha'];

    if(!empty($senha)){
        $senha = md5($senha);
        $sql = "UPDATE usuarios SET nome=?, email=?, senha=? WHERE id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssi", $nome, $email, $senha, $id);
    } else {
        $sql = "UPDATE usuarios SET nome=?, email=? WHERE id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssi", $nome, $email, $id);
    }
    $stmt->execute();
    header("Location: usuarios.php");
    exit();
}

// Promover ou rebaixar
if(isset($_GET['promover'])){
    $id = $_GET['promover'];
    $sql = "UPDATE usuarios SET tipo='admin' WHERE id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    header("Location: usuarios.php");
    exit();
}
if(isset($_GET['rebaixar'])){
    $id = $_GET['rebaixar'];
    $sql = "UPDATE usuarios SET tipo='comum' WHERE id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    header("Location: usuarios.php");
    exit();
}
