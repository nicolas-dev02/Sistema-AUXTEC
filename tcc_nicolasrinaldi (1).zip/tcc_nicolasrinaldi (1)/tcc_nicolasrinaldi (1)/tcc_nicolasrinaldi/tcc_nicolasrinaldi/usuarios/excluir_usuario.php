<?php
session_start();
include '../admin/conexao.php';

if (!isset($_SESSION['tipo']) || $_SESSION['tipo'] !== 'admin') {
    header('Location: ../login/login.php');
    exit();
}

$id = $_POST['id'] ?? 0;

// Inicia uma transação para garantir que ambas as operações sejam bem-sucedidas
$conn->begin_transaction();

try {
    // 1. Apaga todos os registros de cálculos do usuário primeiro
    $sql_delete_calculos = "DELETE FROM calculos WHERE user_id = ?";
    $stmt_calculos = $conn->prepare($sql_delete_calculos);
    $stmt_calculos->bind_param("i", $id);
    $stmt_calculos->execute();
    $stmt_calculos->close();

    // 2. Agora, apaga o usuário da tabela 'usuarios'
    $sql_delete_usuario = "DELETE FROM usuarios WHERE id = ?";
    $stmt_usuario = $conn->prepare($sql_delete_usuario);
    $stmt_usuario->bind_param("i", $id);
    $stmt_usuario->execute();
    $stmt_usuario->close();

    // Se tudo deu certo, confirma a transação
    $conn->commit();
    header('Location: ../admin/admin.php?status=success_delete');
    exit();

} catch (mysqli_sql_exception $exception) {
    // Em caso de erro, desfaz todas as operações
    $conn->rollback();
    error_log($exception->getMessage());
    header('Location: ../admin/admin.php?status=error_delete');
    exit();
}
?>