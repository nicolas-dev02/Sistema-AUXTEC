<?php
session_start();
include("../config/db.php");

if(!isset($_SESSION['user_id']) || $_SESSION['tipo'] !== 'admin'){
    header("Location: ../home/home.php");
    exit();
}

$id = $_GET['id'];
$sql = "SELECT * FROM usuarios WHERE id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$usuario = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Editar Usuário</title>
<link rel="stylesheet" href="usuarios.css">
</head>
<body>
    <h1>Editar Usuário</h1>
    <form method="POST" action="atualizar_usuario.php">
        <input type="hidden" name="id" value="<?= $usuario['id'] ?>">
        <label>Nome:</label><br>
        <input type="text" name="nome" value="<?= $usuario['nome'] ?>" required><br><br>
        <label>Email:</label><br>
        <input type="email" name="email" value="<?= $usuario['email'] ?>" required><br><br>
        <label>Senha (deixe em branco para não alterar):</label><br>
        <input type="password" name="senha"><br><br>
        <button type="submit" name="atualizar">Salvar</button>
    </form>
    <br>
    <a href="usuarios.php">Voltar</a>
</body>
</html>
