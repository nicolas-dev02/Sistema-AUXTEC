<?php
session_start();
// O caminho do seu arquivo de conexão
include("../config/db.php");

// Proteção de acesso: verifica se o usuário está logado e é admin
if(!isset($_SESSION['user_id']) || $_SESSION['tipo'] !== 'admin'){
    header("Location: ../home/home.php");
    exit();
}

// Lógica para buscar todos os usuários do banco de dados
$sql = "SELECT * FROM usuarios";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Gerenciar Usuários</title>
    <link rel="stylesheet" href="usuarios.css">
    <style>
        /* Estilos específicos para a página de usuários */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            color: #333;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 900px;
            margin: 0 auto;
            background: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #333;
            color: #fff;
        }
        .actions a, .actions button {
            text-decoration: none;
            padding: 5px 10px;
            border-radius: 5px;
            color: #fff;
            border: none;
            cursor: pointer;
        }
        .edit-btn {
            background-color: #007bff;
        }
        .promote-btn {
            background-color: #28a745;
        }
        .demote-btn {
            background-color: #ffc107;
        }
        .delete-btn {
            background-color: #dc3545;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Gerenciar Usuários</h1>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>Email</th>
                    <th>Tipo</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($row['id']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['nome']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['email']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['tipo']) . "</td>";
                        echo "<td class='actions'>";
                        echo "<a href='editar_usuario.php?id=" . $row['id'] . "' class='edit-btn'>Editar</a> ";
                        if ($row['tipo'] == 'comum') {
                            echo "<a href='atualizar_usuario.php?promover=" . $row['id'] . "' class='promote-btn'>Promover</a> ";
                        } else {
                            echo "<a href='atualizar_usuario.php?rebaixar=" . $row['id'] . "' class='demote-btn'>Rebaixar</a> ";
                        }
                        echo "<a href='excluir_usuario.php?id=" . $row['id'] . "' class='delete-btn' onclick='return confirm(\"Tem certeza que deseja excluir?\");'>Excluir</a>";
                        echo "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='5'>Nenhum usuário encontrado.</td></tr>";
                }
                ?>
            </tbody>
        </table>
        <br>
        <a href="../home/home.php">Voltar para o Início</a>
    </div>
</body>
</html>