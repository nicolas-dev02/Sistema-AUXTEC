<?php
// Ativa a exibição de erros para diagnóstico
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
// Certifique-se de que o caminho para o arquivo de conexão ao DB está correto
include("../config/db.php"); 

// Se não estiver logado, redireciona
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login/login.php");
    exit();
}

// 1. Lógica de controle: checa qual trilha deve ser exibida
$trilha_ativa = isset($_GET['trilha']) ? htmlspecialchars($_GET['trilha']) : 'informal';

// 2. Lógica de Salvamento e Carregamento (PERSISTÊNCIA COM SESSION)

// Define as chaves de sessão exclusivas por usuário (melhor prática, se user_id for único)
$user_id = $_SESSION['user_id'];
$session_key_informal = 'trilha_informal_concluido_' . $user_id;
$session_key_formal = 'trilha_formal_concluido_' . $user_id;

// Se houver dados de submissão GET (marcar/desmarcar checkbox), SALVA na SESSION
if (isset($_GET['informal']) && is_array($_GET['informal'])) {
    $_SESSION[$session_key_informal] = array_map('intval', $_GET['informal']);
    // Redireciona para URL limpa (evita re-submissão e deixa a URL mais bonita)
    header("Location: juridico.php?trilha=informal");
    exit();
}

if (isset($_GET['formal']) && is_array($_GET['formal'])) {
    $_SESSION[$session_key_formal] = array_map('intval', $_GET['formal']);
    // Redireciona para URL limpa (evita re-submissão e deixa a URL mais bonita)
    header("Location: juridico.php?trilha=formal");
    exit();
}

// CARREGA os dados da SESSION ou usa array vazio se não houver
$concluido_informal = isset($_SESSION[$session_key_informal]) ? $_SESSION[$session_key_informal] : [];
$concluido_formal = isset($_SESSION[$session_key_formal]) ? $_SESSION[$session_key_formal] : [];


// --- FUNÇÕES DE BUSCA: Puxa as tarefas e documentos por tipo (informal/formal) ---

function getTrilhas($conn, $tipo) {
    $trilhas = [];
    $sql = "SELECT id, titulo, paragrafo FROM juridico_trilhas WHERE status_tipo = ? ORDER BY ordem ASC";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $tipo);
    $stmt->execute();
    $result = $stmt->get_result();
    while($row = $result->fetch_assoc()) {
        $trilhas[] = $row;
    }
    $stmt->close();
    return $trilhas;
}

function getDocumentos($conn, $tipo) {
    $documentos = [];
    $sql = "SELECT titulo, link FROM juridico_documentos WHERE tipo = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $tipo);
    $stmt->execute();
    $result = $stmt->get_result();
    while($row = $result->fetch_assoc()) {
        $documentos[] = $row;
    }
    $stmt->close();
    return $documentos;
}

// --- EXECUÇÃO DAS BUSCAS ---

$trilhas_informal = getTrilhas($conn, 'informal');
$trilhas_formal = getTrilhas($conn, 'formal');
$documentos_ativos = getDocumentos($conn, $trilha_ativa);

// --- LÓGICA DE PROGRESSO ---

$total_informal = count($trilhas_informal);
$concluido_informal_count = count($concluido_informal);
$progresso_informal = ($total_informal > 0) ? ($concluido_informal_count / $total_informal) * 100 : 0;

$total_formal = count($trilhas_formal);
$concluido_formal_count = count($concluido_formal);
$progresso_formal = ($total_formal > 0) ? ($concluido_formal_count / $total_formal) * 100 : 0;

$progresso_porcentagem = ($trilha_ativa == 'informal') ? $progresso_informal : $progresso_formal;


// --- BUSCA E FALLBACK DO CONTEÚDO PRINCIPAL E DAS TRILHAS ---

$juridico_conteudo = [];
// Puxa as 6 colunas de conteúdo: 2 principais + 4 específicas das trilhas
$sql_principal = "SELECT 
                    juridico_titulo, juridico_paragrafo, 
                    trilha_informal_titulo, trilha_informal_paragrafo,
                    trilha_formal_titulo, trilha_formal_paragrafo
                  FROM juridico_conteudo WHERE id = 1"; // Assumindo que o conteúdo principal está no ID 1
$result_principal = $conn->query($sql_principal);

// Textos de Fallback (garantem que o texto correto apareça mesmo se o DB estiver vazio ou consulta falhar)
$fallback_content = [
    'juridico_titulo' => 'Guia Jurídico Essencial para MEIs',
    'juridico_paragrafo' => 'Este guia oferece uma visão geral das obrigações legais, direitos e deveres dos Microempreendedores Individuais (MEIs). O material foi desenvolvido para ajudar você a entender as principais leis e regulamentações que impactam sua atividade empresarial, garantindo que você opere de forma segura e em conformidade.',
    'trilha_informal_titulo' => 'Passo a Passo para se Tornar MEI',
    'trilha_informal_paragrafo' => 'Você está no caminho para a formalização! Siga esta trilha para aprender o caminho completo, desde a pesquisa inicial até a obtenção do seu CNPJ e os benefícios que a formalização trará para o seu negócio.',
    'trilha_formal_titulo' => 'Trilha para MEI Formalizado: Mantenha-se em Dia',
    'trilha_formal_paragrafo' => 'Guia essencial para quem já é MEI. Entenda suas obrigações, como declarar seu faturamento, emitir notas fiscais e gerenciar o seu negócio legalmente.'
];

if ($result_principal && $result_principal->num_rows > 0) {
    $db_content = $result_principal->fetch_assoc();
    
    // Mescla o conteúdo do DB com o fallback, priorizando o DB
    $juridico_conteudo = array_merge($fallback_content, $db_content);
    
    // Garante que o conteúdo do DB seja usado apenas se NÃO estiver vazio
    foreach ($juridico_conteudo as $key => $value) {
        if (empty($value) && isset($fallback_content[$key])) {
            $juridico_conteudo[$key] = $fallback_content[$key];
        }
    }
} else {
    // Se a consulta falhar, usa apenas o fallback
    $juridico_conteudo = $fallback_content;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trilha Jurídica - Gamificação</title>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        /* Variáveis de Tema */
        :root {
            --sidebar-width-open: 250px;
            --sidebar-width-closed: 60px;
            --bg-color: #222;
            --text-color: #fff;
            --card-bg: #2b2b2b;
            --sidebar-bg: #1a1a1a;
            --menu-bg: #333;
            --menu-hover-bg: #444;
            --accent-color: #F58A3D; /* Laranja principal */
            --accent-hover: #e67627;
            --border-color: #444; 
            --box-shadow-color: rgba(0, 0, 0, 0.3);
            /* Variáveis da página Jurídico */
            --bg-dark: #121212; 
            --bg-medium: #1e1e1e;
            --bg-light: #2a2a2a;
            --text-light: #f5f5f5;
            --status-positive: #34d399;
            --status-negative: #f87171;
            /* Variáveis de Progresso para Dark Mode */
            --progress-text-color: #ccc;
            --progress-bar-background: var(--border-color);
        }

        /* Variáveis para cores do tema claro */
        body.light-mode {
            --bg-color: #f0f2f5;
            --text-color: #333;
            --card-bg: #fff;
            --sidebar-bg: #f8f9fa;
            --menu-bg: #e9ecef;
            --menu-hover-bg: #dee2e6;
            --accent-color: #F58A3D; 
            --border-color: #dee2e6;
            --box-shadow-color: rgba(0, 0, 0, 0.1);
            /* Ajuste para o light-mode na página jurídico */
            --bg-dark: #e0e0e0;
            --bg-medium: #ffffff;
            --bg-light: #f5f5f5;
            --text-light: #333;
            /* CORREÇÃO DE CONTRASTE: Progresso Light Mode */
            --progress-text-color: #333; /* Texto escuro para alto contraste */
            --progress-bar-background: #d4d4d4; /* Cinza médio para fundo da barra */
        }

        /* Estilos base (menu e tema) */
        body {
            background-color: var(--bg-color);
            color: var(--text-color);
            font-family: 'Open Sans', Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            transition: background-color 0.3s ease, color 0.3s ease;
        }
        
        .sidebar {
            width: var(--sidebar-width-closed);
            background-color: var(--sidebar-bg);
            color: var(--text-color);
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            display: flex;
            flex-direction: column;
            align-items: center; 
            transition: width 0.3s ease-in-out, background-color 0.3s ease;
            z-index: 1000;
            overflow-x: hidden;
            box-shadow: 2px 0 5px var(--box-shadow-color);
        }
        .sidebar:hover {
            width: var(--sidebar-width-open);
        }
        .logo {
            padding: 10px 0;
            margin-bottom: 10px;
            white-space: nowrap;
            width: 100%; 
            text-align: center;
            box-sizing: border-box;
        }
        .logo img {
            max-width: 40px; 
            max-height: 40px; 
            height: auto;
            display: block;
            margin: 0 auto;
            object-fit: contain;
            transition: max-height 0.3s ease-in-out, max-width 0.3s ease-in-out;
        }
        .sidebar:hover .logo img {
            max-width: 120%;
            max-height: 120px;
        }
        .menu-list {
            list-style: none;
            padding: 0;
            width: 100%;
        }
        .menu-list li {
            margin-bottom: 5px;
            padding: 0 5px;
        }
        .menu-list a {
            color: var(--text-color);
            text-decoration: none;
            display: flex;
            padding: 15px;
            background-color: var(--menu-bg);
            border-radius: 8px;
            transition: background-color 0.3s ease;
            font-size: 16px;
            align-items: center;
        }
        .menu-list a .fas {
            margin-right: 15px;
            color: var(--accent-color);
            min-width: 25px;
            text-align: center;
        }
        .menu-list a span {
            display: inline-block;
            visibility: hidden; 
            opacity: 0;
            white-space: nowrap;
            transition: opacity 0.2s ease, visibility 0.2s ease;
        }
        .sidebar:hover .menu-list a span {
            visibility: visible;
            opacity: 1;
        }
        .menu-list a:hover, .menu-list a.active {
            background-color: var(--menu-hover-bg);
        }
        .main-content {
            margin-left: var(--sidebar-width-closed);
            padding: 20px;
            flex-grow: 1;
            box-sizing: border-box;
            transition: margin-left 0.3s ease-in-out;
        }
        .sidebar:hover ~ .main-content {
            margin-left: var(--sidebar-width-open);
        }
        #theme-toggle {
            position: fixed;
            top: 20px;
            right: 20px;
            background: transparent;
            border: 2px solid var(--accent-color);
            border-radius: 50%;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-size: 20px;
            color: var(--accent-color);
            transition: color 0.3s ease, background 0.3s ease, border-color 0.3s ease;
            z-index: 1001;
        }
        #theme-toggle:hover {
            background: var(--accent-color);
            color: white;
        }
        /* Fim dos estilos base */

        /* CSS EXCLUSIVO DA PÁGINA JURÍDICO */
        .juridico-page-container {
            background: var(--bg-medium);
            padding: 30px;
            border-radius: 16px;
            width: 100%;
            max-width: 900px;
            box-shadow: 0px 4px 12px var(--box-shadow-color);
            margin: 20px auto; 
        }

        .header {
            text-align: center;
            margin-bottom: 30px;
        }

        .header h1 {
            font-size: 32px;
            font-weight: bold;
            color: var(--accent-color);
        }

        .header p {
            font-size: 18px;
            margin-top: 10px;
            color: var(--text-color);
            line-height: 1.6;
        }

        .status-selection {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-bottom: 20px;
        }

        .status-selection a {
            text-decoration: none;
        }
        
        .status-btn {
            padding: 10px 18px;
            border: none;
            border-radius: 8px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.2s;
            background: var(--bg-light);
            color: var(--text-light);
            text-decoration: none;
            display: inline-block;
            box-shadow: 0 2px 4px var(--box-shadow-color);
        }

        .status-btn.active {
            background: var(--accent-color);
            color: white;
        }
        
        .status-btn:hover {
            background: var(--accent-hover);
        }

        .progress-container {
            margin-bottom: 30px;
            padding: 15px 20px;
            /* Fundo escuro para contrastar no light mode */
            background: var(--bg-dark); 
            border-radius: 8px;
            text-align: center;
        }

        .progress-bar-wrapper {
            /* USA VARIÁVEL DE TEMA PARA FUNDO DA BARRA */
            background: var(--progress-bar-background); 
            height: 8px; 
            border-radius: 6px;
            overflow: hidden;
            margin-top: 10px;
        }

        .progress-bar {
            height: 100%;
            background: var(--status-positive);
            transition: width 0.5s ease-in-out;
            border-radius: 6px 0 0 6px; 
        }

        .progress-text {
            font-size: 14px;
            /* USA VARIÁVEL DE TEMA PARA COR DO TEXTO (alto contraste) */
            color: var(--progress-text-color); 
        }

        .trilha-juridica-content {
            display: none;
        }

        .trilha-juridica-content.active {
            display: block;
        }

        .trilha-juridica-content h2 {
            font-size: 24px; 
            color: var(--accent-color);
            border-bottom: 2px solid var(--accent-color);
            padding-bottom: 10px;
            margin-bottom: 25px; 
        }
        
        /* CORREÇÃO: Aplicar cor de texto ao parágrafo dentro do conteúdo ativo */
        .trilha-juridica-content.active > p {
            margin-bottom: 20px;
            font-size: 16px;
            color: var(--text-color);
        }

        .task-list {
            list-style: none;
            padding: 0;
        }

        .task-item {
            background: var(--bg-light);
            margin-bottom: 15px;
            padding: 20px;
            border-radius: 8px;
            display: flex;
            align-items: flex-start;
            gap: 15px;
            transition: background 0.2s ease;
            box-shadow: 0 2px 6px var(--box-shadow-color);
            border-left: 5px solid var(--accent-color); 
        }

        .task-item:hover {
            background: var(--menu-hover-bg);
        }

        .task-item.completed {
            background: var(--bg-dark); 
            border-left: 5px solid var(--status-positive);
            opacity: 0.9;
        }

        .task-checkbox {
            -webkit-appearance: none;
            appearance: none;
            width: 24px;
            height: 24px;
            border: 2px solid var(--accent-color);
            border-radius: 4px;
            cursor: pointer;
            flex-shrink: 0;
            position: relative;
            transition: background-color 0.2s, border-color 0.2s;
        }

        .task-checkbox:checked {
            background-color: var(--status-positive);
            border-color: var(--status-positive);
        }

        .task-checkbox:checked::after {
            content: '✔';
            color: white;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            font-size: 16px;
        }

        .task-content {
            flex-grow: 1;
        }

        .task-content h3 {
            font-size: 18px;
            margin-bottom: 5px;
            color: var(--text-light);
        }

        .task-content p {
            font-size: 15px;
            color: #a0a0a0;
            line-height: 1.5;
        }

        .document-links {
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid var(--border-color);
        }

        .document-links h2 {
            font-size: 24px;
            color: var(--accent-color);
            margin-bottom: 20px;
        }

        .document-list {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 20px;
        }

        .document-card {
            background: var(--bg-light);
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 6px var(--box-shadow-color);
            transition: transform 0.2s ease-in-out, background 0.2s ease;
        }

        .document-card:hover {
            transform: translateY(-5px);
            background: var(--menu-hover-bg);
        }

        .document-card h3 {
            font-size: 18px;
            margin-bottom: 10px;
            color: var(--accent-color);
        }

        .document-card a {
            color: var(--status-positive);
            text-decoration: none;
            font-size: 14px;
            display: inline-flex;
            align-items: center;
        }
        
        .document-card a::after {
            content: "\f35d"; /* Ícone de link externo (Font Awesome) */
            font-family: "Font Awesome 5 Free";
            font-weight: 900;
            margin-left: 8px;
            font-size: 12px;
        }
        
        .document-card a:hover {
            text-decoration: underline;
        }

        /* Media Query para Responsividade */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                width: var(--sidebar-width-open);
            }
            .main-content {
                margin-left: 0;
            }
            .sidebar:hover ~ .main-content {
                margin-left: 0;
            }
            .document-list {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <button id="theme-toggle">
        <i class="fas fa-sun"></i>
    </button>
    
    <div class="menu-toggle" onclick="toggleMenu()">
        <i class="fas fa-bars"></i>
    </div>
    
    <div class="sidebar" id="sidebar">
        <div class="logo">
            <a href="../home/home.php">
                <img src="../boasvindas/LogoTipo Auxtec.png" alt="Logo da Auxtec">
            </a>
        </div>
        <ul class="menu-list">
            <li><a href="../home/home.php"><i class="fas fa-home"></i> <span>Início</span></a></li>
            <li><a href="../perfil/editar_perfil.php"><i class="fas fa-user-circle"></i> <span>Meu Perfil</span></a></li>
            <li><a href="../juridico/juridico.php" class="active"><i class="fas fa-gavel"></i> <span>Jurídico</span></a></li>
            <li><a href="../financeiro/financeiro.php"><i class="fas fa-wallet"></i> <span>Financeiro</span></a></li>
            <li><a href="../calculadora/calculadora.php"><i class="fas fa-calculator"></i> <span>Calculadora</span></a></li>
            <li><a href="../planilhas/planilhas.php"><i class="fas fa-file-excel"></i> <span>Minhas Planilhas</span></a></li>
            <li><a href="../calendario/calendario.php"><i class="fas fa-calendar-alt"></i> <span>Calendário</span></a></li>
            <li><a href="../login/logout.php"><i class="fas fa-sign-out-alt"></i> <span>Sair</span></a></li>
            <?php if (isset($_SESSION['tipo']) && $_SESSION['tipo'] == 'admin'): ?>
                <li><a href="../admin/admin.php"><i class="fas fa-user-shield"></i> <span>Painel Admin</span></a></li>
            <?php endif; ?>
        </ul>
    </div>
    <div class="main-content">
        <div class="juridico-page-container">
            <div class="header">
                <h1><?php echo htmlspecialchars($juridico_conteudo['juridico_titulo']); ?></h1>
                <p><?php echo htmlspecialchars($juridico_conteudo['juridico_paragrafo']); ?></p>
            </div>
            
            <div class="status-selection">
                <a href="?trilha=informal" class="status-btn <?php echo ($trilha_ativa == 'informal') ? 'active' : ''; ?>">Sou Informal</a>
                <a href="?trilha=formal" class="status-btn <?php echo ($trilha_ativa == 'formal') ? 'active' : ''; ?>">Já sou Formalizado (MEI)</a>
            </div>
            
            <div class="progress-container">
                <span class="progress-text">Progresso na Trilha Ativa: <strong><?php echo round($progresso_porcentagem); ?>%</strong></span>
                <div class="progress-bar-wrapper">
                    <div class="progress-bar" id="progress-bar-fill" style="width: <?php echo $progresso_porcentagem; ?>%;"></div>
                </div>
            </div>
            
            <form id="trilha-informal-form" class="trilha-juridica-content <?php echo ($trilha_ativa == 'informal') ? 'active' : ''; ?>" method="GET" action="juridico.php">
                <input type="hidden" name="trilha" value="informal">
                
                <h2><?php echo htmlspecialchars($juridico_conteudo['trilha_informal_titulo']); ?></h2>
                <p><?php echo htmlspecialchars($juridico_conteudo['trilha_informal_paragrafo']); ?></p>
                
                <ul class="task-list">
                    <?php 
                    foreach ($trilhas_informal as $index => $item): 
                        $task_id = $item['id'] ?? ($index + 1);
                        // Verifica se a tarefa está na lista de concluídas da SESSION
                        $is_checked = in_array($task_id, $concluido_informal);
                    ?>
                    <li class="task-item <?php echo $is_checked ? 'completed' : ''; ?>">
                        <input type="checkbox" name="informal[]" value="<?php echo $task_id; ?>" class="task-checkbox" onchange="this.form.submit()" <?php echo $is_checked ? 'checked' : ''; ?>>
                        <div class="task-content">
                            <h3><?php echo htmlspecialchars($item['titulo']); ?></h3>
                            <p><?php echo htmlspecialchars($item['paragrafo']); ?></p>
                        </div>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </form>
            
            <form id="trilha-formal-form" class="trilha-juridica-content <?php echo ($trilha_ativa == 'formal') ? 'active' : ''; ?>" method="GET" action="juridico.php">
                <input type="hidden" name="trilha" value="formal">
                
                <h2><?php echo htmlspecialchars($juridico_conteudo['trilha_formal_titulo']); ?></h2>
                <p><?php echo htmlspecialchars($juridico_conteudo['trilha_formal_paragrafo']); ?></p>

                <ul class="task-list">
                    <?php 
                    foreach ($trilhas_formal as $index => $item): 
                        $task_id = $item['id'] ?? ($index + 1);
                        // Verifica se a tarefa está na lista de concluídas da SESSION
                        $is_checked = in_array($task_id, $concluido_formal);
                    ?>
                    <li class="task-item <?php echo $is_checked ? 'completed' : ''; ?>">
                        <input type="checkbox" name="formal[]" value="<?php echo $task_id; ?>" class="task-checkbox" onchange="this.form.submit()" <?php echo $is_checked ? 'checked' : ''; ?>>
                        <div class="task-content">
                            <h3><?php echo htmlspecialchars($item['titulo']); ?></h3>
                            <p><?php echo htmlspecialchars($item['paragrafo']); ?></p>
                        </div>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </form>

            <div class="document-links">
                <h2>Documentos Essenciais</h2>
                <div class="document-list">
                    <?php if (empty($documentos_ativos)): ?>
                        <p style="color: #aaa; grid-column: 1 / -1;">Nenhum documento essencial cadastrado para a trilha "<?php echo $trilha_ativa; ?>".</p>
                    <?php endif; ?>
                    <?php foreach ($documentos_ativos as $item): ?>
                    <div class="document-card">
                        <h3><?php echo htmlspecialchars($item['titulo']); ?></h3>
                        <a href="<?php echo htmlspecialchars($item['link']); ?>" target="_blank" rel="noopener noreferrer">Acessar Documento</a>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        function toggleMenu() {
            var sidebar = document.getElementById("sidebar");
            if (window.innerWidth <= 768) {
                sidebar.classList.toggle("active");
            }
        }

        document.addEventListener('DOMContentLoaded', (event) => {
            const themeToggleBtn = document.getElementById('theme-toggle');
            const body = document.body;
            
            // Aplica o tema salvo no localStorage
            const savedTheme = localStorage.getItem('theme');
            if (savedTheme === 'light') {
                body.classList.add('light-mode');
                themeToggleBtn.innerHTML = '<i class="fas fa-moon"></i>';
            } else {
                body.classList.remove('light-mode');
                themeToggleBtn.innerHTML = '<i class="fas fa-sun"></i>';
            }

            themeToggleBtn.addEventListener('click', () => {
                body.classList.toggle('light-mode');

                if (body.classList.contains('light-mode')) {
                    localStorage.setItem('theme', 'light');
                    themeToggleBtn.innerHTML = '<i class="fas fa-moon"></i>';
                } else {
                    localStorage.setItem('theme', 'dark');
                    themeToggleBtn.innerHTML = '<i class="fas fa-sun"></i>';
                }
            });
        });
    </script>
</body>
</html>