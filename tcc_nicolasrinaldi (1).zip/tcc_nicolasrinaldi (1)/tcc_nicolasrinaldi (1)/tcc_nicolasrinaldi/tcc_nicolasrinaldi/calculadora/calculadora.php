<?php
session_start();
include("../config/db.php");

if (!isset($_SESSION['user_id'])) {
    header("Location: ../boasvindas.html");
    exit();
}

$user_id = $_SESSION['user_id'];
$tipo_usuario = $_SESSION['tipo'];
$atividade_profissional = $_SESSION['atividade_profissional'] ?? '';

// Tenta carregar a atividade profissional mais atualizada no banco se não estiver na sessão
if (empty($atividade_profissional) && $conn) {
    $stmt_atividade = $conn->prepare("SELECT atividade_profissional FROM usuarios WHERE id = ?");
    $stmt_atividade->bind_param("i", $user_id);
    $stmt_atividade->execute();
    $result_atividade = $stmt_atividade->get_result();
    if ($row_atividade = $result_atividade->fetch_assoc()) {
        $atividade_profissional = $row_atividade['atividade_profissional'];
        $_SESSION['atividade_profissional'] = $atividade_profissional; // Salva na sessão
    }
    $stmt_atividade->close();
}

// Lógica para obter o mês para filtragem
$mes_filtro = isset($_GET['mes']) ? $_GET['mes'] : date('Y-m');

// Lógica para buscar os registros do financeiro com base no mês e no usuário
$renda_total = 0;
$custo_fixo_total = 0;
$custo_variavel_total = 0;
$impostos_total = 0;
$salario_total = 0;

$stmt = $conn->prepare("SELECT tipo, SUM(valor) AS total FROM registros_financeiros WHERE user_id = ? AND DATE_FORMAT(data_registro, '%Y-%m') = ? GROUP BY tipo");
$stmt->bind_param("is", $user_id, $mes_filtro);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    if ($row['tipo'] == 'renda') {
        $renda_total = $row['total'];
    } elseif ($row['tipo'] == 'custo_fixo') {
        $custo_fixo_total = $row['total'];
    } elseif ($row['tipo'] == 'custo_variavel') {
        $custo_variavel_total = $row['total'];
    } elseif ($row['tipo'] == 'impostos') {
        $impostos_total = $row['total'];
    } elseif ($row['tipo'] == 'salario') {
        $salario_total = $row['total'];
    }
}
$stmt->close();

$resultado = null;
$status = "";
$orientacao_financeira = "";

// Variáveis para a calculadora do Informal
$renda_informal = $renda_total;
$fixas_informal = $custo_fixo_total;
$variaveis_informal = $custo_variavel_total;
$saldo_informal = 0;

// Variáveis para a calculadora do Formal
$receita_bruta = $renda_total;
$custo_fixo = $custo_fixo_total;
$custo_variavel = $custo_variavel_total;
$impostos = $impostos_total;
$salario = $salario_total;
$saldo_formal = 0;

if (isset($_POST['calcular'])) {
    // Captura o mês selecionado no formulário para salvar o cálculo corretamente
    $mes_calculo = isset($_POST['mes_calculo']) ? $_POST['mes_calculo'] : date('Y-m');
    $data_calculo = $mes_calculo . '-01'; // Define o dia como o primeiro do mês

    if (isset($_POST['calculadora_tipo']) && $_POST['calculadora_tipo'] == 'informal') {
        $renda_informal = floatval($_POST['renda']);
        $fixas_informal = floatval($_POST['fixas']);
        $variaveis_informal = floatval($_POST['variaveis']);
        $totalDespesas = $fixas_informal + $variaveis_informal;
        $saldo_informal = $renda_informal - $totalDespesas;

        // Salvar cálculo no banco de dados com a data selecionada
        $stmt = $conn->prepare("INSERT INTO calculos (user_id, tipo_atividade, renda_bruta, despesas_fixas, despesas_variaveis, saldo, data_calculo) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $tipo_atividade = 'informal';
        $stmt->bind_param("isdddds", $user_id, $tipo_atividade, $renda_informal, $fixas_informal, $variaveis_informal, $saldo_informal, $data_calculo);
        $stmt->execute();
        $stmt->close();

        if ($saldo_informal > 0) {
            $status = "positivo";
            $resultado = "Sobraram R$ " . number_format($saldo_informal, 2, ",", ".");
            $orientacao_financeira = "Parabéns, você teve um saldo positivo! Considere criar uma reserva de emergência e guardar uma parte para investir no seu negócio, como R$ " . number_format($saldo_informal * 0.5, 2, ",", ".") . " para sua reserva e R$ " . number_format($saldo_informal * 0.5, 2, ",", ".") . " para investir em marketing ou novos materiais.";
        } elseif ($saldo_informal < 0) {
            $status = "negativo";
            $resultado = "Faltaram R$ " . number_format(abs($saldo_informal), 2, ",", ".");
            $orientacao_financeira = "Você teve um saldo negativo. Analise suas despesas variáveis e busque formas de reduzir gastos. Se possível, crie uma meta para aumentar sua renda no próximo mês.";
        } else {
            $status = "neutro";
            $resultado = "Você fechou o mês no zero a zero!";
            $orientacao_financeira = "Seu resultado ficou no zero a zero. Busque maneiras de reduzir suas despesas ou aumentar sua renda para começar a construir uma reserva.";
        }
    }

    if (isset($_POST['calculadora_tipo']) && $_POST['calculadora_tipo'] == 'formal') {
        $receita_bruta = floatval($_POST['receita_bruta']);
        $custo_fixo = floatval($_POST['custo_fixo']);
        $custo_variavel = floatval($_POST['custo_variavel']);
        $impostos = floatval($_POST['impostos']);
        $salario = floatval($_POST['salario']);
        $totalDespesas = $custo_fixo + $custo_variavel + $impostos + $salario;
        $saldo_formal = $receita_bruta - $totalDespesas;
        
        // Salvar cálculo no banco de dados com a data selecionada
        $stmt = $conn->prepare("INSERT INTO calculos (user_id, tipo_atividade, renda_bruta, despesas_fixas, despesas_variaveis, impostos, salario, saldo, data_calculo) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $tipo_atividade = 'formal';
        $stmt->bind_param("isdddddds", $user_id, $tipo_atividade, $receita_bruta, $custo_fixo, $custo_variavel, $impostos, $salario, $saldo_formal, $data_calculo);
        $stmt->execute();
        $stmt->close();
        
        if ($saldo_formal > 0) {
            $status = "positivo";
            $resultado = "O lucro da sua empresa foi de R$ " . number_format($saldo_formal, 2, ",", ".");
            $orientacao_financeira = "Excelente! Seu negócio está gerando lucro. Uma boa prática é reinvestir parte desse lucro. Sugestão: " . number_format($saldo_formal * 0.4, 2, ",", ".") . " para a empresa (reserva, novos projetos) e " . number_format($saldo_formal * 0.6, 2, ",", ".") . " para distribuir entre sócios ou manter como capital de giro.";
        } elseif ($saldo_formal < 0) {
            $status = "negativo";
            $resultado = "A sua empresa teve um prejuízo de R$ " . number_format(abs($saldo_formal), 2, ",", ".");
            $orientacao_financeira = "Sua empresa teve um prejuízo. Avalie seus custos, especialmente os fixos, e procure formas de aumentar o preço dos seus serviços ou a quantidade de vendas. Analise se o seu pró-labore é sustentável para a empresa.";
        } else {
            $status = "neutro";
            $resultado = "Sua empresa fechou o mês no zero a zero!";
            $orientacao_financeira = "O resultado foi neutro. Revise todas as suas despesas para identificar possíveis cortes e defina metas de faturamento para o próximo mês para garantir um lucro saudável.";
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Calculadora Financeira - TCC Rinaldi</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        /* ======================================= */
        /* VARIÁVEIS DE TEMA E ESTRUTURA (DO HOME) */
        /* ======================================= */
        :root {
            --sidebar-width-open: 250px;
            --sidebar-width-closed: 60px;

            /* Variáveis para cores do tema escuro (padrão) */
            --bg-color: #222;
            --text-color: #fff;
            --card-bg: #2b2b2b;
            --sidebar-bg: #1a1a1a;
            --menu-bg: #333;
            --menu-hover-bg: #444;
            --accent-color: #F58A3D;
            --border-color: #444;
            --box-shadow-color: rgba(0, 0, 0, 0.3);
        }

        /* Variáveis para cores do tema claro */
        body.light-mode {
            --bg-color: #f0f2f5;
            --text-color: #333;
            --card-bg: #fff;
            --sidebar-bg: #f8f9fa;
            --menu-bg: #e9ecef;
            --menu-hover-bg: #dee2e6;
            --accent-color: #F58A3D;
            --border-color: #dee2e6;
            --box-shadow-color: rgba(0, 0, 0, 0.1);

            /* Cores específicas para o tema claro nos componentes da calculadora */
            --calc-form-bg: #fff;
            --calc-text-color: #333;
            --calc-input-bg: #f8f9fa;
            --calc-input-border: #ccc;
            --calc-shadow-light: rgba(0, 0, 0, 0.15);
        }
        
        /* Tema Escuro Padrão para a Calculadora */
        .calc-form-wrapper, .resultado-container {
            background-color: var(--card-bg); /* Adaptado para a variável do tema */
            box-shadow: 0px 4px 12px var(--box-shadow-color); /* Adaptado para a variável do tema */
        }

        .calc-form-wrapper h2, .form-row label {
            color: var(--text-color); /* Adaptado para a variável do tema */
        }
        
        .form-row input, .filter-section input[type="month"] {
            border: 1px solid var(--border-color); /* Adaptado para a variável do tema */
            background-color: var(--menu-bg); /* Adaptado para a variável do tema */
            color: var(--text-color); /* Adaptado para a variável do tema */
        }
        
        .orientacao {
            background-color: var(--menu-bg); /* Adaptado para a variável do tema */
        }
        
        .grafico-container {
            background: var(--menu-bg); /* Adaptado para a variável do tema */
            border: 1px solid var(--border-color); /* Adaptado para a variável do tema */
        }
        
        /* Estilos do body e transições */
        body {
            background-color: var(--bg-color);
            color: var(--text-color);
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            transition: background-color 0.3s ease, color 0.3s ease;
        }

        /* Menu Lateral (Sidebar) com efeito hover */
        .sidebar {
            width: var(--sidebar-width-closed);
            background-color: var(--sidebar-bg);
            color: var(--text-color);
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            display: flex;
            flex-direction: column;
            align-items: center; 
            transition: width 0.3s ease-in-out, background-color 0.3s ease;
            z-index: 1000;
            overflow-x: hidden;
            box-shadow: 2px 0 5px var(--box-shadow-color);
        }

        .sidebar:hover {
            width: var(--sidebar-width-open);
        }
        
        .logo {
            padding: 10px 0;
            margin-bottom: 10px;
            white-space: nowrap;
            opacity: 1; 
            width: 100%; 
            text-align: center;
            box-sizing: border-box;
        }
        
        .logo img {
            max-width: 40px; 
            max-height: 40px; 
            height: auto;
            display: block;
            margin: 0 auto;
            object-fit: contain;
            transition: max-height 0.3s ease-in-out, max-width 0.3s ease-in-out;
        }

        .sidebar:hover .logo {
            width: var(--sidebar-width-open); 
        }

        .sidebar:hover .logo img {
            max-width: 80%;
            max-height: 80px;
        }

        .logo a {
            font-size: 24px;
            font-weight: bold;
            color: var(--accent-color);
            text-decoration: none;
        }
        
        .menu-list {
            list-style: none;
            padding: 0;
            width: 100%;
        }

        .menu-list li {
            margin-bottom: 5px;
            padding: 0 5px;
        }

        .menu-list a {
            color: var(--text-color);
            text-decoration: none;
            display: flex;
            padding: 15px;
            background-color: var(--menu-bg);
            border-radius: 8px;
            transition: background-color 0.3s ease;
            font-size: 18px;
            align-items: center;
        }
        
        .menu-list a .fas {
            margin-right: 15px;
            color: var(--accent-color);
            min-width: 25px;
            text-align: center;
        }
        
        .menu-list a span {
            display: inline-block;
            visibility: hidden; 
            opacity: 0;
            white-space: nowrap;
            transition: opacity 0.2s ease, visibility 0.2s ease;
        }

        .sidebar:hover .menu-list a span {
            visibility: visible;
            opacity: 1;
        }

        .menu-list a:hover {
            background-color: var(--menu-hover-bg);
        }

        /* Conteúdo Principal */
        .main-content {
            margin-left: var(--sidebar-width-closed);
            padding: 20px;
            flex-grow: 1;
            box-sizing: border-box;
            transition: margin-left 0.3s ease-in-out;
        }

        .sidebar:hover ~ .main-content {
            margin-left: var(--sidebar-width-open);
        }
        
        /* Botão de tema no canto superior direito */
        #theme-toggle {
            position: fixed;
            top: 20px;
            right: 20px;
            background: transparent;
            border: 2px solid var(--accent-color);
            border-radius: 50%;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-size: 20px;
            color: var(--accent-color);
            transition: color 0.3s ease, background 0.3s ease, border-color 0.3s ease;
            z-index: 1001;
        }

        #theme-toggle:hover {
            background: var(--accent-color);
            color: white;
        }
        
        /* Media Queries para Responsividade */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                width: var(--sidebar-width-open);
            }
            .sidebar.active {
                transform: translateX(0);
            }
            .main-content {
                margin-left: 0;
                padding-left: 20px;
            }
            .menu-toggle {
                display: block;
            }
            .sidebar:hover {
                width: var(--sidebar-width-open);
            }
            .sidebar:hover ~ .main-content {
                margin-left: 0;
            }
        }
        
        /* ======================================= */
        /* CSS ESPECÍFICO DA CALCULADORA */
        /* ======================================= */

        h1 {
            color: var(--accent-color);
            text-align: center;
            margin-bottom: 25px;
            font-size: 22px;
        }

        .calculadora-layout {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 2rem;
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
        }

        .calc-form-wrapper {
            padding: 30px;
            border-radius: 16px;
            display: flex;
            flex-direction: column;
            gap: 1.5rem;
            width: 100%;
            max-width: 500px;
        }
        
        /* Ajuste do fundo de cards/formulários para o modo claro */
        body.light-mode .calc-form-wrapper, body.light-mode .resultado-container {
            background-color: var(--card-bg);
            box-shadow: 0px 4px 12px var(--calc-shadow-light);
        }
        
        body.light-mode .orientacao, body.light-mode .grafico-container {
            background-color: var(--menu-bg);
            border-color: var(--border-color);
        }
        
        body.light-mode .form-row input, body.light-mode .filter-section input[type="month"] {
            background-color: var(--calc-input-bg);
            color: var(--text-color);
            border: 1px solid var(--calc-input-border);
        }


        .calc-form h2 {
            color: var(--text-color);
            border-bottom: 2px solid var(--accent-color);
            padding-bottom: 0.5rem;
            margin-bottom: 1.5rem;
        }

        .form-row {
            display: flex;
            flex-direction: column;
            margin-bottom: 1rem;
        }

        .form-row label {
            margin-bottom: 0.5rem;
        }

        .form-row input {
            padding: 0.75rem;
            border-radius: 5px;
            transition: border-color 0.3s ease;
        }

        .form-row input:focus {
            outline: none;
            border-color: var(--accent-color);
        }

        .btn {
            padding: 10px 18px;
            border: none;
            border-radius: 8px;
            font-weight: bold;
            cursor: pointer;
            font-size: 1rem;
            text-align: center;
            text-decoration: none;
            transition: all 0.2s;
        }

        .btn-primary {
            background: var(--accent-color);
            color: white;
        }

        .btn-primary:hover {
            background: #e67627;
            transform: translateY(-2px);
        }

        .resultado-container {
            padding: 30px;
            border-radius: 16px;
            display: flex;
            flex-direction: column;
            gap: 1.5rem;
            width: 100%;
            max-width: 500px;
            min-height: 400px;
        }

        .resultado {
            padding: 1rem;
            border-radius: 5px;
            text-align: center;
            font-size: 1.2rem;
            font-weight: bold;
        }

        .resultado.positivo {
            background-color: #34d399; /* Cor verde para positivo */
            color: white;
        }

        .resultado.negativo {
            background-color: #f87171; /* Cor vermelha para negativo */
            color: white;
        }

        .resultado.neutro {
            background-color: #fbbf24; /* Cor amarela para neutro */
            color: #121212;
        }

        .orientacao {
            font-size: 1rem;
            line-height: 1.5;
            padding: 1.5rem;
            border-radius: 5px;
        }
        
        .grafico-container {
            padding: 20px;
            border-radius: 12px;
        }
        
        /* Chart.js label color fix for dark/light mode */
        .chart-legend-label {
            color: var(--text-color) !important;
        }

        .tooltip-trigger {
            cursor: help;
            border-radius: 50%;
            background-color: var(--accent-color);
            color: white;
            font-size: 0.8em;
            padding: 0.1em 0.5em;
            vertical-align: top;
            line-height: 1;
            position: relative; /* Necessário para posicionar o tooltip */
        }

        .tooltip-trigger:hover::before {
            content: attr(data-tooltip);
            position: absolute;
            bottom: 120%;
            left: 50%;
            transform: translateX(-50%);
            background-color: rgba(0, 0, 0, 0.9);
            color: white;
            padding: 0.5rem;
            border-radius: 5px;
            white-space: nowrap;
            z-index: 100;
            font-size: 0.9em;
        }

        @media (max-width: 768px) {
            .calculadora-layout {
                flex-direction: column;
                align-items: center;
            }
        }

        .filter-section {
            margin-bottom: 20px;
        }

        .filter-section label {
            margin-right: 10px;
            color: var(--text-color);
        }

        .filter-section input[type="month"] {
            padding: 8px;
            border-radius: 5px;
            font-family: inherit;
        }

    </style>
</head>
<body>
    <button id="theme-toggle">
        <i class="fas fa-sun"></i>
    </button>
    
    <!-- Incluindo o menu.php no cabeçalho ou usando a estrutura diretamente -->
    <!-- Como você está incluindo o arquivo `menu/menu.php`, presumo que a estrutura do menu está lá.
         Para garantir a correção do menu e do tema, vou adicionar a estrutura completa do menu aqui,
         ASSUMINDO que você vai remover o include('../menu/menu.php'); -->
         
    <div class="sidebar" id="sidebar">
        <div class="logo">
            <a href="../home/home.php">
                <img src="../boasvindas/LogoTipo Auxtec.png" alt="Logo da Auxtec">
            </a>
        </div>
        <ul class="menu-list">
            <li><a href="../home/home.php"><i class="fas fa-home"></i> <span>Início</span></a></li>
            <li><a href="../perfil/editar_perfil.php"><i class="fas fa-user-circle"></i> <span>Meu Perfil</span></a></li>
            <li><a href="../juridico/juridico.php"><i class="fas fa-gavel"></i> <span>Jurídico</span></a></li>
            <li><a href="../financeiro/financeiro.php"><i class="fas fa-wallet"></i> <span>Financeiro</span></a></li>
            <li><a href="../calculadora/calculadora.php"><i class="fas fa-calculator"></i> <span>Calculadora</span></a></li>
            <li><a href="../planilhas/planilhas.php"><i class="fas fa-file-excel"></i> <span>Minhas Planilhas</span></a></li>
            <li><a href="../calendario/calendario.php"><i class="fas fa-calendar-alt"></i> <span>Calendário</span></a></li>
            <li><a href="../login/logout.php"><i class="fas fa-sign-out-alt"></i> <span>Sair</span></a></li>
            <?php if ($tipo_usuario == 'admin'): ?>
                <li><a href="../admin/admin.php"><i class="fas fa-user-shield"></i> <span>Painel Admin</span></a></li>
            <?php endif; ?>
        </ul>
    </div>
    
    <div class="main-content">
        <h1>Calculadora Financeira</h1>
        <div class="calculadora-layout">
            <div class="calc-form-wrapper">
                <div class="filter-section">
                    <form action="calculadora.php" method="GET">
                        <label for="mes">Filtrar por Mês:</label>
                        <input type="month" id="mes" name="mes" value="<?php echo htmlspecialchars($mes_filtro); ?>" onchange="this.form.submit()">
                    </form>
                </div>
                <?php if ($tipo_usuario == 'admin' || $atividade_profissional == 'informal'): ?>
                <h2>Calculadora para Trabalhador Informal</h2>
                <form method="POST" class="calc-form">
                    <input type="hidden" name="calculadora_tipo" value="informal">
                    <input type="hidden" name="mes_calculo" value="<?php echo htmlspecialchars($mes_filtro); ?>">
                    <div class="form-row">
                        <label for="renda">
                            Renda Mensal (R$)
                            <span class="tooltip-trigger" data-tooltip="O valor total que você recebeu no mês pelos seus serviços.">?</span>
                        </label>
                        <input type="number" name="renda" id="renda" step="0.01" value="<?php echo htmlspecialchars($renda_informal); ?>" required>
                    </div>
                    <div class="form-row">
                        <label for="fixas">
                            Despesas Fixas (R$)
                            <span class="tooltip-trigger" data-tooltip="Gastos que se repetem todo mês, como aluguel, luz e internet.">?</span>
                        </label>
                        <input type="number" name="fixas" id="fixas" step="0.01" value="<?php echo htmlspecialchars($fixas_informal); ?>" required>
                    </div>
                    <div class="form-row">
                        <label for="variaveis">
                            Despesas Variáveis (R$)
                            <span class="tooltip-trigger" data-tooltip="Gastos que variam, como material de trabalho, gasolina, etc.">?</span>
                        </label>
                        <input type="number" name="variaveis" id="variaveis" step="0.01" value="<?php echo htmlspecialchars($variaveis_informal); ?>" required>
                    </div>
                    <button type="submit" name="calcular" class="btn btn-primary">Calcular</button>
                </form>
                <?php endif; ?>

                <?php if ($tipo_usuario == 'admin' && $atividade_profissional != 'informal'): ?>
                    <hr style="border-color: var(--border-color)">
                <?php endif; ?>

                <?php if ($tipo_usuario == 'admin' || $atividade_profissional == 'formal'): ?>
                <h2>Calculadora para Trabalhador Formal</h2>
                <form method="POST" class="calc-form">
                    <input type="hidden" name="calculadora_tipo" value="formal">
                    <input type="hidden" name="mes_calculo" value="<?php echo htmlspecialchars($mes_filtro); ?>">
                    <div class="form-row">
                        <label for="receita_bruta">
                            Receita Bruta (R$)
                            <span class="tooltip-trigger" data-tooltip="O valor total que sua empresa faturou antes de deduzir qualquer custo.">?</span>
                        </label>
                        <input type="number" name="receita_bruta" id="receita_bruta" step="0.01" value="<?php echo htmlspecialchars($receita_bruta); ?>" required>
                    </div>
                    <div class="form-row">
                        <label for="custo_fixo">
                            Custo Fixo (R$)
                            <span class="tooltip-trigger" data-tooltip="Gastos essenciais da empresa que não variam com as vendas, como aluguel e salários fixos.">?</span>
                        </label>
                        <input type="number" name="custo_fixo" id="custo_fixo" step="0.01" value="<?php echo htmlspecialchars($custo_fixo); ?>" required>
                    </div>
                    <div class="form-row">
                        <label for="custo_variavel">
                            Custo Variável (R$)
                            <span class="tooltip-trigger" data-tooltip="Gastos que mudam de acordo com a produção ou serviço, como matéria-prima ou comissões.">?</span>
                        </label>
                        <input type="number" name="custo_variavel" id="custo_variavel" step="0.01" value="<?php echo htmlspecialchars($custo_variavel); ?>" required>
                    </div>
                    <div class="form-row">
                        <label for="impostos">
                            Impostos e Taxas (R$)
                            <span class="tooltip-trigger" data-tooltip="Valores que sua empresa paga ao governo, como DAS (para MEI) e outras contribuições.">?</span>
                        </label>
                        <input type="number" name="impostos" id="impostos" step="0.01" value="<?php echo htmlspecialchars($impostos); ?>" required>
                    </div>
                    <div class="form-row">
                        <label for="salario">
                            Salário / Pró-labore (R$)
                            <span class="tooltip-trigger" data-tooltip="O valor que você retira da empresa para seu sustento pessoal.">?</span>
                        </label>
                        <input type="number" name="salario" id="salario" step="0.01" value="<?php echo htmlspecialchars($salario); ?>" required>
                    </div>
                    <button type="submit" name="calcular" class="btn btn-primary">Calcular</button>
                </form>
                <?php endif; ?>
            </div>

            <?php if ($resultado): ?>
            <div class="resultado-container">
                <div class="resultado <?php echo $status; ?>">
                    <?php echo $resultado; ?>
                </div>
                <div class="orientacao">
                    <p><?php echo $orientacao_financeira; ?></p>
                </div>
                <div class="grafico-container">
                    <canvas id="graficoFinanceiro"></canvas>
                </div>
                <script>
                    const ctx = document.getElementById('graficoFinanceiro').getContext('2d');
                    let labels = [];
                    let data = [];
                    let backgroundColors = [];

                    <?php if (isset($_POST['calculadora_tipo']) && $_POST['calculadora_tipo'] == 'informal'): ?>
                        labels = ['Despesas Fixas', 'Despesas Variáveis', 'Saldo'];
                        data = [<?php echo $fixas_informal; ?>, <?php echo $variaveis_informal; ?>, <?php echo $saldo_informal > 0 ? $saldo_informal : 0; ?>];
                        backgroundColors = ['#f87171', '#fbbf24', '#34d399'];
                    <?php else: ?>
                        labels = ['Custo Fixo', 'Custo Variável', 'Impostos', 'Salário', 'Lucro'];
                        data = [<?php echo $custo_fixo; ?>, <?php echo $custo_variavel; ?>, <?php echo $impostos; ?>, <?php echo $salario; ?>, <?php echo $saldo_formal > 0 ? $saldo_formal : 0; ?>];
                        backgroundColors = ['#f87171', '#fbbf24', '#f58a3d', '#4d7c0f', '#34d399'];
                    <?php endif; ?>

                    data = data.map(val => val < 0 ? 0 : val);

                    const grafico = new Chart(ctx, {
                        type: 'pie',
                        data: {
                            labels: labels,
                            datasets: [{
                                data: data,
                                backgroundColor: backgroundColors,
                                borderColor: ['#fff', '#fff', '#fff', '#fff', '#fff'],
                                borderWidth: 2
                            }]
                        },
                        options: {
                            responsive: true,
                            plugins: {
                                legend: {
                                    position: 'bottom',
                                    labels: {
                                        // Função para garantir que a cor do texto da legenda mude com o tema
                                        color: function(context) {
                                            const body = document.body;
                                            return body.classList.contains('light-mode') ? '#333' : '#ddd';
                                        },
                                        font: { size: 14 }
                                    }
                                }
                            }
                        }
                    });
                    
                    // Atualiza a cor do texto da legenda ao mudar o tema
                    const themeToggleBtn = document.getElementById('theme-toggle');
                    themeToggleBtn.addEventListener('click', () => {
                        grafico.options.plugins.legend.labels.color = function() {
                            const body = document.body;
                            return body.classList.contains('light-mode') ? '#333' : '#ddd';
                        };
                        grafico.update();
                    });
                </script>
            </div>
            <?php endif; ?>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', (event) => {
            const themeToggleBtn = document.getElementById('theme-toggle');
            const body = document.body;
            
            // 1. Aplica o tema salvo no localStorage
            const savedTheme = localStorage.getItem('theme');
            if (savedTheme === 'light') {
                body.classList.add('light-mode');
                themeToggleBtn.innerHTML = '<i class="fas fa-moon"></i>';
            } else {
                // Tema escuro padrão
                themeToggleBtn.innerHTML = '<i class="fas fa-sun"></i>';
            }

            // 2. Listener para alternar o tema
            themeToggleBtn.addEventListener('click', () => {
                body.classList.toggle('light-mode');

                if (body.classList.contains('light-mode')) {
                    localStorage.setItem('theme', 'light');
                    themeToggleBtn.innerHTML = '<i class="fas fa-moon"></i>';
                } else {
                    localStorage.setItem('theme', 'dark');
                    themeToggleBtn.innerHTML = '<i class="fas fa-sun"></i>';
                }
            });
            
            // O menu lateral está agora fixo (sem a função toggleMenu)
        });
    </script>
</body>
</html>
