<?php
session_start();
include("../config/db.php");

// Verifica se está logado
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login/login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$tipo_usuario = $_SESSION['tipo'] ?? 'comum';

// Verifica se o ID do registro foi passado
if (!isset($_GET['registro_id'])) {
    header("Location: financeiro.php");
    exit();
}

$registro_id = intval($_GET['registro_id']);

// Lógica para atualizar registro
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $valor = floatval($_POST['valor']);
    $descricao = trim(htmlspecialchars($_POST['descricao']));
    $tipo = trim(htmlspecialchars($_POST['tipo']));
    $data_registro = $_POST['data_registro'];

    $stmt = $conn->prepare("UPDATE registros_financeiros SET valor = ?, tipo = ?, descricao = ?, data_registro = ? WHERE id = ? AND user_id = ?");
    $stmt->bind_param("dsssii", $valor, $tipo, $descricao, $data_registro, $registro_id, $user_id);

    if ($stmt->execute()) {
        header("Location: financeiro.php?status=updated");
        exit();
    } else {
        $error = "Erro ao atualizar o registro.";
    }
    $stmt->close();
}

// Busca o registro para preencher o formulário
$stmt = $conn->prepare("SELECT * FROM registros_financeiros WHERE id = ? AND user_id = ?");
$stmt->bind_param("ii", $registro_id, $user_id);
$stmt->execute();
$result = $stmt->get_result();
$registro = $result->fetch_assoc();
$stmt->close();

if (!$registro) {
    header("Location: financeiro.php");
    exit();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Editar Registro - Financeiro</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <style>
        :root {
            --bg-color: #222;
            --text-color: #fff;
            --card-bg: #2b2b2b;
            --accent-color: #F58A3D;
            --border-color: #444;
            --box-shadow-color: rgba(0, 0, 0, 0.3);
        }

        body.light-mode {
            --bg-color: #f0f2f5;
            --text-color: #333;
            --card-bg: #fff;
            --accent-color: #F58A3D;
            --border-color: #dee2e6;
            --box-shadow-color: rgba(0,0,0,0.1);
        }

        body {
            background-color: var(--bg-color);
            color: var(--text-color);
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            transition: background-color 0.3s, color 0.3s;
        }

        .container {
            max-width: 600px;
            margin: 50px auto;
            background: var(--card-bg);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px var(--box-shadow-color);
            transition: background-color 0.3s, box-shadow 0.3s;
        }

        h1 {
            text-align: center;
            margin-bottom: 30px;
        }

        .form-row {
            display: flex;
            flex-direction: column;
            margin-bottom: 15px;
        }

        .form-row label {
            margin-bottom: 5px;
        }

        .form-row input, .form-row select {
            padding: 10px;
            border-radius: 5px;
            border: 1px solid var(--border-color);
            background: var(--bg-color);
            color: var(--text-color);
        }

        .btn-primary {
            display: inline-block;
            padding: 10px 20px;
            background: var(--accent-color);
            color: white;
            text-decoration: none;
            border-radius: 5px;
            border: none;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        .btn-primary:hover {
            background-color: #d87a32;
        }

        .btn-back {
            display: inline-block;
            margin-bottom: 20px;
            text-decoration: none;
            color: var(--text-color);
            background: var(--border-color);
            padding: 8px 15px;
            border-radius: 5px;
        }

        .btn-back:hover {
            background: var(--accent-color);
            color: white;
        }

        .alert {
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 5px;
            font-weight: bold;
        }

        .alert.error { background-color: #f87171; color: #fff; }

        /* Botão de tema */
        #theme-toggle {
            position: fixed;
            top: 20px;
            right: 20px;
            background: transparent;
            border: 2px solid var(--accent-color);
            border-radius: 50%;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-size: 20px;
            color: var(--accent-color);
            transition: color 0.3s, background 0.3s, border-color 0.3s;
            z-index: 1001;
        }

        #theme-toggle:hover {
            background: var(--accent-color);
            color: white;
        }
    </style>
</head>
<body>
    <button id="theme-toggle"><i class="fas fa-sun"></i></button>

    <div class="container">
        <a href="financeiro.php" class="btn-back"><i class="fas fa-arrow-left"></i> Voltar</a>
        <h1>Editar Registro</h1>

        <?php if (isset($error)): ?>
            <div class="alert error"><?php echo $error; ?></div>
        <?php endif; ?>

        <form action="" method="POST">
            <div class="form-row">
                <label for="tipo">Tipo:</label>
                <select name="tipo" id="tipo" required>
                    <option value="renda" <?php if($registro['tipo']=='renda') echo 'selected'; ?>>Renda</option>
                    <option value="custo_fixo" <?php if($registro['tipo']=='custo_fixo') echo 'selected'; ?>>Custo Fixo</option>
                    <option value="custo_variavel" <?php if($registro['tipo']=='custo_variavel') echo 'selected'; ?>>Custo Variável</option>
                    <?php if($tipo_usuario == 'admin'): ?>
                        <option value="impostos" <?php if($registro['tipo']=='impostos') echo 'selected'; ?>>Impostos</option>
                        <option value="salario" <?php if($registro['tipo']=='salario') echo 'selected'; ?>>Salário</option>
                    <?php endif; ?>
                </select>
            </div>

            <div class="form-row">
                <label for="valor">Valor (R$):</label>
                <input type="number" name="valor" id="valor" step="0.01" value="<?php echo $registro['valor']; ?>" required>
            </div>

            <div class="form-row">
                <label for="descricao">Descrição:</label>
                <input type="text" name="descricao" id="descricao" value="<?php echo htmlspecialchars($registro['descricao']); ?>" required>
            </div>

            <div class="form-row">
                <label for="data_registro">Data:</label>
                <input type="date" name="data_registro" id="data_registro" value="<?php echo $registro['data_registro']; ?>" required>
            </div>

            <button type="submit" class="btn-primary">Atualizar Registro</button>
        </form>
    </div>

    <script>
        // Alternar tema claro/escuro
        const themeToggleBtn = document.getElementById('theme-toggle');
        const body = document.body;

        // Aplica tema salvo
        const savedTheme = localStorage.getItem('theme');
        if(savedTheme === 'light') {
            body.classList.add('light-mode');
            themeToggleBtn.innerHTML = '<i class="fas fa-moon"></i>';
        } else {
            themeToggleBtn.innerHTML = '<i class="fas fa-sun"></i>';
        }

        themeToggleBtn.addEventListener('click', () => {
            body.classList.toggle('light-mode');
            if(body.classList.contains('light-mode')) {
                localStorage.setItem('theme', 'light');
                themeToggleBtn.innerHTML = '<i class="fas fa-moon"></i>';
            } else {
                localStorage.setItem('theme', 'dark');
                themeToggleBtn.innerHTML = '<i class="fas fa-sun"></i>';
            }
        });
    </script>
</body>
</html>
