<?php
// Ativa a exibição de erros para diagnóstico (Desativar em produção!)
// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);

session_start();
// Importa o arquivo de conexão com o banco de dados
include("../config/db.php");

// 1. Verificação de Sessão
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login/login.php"); // Redirecionado para a pasta de login
    exit();
}

$user_id = $_SESSION['user_id'];
$tipo_usuario = $_SESSION['tipo'] ?? 'comum'; // Garante que tipo_usuario tem um valor padrão
$records = [];
$total_renda = 0;
$total_custo_fixo = 0;
$total_custo_variavel = 0;
$total_impostos = 0;
$total_salario = 0;
$saldo_liquido = 0;

// 2. Lógica para obter o mês para filtragem
// Prioriza o mês enviado via GET ou usa o mês e ano atuais
$mes_filtro = isset($_GET['mes']) ? $_GET['mes'] : date('Y-m');

// 3. Lógica para Inserção de Novo Registro
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Garante que o valor seja um float e sanitiza inputs
    $valor = floatval($_POST['valor']);
    $descricao = trim(htmlspecialchars($_POST['descricao']));
    $tipo = trim(htmlspecialchars($_POST['tipo']));
    $data_registro = $_POST['data_registro'];
    
    // Insere o registro no banco de dados com prepared statements
    $stmt = $conn->prepare("INSERT INTO registros_financeiros (user_id, valor, tipo, descricao, data_registro) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("idsss", $user_id, $valor, $tipo, $descricao, $data_registro);
    
    if ($stmt->execute()) {
        // Redireciona para evitar reenvio do formulário, adicionando status de sucesso
        header("Location: financeiro.php?mes=" . $mes_filtro . "&status=success");
    } else {
        // Redireciona com status de erro, caso a execução falhe
        header("Location: financeiro.php?mes=" . $mes_filtro . "&status=error");
    }
    
    $stmt->close();
    exit();
}

// 4. Lógica para Buscar os Registros do Mês Filtrado
$stmt = $conn->prepare("SELECT * FROM registros_financeiros WHERE user_id = ? AND DATE_FORMAT(data_registro, '%Y-%m') = ? ORDER BY data_registro DESC");
$stmt->bind_param("is", $user_id, $mes_filtro);
$stmt->execute();
$result = $stmt->get_result();

// 5. Calcula os totais financeiros
while ($row = $result->fetch_assoc()) {
    $records[] = $row;
    if ($row['tipo'] == 'renda') {
        $total_renda += $row['valor'];
    } elseif ($row['tipo'] == 'custo_fixo') {
        $total_custo_fixo += $row['valor'];
    } elseif ($row['tipo'] == 'custo_variavel') {
        $total_custo_variavel += $row['valor'];
    } elseif ($row['tipo'] == 'impostos') {
        $total_impostos += $row['valor'];
    } elseif ($row['tipo'] == 'salario') {
        $total_salario += $row['valor'];
    }
}
$stmt->close();

$total_despesas = $total_custo_fixo + $total_custo_variavel + $total_impostos + $total_salario;
$saldo_liquido = $total_renda - $total_despesas;

// Verifica se há mensagens de status na URL
$message = '';
if (isset($_GET['status'])) {
    if ($_GET['status'] == 'success') {
        $message = '<div class="alert success">Registro adicionado com sucesso!</div>';
    } elseif ($_GET['status'] == 'error') {
        $message = '<div class="alert error">Erro ao adicionar o registro financeiro.</div>';
    }
}

// Fecha a conexão com o banco de dados
$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Financeiro - TCC Rinaldi</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    
    <link rel="stylesheet" href="financeiro.css?v=<?php echo time(); ?>"> 
    
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <style>
        /* Variáveis de Tema */
        :root {
            --sidebar-width-open: 250px;
            --sidebar-width-closed: 60px;

            /* Variáveis para cores do tema escuro (padrão) */
            --bg-color: #222;
            --text-color: #fff;
            --card-bg: #2b2b2b;
            --sidebar-bg: #1a1a1a;
            --menu-bg: #333;
            --menu-hover-bg: #444;
            --accent-color: #F58A3D; /* Laranja principal */
            --border-color: #444;
            --box-shadow-color: rgba(0, 0, 0, 0.3);
        }

        /* Variáveis para cores do tema claro */
        body.light-mode {
            --bg-color: #f0f2f5;
            --text-color: #333;
            --card-bg: #fff;
            --sidebar-bg: #f8f9fa;
            --menu-bg: #e9ecef;
            --menu-hover-bg: #dee2e6;
            --accent-color: #F58A3D;
            --border-color: #dee2e6;
            --box-shadow-color: rgba(0, 0, 0, 0.1);
        }

        /* Estilos do body e transições */
        body {
            background-color: var(--bg-color);
            color: var(--text-color);
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            transition: background-color 0.3s ease, color 0.3s ease;
        }

        /* Menu Lateral (Sidebar) com efeito hover (Desktop) */
        .sidebar {
            width: var(--sidebar-width-closed);
            background-color: var(--sidebar-bg);
            color: var(--text-color);
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            display: flex;
            flex-direction: column;
            align-items: center; 
            transition: width 0.3s ease-in-out, background-color 0.3s ease;
            z-index: 1000;
            overflow-x: hidden;
            box-shadow: 2px 0 5px var(--box-shadow-color);
        }

        .sidebar:hover {
            width: var(--sidebar-width-open);
        }

        /* LOGO */
        .logo {
            padding: 10px 0;
            margin-bottom: 10px;
            white-space: nowrap;
            opacity: 1; 
            width: 100%; 
            text-align: center;
            box-sizing: border-box;
        }

        .logo img {
            max-width: 40px; 
            max-height: 40px; 
            height: auto;
            display: block;
            margin: 0 auto;
            object-fit: contain;
            transition: max-height 0.3s ease-in-out, max-width 0.3s ease-in-out;
        }

        .sidebar:hover .logo img {
            max-width: 120%;
            max-height: 120px;
        }
        
        .menu-list {
            list-style: none;
            padding: 0;
            width: 100%;
        }

        .menu-list li {
            margin-bottom: 5px;
            padding: 0 5px;
        }

        .menu-list a {
            color: var(--text-color);
            text-decoration: none;
            display: flex;
            padding: 15px;
            background-color: var(--menu-bg);
            border-radius: 8px;
            transition: background-color 0.3s ease;
            font-size: 18px;
            align-items: center;
        }

        .menu-list a .fas {
            margin-right: 15px;
            color: var(--accent-color);
            min-width: 25px;
            text-align: center;
        }

        .menu-list a span {
            display: inline-block;
            visibility: hidden; 
            opacity: 0;
            white-space: nowrap;
            transition: opacity 0.2s ease, visibility 0.2s ease;
        }

        .sidebar:hover .menu-list a span {
            visibility: visible;
            opacity: 1;
        }

        .menu-list a:hover {
            background-color: var(--menu-hover-bg);
        }

        /* Conteúdo Principal */
        .main-content {
            margin-left: var(--sidebar-width-closed);
            padding: 20px;
            flex-grow: 1;
            box-sizing: border-box;
            transition: margin-left 0.3s ease-in-out;
            width: 100%; 
        }

        .sidebar:hover ~ .main-content {
            margin-left: var(--sidebar-width-open);
        }

        /* Botão de tema no canto superior direito */
        #theme-toggle {
            position: fixed;
            top: 20px;
            right: 20px;
            background: transparent;
            border: 2px solid var(--accent-color);
            border-radius: 50%;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-size: 20px;
            color: var(--accent-color);
            transition: color 0.3s ease, background 0.3s ease, border-color 0.3s ease;
            z-index: 1001;
        }

        #theme-toggle:hover {
            background: var(--accent-color);
            color: white;
        }
        
        /* Botão de Toggle para Mobile */
        .menu-toggle {
            display: none; /* Esconde no desktop */
            position: fixed;
            top: 20px;
            left: 20px;
            z-index: 1002;
            background: var(--accent-color);
            color: white;
            padding: 10px;
            border-radius: 5px;
            cursor: pointer;
        }

        /* Alertas */
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 8px;
            font-weight: bold;
        }

        .alert.success {
            background-color: #34d399;
            color: white;
        }

        .alert.error {
            background-color: #f87171;
            color: white;
        }
        
        /* Media Queries para Responsividade (Mobile) */
        @media (max-width: 768px) {
            .menu-toggle {
                display: block;
            }
            
            .sidebar {
                width: 0;
                transform: translateX(-100%);
                transition: transform 0.3s ease-in-out, width 0.3s ease-in-out;
            }
            
            .sidebar.active {
                width: var(--sidebar-width-open);
                transform: translateX(0);
            }
            
            .sidebar:hover {
                width: 0;
            }

            .main-content {
                margin-left: 0;
                padding-top: 60px;
            }
        }

        /* ESTILOS ESPECÍFICOS DO FINANCEIRO */
        .financeiro-container {
            max-width: 1200px;
            margin: auto;
            text-align: center;
        }
        
        .overview-cards {
            display: flex;
            justify-content: space-around;
            gap: 20px;
            margin-bottom: 30px;
            flex-wrap: wrap;
        }
        
        .overview-cards .card {
            background: var(--card-bg);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px var(--box-shadow-color);
            min-width: 250px;
            transition: background-color 0.3s ease;
        }
        
        .renda-card i { color: #34d399; }
        .despesa-card i { color: #f87171; }
        .saldo-card i { color: var(--accent-color); }
        
        .card h3 {
            margin: 5px 0 0;
            font-size: 1.5em;
        }

        .positivo { color: #34d399 !important; }
        .negativo { color: #f87171 !important; }

        .form-section, .data-display-section {
            background: var(--card-bg);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px var(--box-shadow-color);
            margin-bottom: 30px;
            transition: background-color 0.3s ease;
            text-align: left;
        }
        
        .form-row {
            display: flex;
            flex-direction: column;
            margin-bottom: 15px;
        }
        
        .form-section input, .form-section select {
            padding: 10px;
            border-radius: 5px;
            border: 1px solid var(--border-color);
            background: var(--bg-color);
            color: var(--text-color);
            margin-top: 5px;
        }

        .btn-primary {
            display: inline-block;
            padding: 10px 20px;
            background: var(--accent-color);
            color: white;
            text-decoration: none;
            border-radius: 5px;
            border: none;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        .btn-primary:hover {
            background-color: #d87a32;
        }

        /* Tabela e Filtro */
        .filter-section {
            text-align: right;
            margin-bottom: 20px;
        }

        .filter-section label {
            margin-right: 10px;
        }
        
        .tabela-wrapper {
            overflow-x: auto;
            margin-top: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }
        
        table th, table td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid var(--border-color);
        }
        
        table th {
            background-color: var(--menu-bg);
            color: var(--text-color);
        }
        
        table tr:hover {
            background-color: var(--menu-hover-bg);
        }

        .no-data {
            text-align: center;
            font-style: italic;
            color: var(--text-color);
        }
        
        .grafico-container {
            margin-top: 40px;
            padding: 20px;
            background: var(--menu-bg);
            border-radius: 10px;
            /* CORREÇÃO DO TAMANHO E CENTRALIZAÇÃO */
            max-width: 500px;
            margin-left: auto;
            margin-right: auto;
        }
        
        .grafico-container h2 {
            text-align: center;
            color: var(--text-color);
        }
        
        /* Ajuste do gráfico para o tema */
        .chartjs-render-monitor {
            background-color: var(--menu-bg);
        }

    </style>
</head>
<body>
    <button id="theme-toggle">
        <i class="fas fa-sun"></i>
    </button>

    <div class="menu-toggle" onclick="toggleMenu()">
        <i class="fas fa-bars"></i>
    </div>
    
    <div class="sidebar" id="sidebar">
        <div class="logo">
            <a href="../home/home.php">
                <img src="../boasvindas/LogoTipo Auxtec.png" alt="Logo da Auxtec">
            </a>
        </div>
        <ul class="menu-list">
            <li><a href="../home/home.php"><i class="fas fa-home"></i> <span>Início</span></a></li>
            <li><a href="../perfil/editar_perfil.php"><i class="fas fa-user-circle"></i> <span>Meu Perfil</span></a></li>
            <li><a href="../juridico/juridico.php"><i class="fas fa-gavel"></i> <span>Jurídico</span></a></li>
            <li><a href="../financeiro/financeiro.php"><i class="fas fa-wallet"></i> <span>Financeiro</span></a></li>
            <li><a href="../calculadora/calculadora.php"><i class="fas fa-calculator"></i> <span>Calculadora</span></a></li>
            <li><a href="../planilhas/planilhas.php"><i class="fas fa-file-excel"></i> <span>Minhas Planilhas</span></a></li>
            <li><a href="../calendario/calendario.php"><i class="fas fa-calendar-alt"></i> <span>Calendário</span></a></li>
            <li><a href="../login/logout.php"><i class="fas fa-sign-out-alt"></i> <span>Sair</span></a></li>
            <?php if ($tipo_usuario == 'admin'): ?>
                <li><a href="../admin/admin.php"><i class="fas fa-user-shield"></i> <span>Painel Admin</span></a></li>
            <?php endif; ?>
        </ul>
    </div>

    <div class="main-content">
        <?php echo $message; ?>
        <div class="financeiro-container">
            <h1>Registro Financeiro</h1>
            <div class="overview-section">
                <h2>Visão Geral do Mês</h2>
                <div class="overview-cards">
                    <div class="card renda-card">
                        <i class="fas fa-arrow-up"></i>
                        <p>Renda Total</p>
                        <h3>R$ <?php echo number_format($total_renda, 2, ",", "."); ?></h3>
                    </div>
                    <div class="card despesa-card">
                        <i class="fas fa-arrow-down"></i>
                        <p>Total de Despesas</p>
                        <h3>R$ <?php echo number_format($total_despesas, 2, ",", "."); ?></h3>
                    </div>
                    <div class="card saldo-card">
                        <i class="fas fa-wallet"></i>
                        <p>Saldo Líquido</p>
                        <h3 class="<?php echo ($saldo_liquido >= 0) ? 'positivo' : 'negativo'; ?>">R$ <?php echo number_format($saldo_liquido, 2, ",", "."); ?></h3>
                    </div>
                </div>
            </div>

            <div class="form-section">
                <h2>Adicionar Novo Registro</h2>
                <form action="financeiro.php?mes=<?php echo htmlspecialchars($mes_filtro); ?>" method="POST">
                    <div class="form-row">
                        <label for="tipo">Tipo:</label>
                        <select name="tipo" id="tipo" required>
                            <option value="">Selecione...</option>
                            <option value="renda">Renda</option>
                            <option value="custo_fixo">Custo Fixo</option>
                            <option value="custo_variavel">Custo Variável</option>
                            <?php if ($tipo_usuario == 'admin'): ?>
                                <option value="impostos">Impostos</option>
                                <option value="salario">Salário</option>
                            <?php endif; ?>
                        </select>
                    </div>
                    <div class="form-row">
                        <label for="valor">Valor (R$):</label>
                        <input type="number" name="valor" id="valor" step="0.01" required>
                    </div>
                    <div class="form-row">
                        <label for="descricao">Descrição:</label>
                        <input type="text" name="descricao" id="descricao" required>
                    </div>
                    <div class="form-row">
                        <label for="data_registro">Data:</label>
                        <input type="date" name="data_registro" id="data_registro" value="<?php echo date('Y-m-d'); ?>" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Adicionar Registro</button>
                </form>
            </div>

            <div class="data-display-section">
                <div class="filter-section">
                    <form action="financeiro.php" method="GET">
                        <label for="mes">Filtrar por Mês:</label>
                        <input type="month" id="mes" name="mes" value="<?php echo htmlspecialchars($mes_filtro); ?>" onchange="this.form.submit()">
                    </form>
                </div>



                <h2>Registros de <?php echo date("F Y", strtotime($mes_filtro)); ?></h2>
                <div class="tabela-wrapper">
    <table>
        <thead>
            <tr>
                <th>Data</th>
                <th>Tipo</th>
                <th>Descrição</th>
                <th>Valor</th>
                <th>Ações</th> <!-- Coluna para o botão Editar -->
            </tr>
        </thead>
        <tbody>
            <?php if (empty($records)): ?>
                <tr>
                    <td colspan="5" class="no-data">Nenhum registro encontrado para este mês.</td>
                </tr>
            <?php else: ?>
                <?php foreach ($records as $record): ?>
                    <tr>
                        <td><?php echo date("d/m/Y", strtotime($record['data_registro'])); ?></td>
                        <td><?php echo htmlspecialchars($record['tipo']); ?></td>
                        <td><?php echo htmlspecialchars($record['descricao']); ?></td>
                        <td>R$ <?php echo number_format($record['valor'], 2, ",", "."); ?></td>
                        <td>
                            <a href="editar_registro.php?registro_id=<?php echo $record['id']; ?>" class="btn-primary">✏️ Editar</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>


                <div class="grafico-container">
                    <h2>Composição Financeira</h2>
                    <canvas id="financeiroChart"></canvas>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Função para abrir e fechar o menu lateral (usada no botão de mobile)
        function toggleMenu() {
            var sidebar = document.getElementById("sidebar");
            sidebar.classList.toggle("active");
        }

        document.addEventListener('DOMContentLoaded', function() {
            const body = document.body;
            const themeToggleBtn = document.getElementById('theme-toggle');
            
            // --- LÓGICA DO TEMA ---
            
            // Pega o tema salvo e aplica
            const savedTheme = localStorage.getItem('theme');
            if (savedTheme === 'light') {
                body.classList.add('light-mode');
                themeToggleBtn.innerHTML = '<i class="fas fa-moon"></i>';
            } else {
                // Tema escuro padrão
                themeToggleBtn.innerHTML = '<i class="fas fa-sun"></i>';
            }

            // Listener para alternar o tema ao clicar
            themeToggleBtn.addEventListener('click', () => {
                body.classList.toggle('light-mode');

                if (body.classList.contains('light-mode')) {
                    localStorage.setItem('theme', 'light');
                    themeToggleBtn.innerHTML = '<i class="fas fa-moon"></i>';
                } else {
                    localStorage.setItem('theme', 'dark');
                    themeToggleBtn.innerHTML = '<i class="fas fa-sun"></i>';
                }
                
                // Atualiza o gráfico após a mudança de tema
                updateChart();
            });

            // --- LÓGICA DO GRÁFICO (Chart.js) ---
            
            const chartData = {
                renda: <?php echo $total_renda; ?>,
                custoFixo: <?php echo $total_custo_fixo; ?>,
                custoVariavel: <?php echo $total_custo_variavel; ?>,
                impostos: <?php echo $total_impostos; ?>,
                salario: <?php echo $total_salario; ?>
            };
            
            const ctx = document.getElementById('financeiroChart');
            let myChart = null; // Variável para armazenar a instância do gráfico
            
            // FUNÇÃO CORRIGIDA: Define a cor do texto do gráfico com base no tema do body
            function getChartTextColor() {
                // Se estiver no modo claro, retorna preto. Senão, retorna branco.
                return body.classList.contains('light-mode') ? '#333' : '#fff'; 
            }

            function renderChart() {
                if (myChart) {
                    myChart.destroy(); // Destrói a instância anterior antes de criar uma nova
                }
                
                const textColor = getChartTextColor();

                const data = {
                    labels: ['Renda', 'Custo Fixo', 'Custo Variável', 'Impostos', 'Salário'],
                    datasets: [{
                        data: [
                            chartData.renda,
                            chartData.custoFixo,
                            chartData.custoVariavel,
                            chartData.impostos,
                            chartData.salario
                        ],
                        backgroundColor: [
                            '#34d399', // Verde para Renda
                            '#f87171', // Vermelho para Custo Fixo
                            '#fbbf24', // Amarelo para Custo Variável
                            '#60a5fa', // Azul para Impostos
                            '#c084fc'  // Roxo para Salário
                        ],
                        // Borda para destacar as fatias
                        borderColor: textColor, 
                        borderWidth: 2
                    }]
                };

                const config = {
                    type: 'pie',
                    data: data,
                    options: {
                        responsive: true,
                        plugins: {
                            legend: {
                                position: 'top',
                                labels: {
                                    color: textColor // Corrigido
                                }
                            },
                            title: {
                                display: true,
                                text: 'Distribuição de Renda e Despesas',
                                color: textColor // Corrigido
                            },
                            tooltip: {
                                callbacks: {
                                    label: function(context) {
                                        let label = context.label || '';
                                        if (label) {
                                            label += ': ';
                                        }
                                        if (context.parsed !== null) {
                                            label += 'R$ ' + context.parsed.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
                                        }
                                        return label;
                                    }
                                }
                            }
                        }
                    }
                };

                myChart = new Chart(ctx, config);
            }

            function updateChart() {
                if (myChart) {
                    const textColor = getChartTextColor();
                    
                    // Atualiza as cores para o novo tema
                    myChart.options.plugins.legend.labels.color = textColor;
                    myChart.options.plugins.title.color = textColor; 
                    
                    myChart.update();
                } else {
                    renderChart();
                }
            }
            
            // Desenha o gráfico na inicialização
            renderChart();
        });
    </script>
</body>
</html>