<?php
// Configurações do banco de dados
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "tcc_rinaldi"; // Certifique-se de que o nome do banco está correto

// Criar conexão
$conn = new mysqli($host, $user, $pass, $dbname);

// Verificar conexão
if ($conn->connect_error) {
    die("Erro na conexão: " . $conn->connect_error);
}
?>