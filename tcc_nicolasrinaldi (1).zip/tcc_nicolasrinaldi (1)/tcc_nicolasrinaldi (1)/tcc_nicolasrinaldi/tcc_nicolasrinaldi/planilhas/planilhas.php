<?php
// Ativa a exibição de erros para diagnóstico
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
include("../config/db.php");

if (!isset($_SESSION['user_id'])) {
    header("Location: ../boasvindas.html");
    exit();
}

$user_id = $_SESSION['user_id'];
$records = [];
$chart_labels = [];
$chart_datasets = [];
$tipo = $_SESSION['tipo'] ?? 'comum';

// Lógica para obter os meses para filtragem
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['gerar_grafico'])) {
    $mes_inicio = $_POST['mes_inicio'] ?? date('Y-m', strtotime('-5 months'));
    $mes_fim = $_POST['mes_fim'] ?? date('Y-m');
} else {
    $mes_inicio = date('Y-m', strtotime('-5 months'));
    $mes_fim = date('Y-m');
}

// Converte os meses para datas completas
$data_inicio = $mes_inicio . '-01';
$data_fim = date('Y-m-t', strtotime($mes_fim));

// Lógica para buscar os registros de cálculo
$stmt = $conn->prepare("SELECT * FROM calculos WHERE user_id = ? AND data_calculo BETWEEN ? AND ? ORDER BY data_calculo ASC");
$stmt->bind_param("iss", $user_id, $data_inicio, $data_fim);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $records[] = $row;
}
$stmt->close();

// Lógica para gerar o gráfico com base nos campos selecionados
$default_fields = ['saldo']; 
$selected_fields = $default_fields;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['gerar_grafico'])) {
    // Busca os campos selecionados do formulário
    $selected_fields = $_POST['campos'] ?? $default_fields;
    
    if (empty($selected_fields)) {
        $selected_fields = $default_fields;
    }
}

if (!empty($records)) {
    $chart_labels = array_map(function($record) {
        return date("d/m", strtotime($record['data_calculo']));
    }, $records);

    // Cores fixas para o gráfico
    $colors = [
        'renda_bruta' => '#28a745',
        'despesas_fixas' => '#dc3545',
        'despesas_variaveis' => '#ffc107',
        'impostos' => '#6c757d',
        'salario' => '#17a2b8',
        'saldo' => '#007bff'
    ];

    foreach ($selected_fields as $field) {
        if (isset($records[0][$field])) { 
            $data_points = array_map(function($record) use ($field) {
                return $record[$field];
            }, $records);
            
            $chart_datasets[] = [
                'label' => ucwords(str_replace('_', ' ', $field)),
                'data' => $data_points,
                'borderColor' => $colors[$field] ?? '#333', 
                'backgroundColor' => 'transparent',
                'tension' => 0.4
            ];
        }
    }
}

if (isset($conn)) {
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Minhas Planilhas - TCC Rinaldi</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        /* ========================================================================= */
        /* VARIÁVEIS DE TEMA E ESTRUTURA GLOBAL (DARK MODE PADRÃO)                  */
        /* ========================================================================= */
        :root {
            --sidebar-width-open: 250px;
            --sidebar-width-closed: 60px;

            /* Cores do Tema Escuro */
            --bg-color: #222;
            --text-color: #fff;
            --card-bg: #2b2b2b;
            --sidebar-bg: #1a1a1a;
            --menu-bg: #333;
            --menu-hover-bg: #444;
            --accent-color: #F58A3D;
            --border-color: #444;
            --box-shadow-color: rgba(0, 0, 0, 0.3);
            
            /* Mapeamento para o CSS de Planilhas */
            --cor-card: var(--card-bg);
            --cor-texto-principal: var(--text-color);
            --cor-texto-secundario: #aaa;
            --cor-borda: var(--border-color);
            --cor-destaque: var(--accent-color);
            --cor-fundo-secundario: #333;
            --cor-header-tabela: #333;
            --cor-texto-header-tabela: #fff;
            --cor-tabela-zebra: #272727;
        }

        /* Cores do Tema Claro */
        body.light-mode {
            --bg-color: #f0f2f5;
            --text-color: #333;
            --card-bg: #fff;
            --sidebar-bg: #f8f9fa;
            --menu-bg: #e9ecef;
            --menu-hover-bg: #dee2e6;
            --accent-color: #F58A3D;
            --border-color: #dee2e6;
            --box-shadow-color: rgba(0, 0, 0, 0.1);
            
            /* Mapeamento para o CSS de Planilhas */
            --cor-card: var(--card-bg);
            --cor-texto-principal: var(--text-color);
            --cor-texto-secundario: #6c757d;
            --cor-borda: var(--border-color);
            --cor-destaque: var(--accent-color);
            --cor-fundo-secundario: #fff;
            --cor-header-tabela: #007bff;
            --cor-texto-header-tabela: #fff;
            --cor-tabela-zebra: #f6f6f6;
        }

        body {
            background-color: var(--bg-color);
            color: var(--text-color);
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            transition: background-color 0.3s ease, color 0.3s ease;
        }

        /* Botão de tema */
        #theme-toggle {
            position: fixed;
            top: 20px;
            right: 20px;
            background: transparent;
            border: 2px solid var(--accent-color);
            border-radius: 50%;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-size: 20px;
            color: var(--accent-color);
            transition: color 0.3s ease, background 0.3s ease, border-color 0.3s ease;
            z-index: 1001;
        }

        #theme-toggle:hover {
            background: var(--accent-color);
            color: white;
        }

        /* ========================================================================= */
        /* MENU LATERAL (SIDEBAR)                                                    */
        /* ========================================================================= */
        .sidebar {
            width: var(--sidebar-width-closed);
            background-color: var(--sidebar-bg);
            color: var(--text-color);
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            display: flex;
            flex-direction: column;
            align-items: center; 
            transition: width 0.3s ease-in-out, background-color 0.3s ease;
            z-index: 1000;
            overflow-x: hidden;
            box-shadow: 2px 0 5px var(--box-shadow-color);
        }

        .sidebar:hover {
            width: var(--sidebar-width-open);
        }

        .logo {
            padding: 10px 0;
            margin-bottom: 10px;
            white-space: nowrap;
            opacity: 1; 
            width: 100%; 
            text-align: center;
            box-sizing: border-box;
        }
        
        .logo img {
            max-width: 40px; 
            max-height: 40px; 
            height: auto;
            display: block;
            margin: 0 auto;
            object-fit: contain;
            transition: max-height 0.3s ease-in-out, max-width 0.3s ease-in-out;
        }

        .sidebar:hover .logo {
            width: var(--sidebar-width-open); 
        }

        .sidebar:hover .logo img {
            max-width: 120%;
            max-height: 120px;
        }

        .menu-list {
            list-style: none;
            padding: 0;
            width: 100%;
        }

        .menu-list li {
            margin-bottom: 5px;
            padding: 0 5px;
        }

        .menu-list a {
            color: var(--text-color);
            text-decoration: none;
            display: flex;
            padding: 15px;
            background-color: var(--menu-bg);
            border-radius: 8px;
            transition: background-color 0.3s ease;
            font-size: 18px;
            align-items: center;
        }
        
        .menu-list a .fas {
            margin-right: 15px;
            color: var(--accent-color);
            min-width: 25px;
            text-align: center;
        }
        
        .menu-list a span {
            display: inline-block;
            visibility: hidden; 
            opacity: 0;
            white-space: nowrap;
            transition: opacity 0.2s ease, visibility 0.2s ease;
        }

        .sidebar:hover .menu-list a span {
            visibility: visible;
            opacity: 1;
        }

        .menu-list a:hover {
            background-color: var(--menu-hover-bg);
        }

        /* Conteúdo Principal */
        .main-content {
            margin-left: var(--sidebar-width-closed);
            padding: 20px;
            flex-grow: 1;
            box-sizing: border-box;
            transition: margin-left 0.3s ease-in-out;
        }

        .sidebar:hover ~ .main-content {
            margin-left: var(--sidebar-width-open);
        }

        /* ========================================================================= */
        /* ESTILOS DA PÁGINA PLANILHAS (planilhas.css)                               */
        /* ========================================================================= */
        .planilhas-container {
            padding: 30px;
            border-radius: 12px;
            width: 100%;
            max-width: 1000px;
            background: var(--cor-card);
            box-shadow: 0 2px 10px var(--box-shadow-color);
            margin: auto;
        }

        h1 {
            font-size: 1.5rem;
            font-weight: bold;
            color: var(--cor-texto-principal);
            margin-bottom: 25px;
        }

        .filter-section form {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 1px solid var(--cor-borda);
        }

        .filter-section label {
            font-weight: 500;
            color: var(--cor-texto-secundario);
            white-space: nowrap;
        }

        .filter-section input[type="month"] {
            padding: 8px;
            border: 1px solid var(--cor-borda);
            border-radius: 4px;
            background: var(--cor-fundo-secundario);
            color: var(--cor-texto-principal);
            transition: border-color 0.2s;
            flex-grow: 1;
            max-width: 150px;
        }

        /* Botões */
        .btn {
            padding: 8px 15px;
            border: none;
            border-radius: 4px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            transition: all 0.2s;
            white-space: nowrap;
            font-size: 0.9rem;
        }

        .btn-primary {
            background: var(--cor-destaque);
            color: #fff;
        }

        .btn-primary:hover {
            opacity: 0.9;
            box-shadow: 0 2px 5px var(--box-shadow-color);
        }

        /* Tabela */
        .tabela-wrapper {
            overflow-x: auto;
            margin-bottom: 40px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: var(--cor-card);
            border-radius: 4px;
            overflow: hidden;
            box-shadow: 0 1px 3px var(--box-shadow-color);
            min-width: 800px;
        }

        table thead th {
            background: var(--cor-header-tabela);
            color: var(--cor-texto-header-tabela);
            padding: 10px 12px;
            text-align: left;
            font-size: 0.9rem;
            font-weight: 600;
            border-bottom: 1px solid var(--cor-borda);
        }

        table tbody tr {
            border-bottom: 1px solid var(--cor-borda);
            color: var(--cor-texto-principal);
        }

        table tbody tr:last-child {
            border-bottom: none;
        }

        table tbody tr:nth-child(even) {
            background: var(--cor-tabela-zebra);
        }

        table td {
            padding: 10px 12px;
            font-size: 0.9rem;
            white-space: nowrap;
        }

        .positivo {
            color: #28a745;
            font-weight: bold;
        }

        .negativo {
            color: #dc3545;
            font-weight: bold;
        }

        /* Gráfico */
        .grafico-container {
            margin-top: 30px;
            padding: 20px;
            background: var(--cor-card);
            border: 1px solid var(--cor-borda);
            border-radius: 8px;
            box-shadow: 0 1px 5px var(--box-shadow-color);
        }

        .grafico-container h2 {
            font-size: 1.3rem;
            color: var(--cor-texto-principal);
            text-align: center;
            margin-bottom: 20px;
        }

        .grafico-form {
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            gap: 15px;
            margin-bottom: 20px;
            justify-content: center;
            padding-bottom: 15px;
            border-bottom: 1px dashed var(--cor-borda);
        }

        .checkbox-group {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
        }

        .checkbox-group label {
            font-size: 0.9rem;
            color: var(--cor-texto-secundario);
            display: flex;
            align-items: center;
            cursor: pointer;
        }

        .checkbox-group input[type="checkbox"] {
            margin-right: 5px;
            accent-color: var(--cor-destaque);
        }

        .no-data {
            text-align: center;
            color: var(--cor-texto-secundario);
            padding: 50px;
        }

        .no-data a {
            color: var(--cor-destaque);
            text-decoration: none;
            font-weight: bold;
        }
        
        /* Footer */
        footer {
            text-align: center;
            padding: 20px 0;
            margin-top: 50px;
            border-top: 1px solid var(--cor-borda);
            color: var(--cor-texto-secundario);
        }

        /* Responsividade */
        .menu-toggle {
            display: none;
            position: fixed;
            top: 15px;
            left: 15px;
            background: var(--accent-color);
            color: white;
            padding: 10px 12px;
            border-radius: 5px;
            cursor: pointer;
            z-index: 1002;
            font-size: 20px;
        }
        
        @media (max-width: 768px) {
            .planilhas-container {
                padding: 15px;
            }

            .filter-section form, .grafico-form {
                flex-direction: column;
                align-items: stretch;
            }

            .filter-section input[type="month"] {
                max-width: 100%;
            }

            .checkbox-group {
                flex-direction: column;
                gap: 10px;
            }
            
            .sidebar {
                transform: translateX(-100%);
                width: var(--sidebar-width-open);
                transition: transform 0.3s ease-in-out;
            }
            .sidebar.active {
                transform: translateX(0);
            }
            .main-content {
                margin-left: 0;
                padding-top: 60px;
            }
            .sidebar:hover ~ .main-content {
                margin-left: 0;
            }
            .menu-toggle {
                display: block;
            }
            #theme-toggle {
                top: 15px;
                right: 15px;
            }
        }
    </style>
</head>
<body>
    <button id="theme-toggle">
        <i class="fas fa-sun"></i>
    </button>
    
    <div class="menu-toggle" onclick="toggleMenu()">
        <i class="fas fa-bars"></i>
    </div>

    <div class="sidebar" id="sidebar">
        <div class="logo">
            <a href="../home/home.php">
                <img src="../boasvindas/LogoTipo Auxtec.png" alt="Logo da Auxtec">
            </a>
        </div>
        <ul class="menu-list">
            <li><a href="../home/home.php"><i class="fas fa-home"></i> <span>Início</span></a></li>
            <li><a href="../perfil/editar_perfil.php"><i class="fas fa-user-circle"></i> <span>Meu Perfil</span></a></li>
            <li><a href="../juridico/juridico.php"><i class="fas fa-gavel"></i> <span>Jurídico</span></a></li>
            <li><a href="../financeiro/financeiro.php"><i class="fas fa-wallet"></i> <span>Financeiro</span></a></li>
            <li><a href="../calculadora/calculadora.php"><i class="fas fa-calculator"></i> <span>Calculadora</span></a></li>
            <li><a href="../planilhas/planilhas.php"><i class="fas fa-file-excel"></i> <span>Minhas Planilhas</span></a></li>
            <li><a href="../calendario/calendario.php"><i class="fas fa-calendar-alt"></i> <span>Calendário</span></a></li>
            <li><a href="../login/logout.php"><i class="fas fa-sign-out-alt"></i> <span>Sair</span></a></li>
            <?php if ($tipo == 'admin'): ?>
                <li><a href="../admin/admin.php"><i class="fas fa-user-shield"></i> <span>Painel Admin</span></a></li>
            <?php endif; ?>
        </ul>
    </div>

    <div class="main-content">
        <div class="planilhas-container">
            <h1>Minhas Planilhas Financeiras</h1>

            <div class="filter-section">
                <form action="planilhas.php" method="POST">
                    <label for="mes_inicio">Mês de Início:</label>
                    <input type="month" id="mes_inicio" name="mes_inicio" value="<?php echo htmlspecialchars($mes_inicio); ?>">
                    <label for="mes_fim">Mês de Fim:</label>
                    <input type="month" id="mes_fim" name="mes_fim" value="<?php echo htmlspecialchars($mes_fim); ?>">
                    <button type="submit" name="gerar_grafico" class="btn btn-primary">Gerar Gráfico</button>
                    
                    <div class="checkbox-group" style="display: none;">
                        <input type="checkbox" name="campos[]" value="renda_bruta" <?php echo (in_array('renda_bruta', $selected_fields)) ? 'checked' : ''; ?>>
                        <input type="checkbox" name="campos[]" value="despesas_fixas" <?php echo (in_array('despesas_fixas', $selected_fields)) ? 'checked' : ''; ?>>
                        <input type="checkbox" name="campos[]" value="despesas_variaveis" <?php echo (in_array('despesas_variaveis', $selected_fields)) ? 'checked' : ''; ?>>
                        <input type="checkbox" name="campos[]" value="saldo" <?php echo (in_array('saldo', $selected_fields)) ? 'checked' : ''; ?>>
                    </div>
                </form>
            </div>
            
            <?php if (empty($records)): ?>
                <div class="no-data">
                    <p>Nenhum cálculo encontrado para o período selecionado. Faça um cálculo na <a href="../calculadora/calculadora.php">página da calculadora</a> para começar.</p>
                </div>
            <?php else: ?>
                <div class="tabela-wrapper">
                    <table>
                        <thead>
                            <tr>
                                <th>Data</th>
                                <th>Tipo</th>
                                <th>Renda/Receita</th>
                                <th>Despesas Fixas</th>
                                <th>Despesas Variáveis</th>
                                <th>Impostos</th>
                                <th>Salário</th>
                                <th>Saldo</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($records as $record): ?>
                            <tr>
                                <td><?php echo date("d/m/Y H:i", strtotime($record['data_calculo'])); ?></td>
                                <td><?php echo htmlspecialchars($record['tipo_atividade']); ?></td>
                                <td>R$ <?php echo number_format($record['renda_bruta'], 2, ",", "."); ?></td>
                                <td>R$ <?php echo number_format($record['despesas_fixas'], 2, ",", "."); ?></td>
                                <td>R$ <?php echo number_format($record['despesas_variaveis'], 2, ",", "."); ?></td>
                                <td>R$ <?php echo number_format($record['impostos'], 2, ",", "."); ?></td>
                                <td>R$ <?php echo number_format($record['salario'], 2, ",", "."); ?></td>
                                <td><span class="<?php echo ($record['saldo'] >= 0) ? 'positivo' : 'negativo'; ?>">R$ <?php echo number_format($record['saldo'], 2, ",", "."); ?></span></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <div class="grafico-container">
                    <h2>Gráfico de Evolução</h2>
                    <form method="POST" class="grafico-form">
                        <input type="hidden" name="mes_inicio" value="<?php echo htmlspecialchars($mes_inicio); ?>">
                        <input type="hidden" name="mes_fim" value="<?php echo htmlspecialchars($mes_fim); ?>">
                        <div class="checkbox-group">
                            <label><input type="checkbox" name="campos[]" value="renda_bruta" <?php echo (in_array('renda_bruta', $selected_fields)) ? 'checked' : ''; ?>> Renda / Receita</label>
                            <label><input type="checkbox" name="campos[]" value="despesas_fixas" <?php echo (in_array('despesas_fixas', $selected_fields)) ? 'checked' : ''; ?>> Despesas Fixas</label>
                            <label><input type="checkbox" name="campos[]" value="despesas_variaveis" <?php echo (in_array('despesas_variaveis', $selected_fields)) ? 'checked' : ''; ?>> Despesas Variáveis</label>
                            <label><input type="checkbox" name="campos[]" value="saldo" <?php echo (in_array('saldo', $selected_fields)) ? 'checked' : ''; ?>> Saldo</label>
                        </div>
                        <button type="submit" name="gerar_grafico" class="btn btn-primary">Atualizar Gráfico</button>
                    </form>
                    <canvas id="evolucaoChart"></canvas>
                </div>

                <script>
                    // Os dados e a configuração do gráfico estão aqui
                    const chartData = {
                        labels: <?php echo json_encode($chart_labels); ?>,
                        datasets: <?php echo json_encode($chart_datasets); ?>
                    };

                    // Variáveis que definem as cores do Chart.js (grid e texto)
                    function getChartColors(isLightMode) {
                        return {
                            textColor: isLightMode ? '#333' : '#fff',
                            gridColor: isLightMode ? 'rgba(0, 0, 0, 0.1)' : 'rgba(255, 255, 255, 0.1)'
                        };
                    }

                    // Função para iniciar ou atualizar o gráfico
                    function initializeChart(isLightMode) {
                        const colors = getChartColors(isLightMode);

                        const config = {
                            type: 'line',
                            data: chartData,
                            options: {
                                responsive: true,
                                plugins: {
                                    legend: {
                                        position: 'top',
                                        labels: {
                                            color: colors.textColor,
                                        }
                                    },
                                    title: {
                                        display: true,
                                        text: 'Evolução Financeira ao Longo do Tempo',
                                        color: colors.textColor,
                                    }
                                },
                                scales: {
                                    x: {
                                        ticks: {
                                            color: colors.textColor,
                                        },
                                        grid: {
                                            color: colors.gridColor,
                                        }
                                    },
                                    y: {
                                        beginAtZero: true,
                                        ticks: {
                                            color: colors.textColor,
                                        },
                                        grid: {
                                            color: colors.gridColor,
                                        }
                                    }
                                }
                            }
                        };
                        
                        // Destrói a instância anterior se existir para evitar bugs de tema/cor
                        let existingChart = Chart.getChart('evolucaoChart');
                        if (existingChart) {
                            existingChart.destroy();
                        }

                        const ctx = document.getElementById('evolucaoChart').getContext('2d');
                        window.evolucaoChart = new Chart(ctx, config);
                    }

                    // Inicia o gráfico com o tema atual (dark mode padrão, a menos que o localStorage diga o contrário)
                    const initialTheme = localStorage.getItem('theme') === 'light';
                    initializeChart(initialTheme);
                </script>
            <?php endif; ?>
        </div>
        <footer>
            <p>© 2025 TCC Rinaldi. Todos os direitos reservados.</p>
        </footer>
    </div>
    
    <script>
        function toggleMenu() {
            var sidebar = document.getElementById("sidebar");
            sidebar.classList.toggle("active");
        }

        document.addEventListener('DOMContentLoaded', (event) => {
            const themeToggleBtn = document.getElementById('theme-toggle');
            const body = document.body;
            
            // 1. Aplica o tema salvo (Dark Mode é o padrão se nada estiver salvo)
            const savedTheme = localStorage.getItem('theme');
            const isLightMode = savedTheme === 'light';

            if (isLightMode) {
                body.classList.add('light-mode');
                themeToggleBtn.innerHTML = '<i class="fas fa-moon"></i>';
            } else {
                themeToggleBtn.innerHTML = '<i class="fas fa-sun"></i>';
            }
            
            // 2. Listener do botão de tema
            themeToggleBtn.addEventListener('click', () => {
                body.classList.toggle('light-mode');
                const newIsLightMode = body.classList.contains('light-mode');

                if (newIsLightMode) {
                    localStorage.setItem('theme', 'light');
                    themeToggleBtn.innerHTML = '<i class="fas fa-moon"></i>';
                } else {
                    localStorage.setItem('theme', 'dark');
                    themeToggleBtn.innerHTML = '<i class="fas fa-sun"></i>';
                }

                // 3. Atualiza o gráfico com o novo tema
                if (typeof initializeChart === 'function') {
                    initializeChart(newIsLightMode);
                }
            });
            
            // 4. Garante que o gráfico inicie com o tema correto, caso não tenha sido inicializado antes do DOMContentLoaded
            if (typeof initializeChart === 'function') {
                initializeChart(isLightMode);
            }
        });
    </script>
</body>
</html>